#include "CommandPalet.h"
#include "initalize.h"
#include "window.h"
#include <Dxlib.h>
#include <string.h>

int  Line2ListWindow( int x, int y, int paturn );

CommandPalet::CommandPalet( int member ){
	this->member = member;
	this->selectCommand = -1;
	this->time = 0;
	this->saveItem[0] = 0;
	this->saveItem[1] = 0;
	this->saveItem[2] = -1;
}

CommandPalet::~CommandPalet(void){
}

void CommandPalet::simulateTimeDraw( int skillnum ){

	int waitTime = 0;
	int actionTime = 0;
	
	if( skillnum == -1 ){
	//�A�C�e���̏ꍇ(������ҋ@80��
		waitTime = int((saveChara[Save_system.party[this->member]].status[6][0] + saveChara[Save_system.party[this->member]].status[6][1]) * 0.8 );
		actionTime = 1;
	}else if( skillnum == -2 ){
	//�����̏ꍇ(��������s���ҋ@120��
		waitTime = int((saveChara[Save_system.party[this->member]].status[6][0] + saveChara[Save_system.party[this->member]].status[6][1]) * 1.2 );
		actionTime = 1;
	}else if( skillData[skillnum].type == 0 ){
	//�����X�L���̏ꍇ
		waitTime = skillData[skillnum].waitTime[0] + int(((saveChara[Save_system.party[this->member]].status[6][0] + saveChara[Save_system.party[this->member]].status[6][1]) * skillData[skillnum].waitTime[0] ) / 100);
		actionTime = skillData[skillnum].waitTime[0] + int(((saveChara[Save_system.party[this->member]].status[6][0] + saveChara[Save_system.party[this->member]].status[6][1]) * skillData[skillnum].actionTime[0] ) / 100);
	}else if( skillData[skillnum].type == 1 ){
	//���@�X�L���̏ꍇ
		waitTime = skillData[skillnum].waitTime[0] + int(((saveChara[Save_system.party[this->member]].status[7][0] + saveChara[Save_system.party[this->member]].status[7][1]) * skillData[skillnum].waitTime[0] ) / 100);
		actionTime = skillData[skillnum].waitTime[0] + int(((saveChara[Save_system.party[this->member]].status[7][0] + saveChara[Save_system.party[this->member]].status[7][1]) * skillData[skillnum].actionTime[0] ) / 100);
	}

	//0�ȉ��`�F�b�N
	if( waitTime <= 0 ){
		waitTime = 1;
	}
	if( actionTime <= 0 ){
		actionTime = 1;
	}

	DrawFormatStringToHandle( 19 + (member * 125), 453, Color[18], Font[1], "%d", actionTime );
	DrawFormatStringToHandle( 80 + (member * 125), 453, Color[19], Font[1], "%d", waitTime ); 
}

int CommandPalet::battleSelect( int initfanc ){

	//�ϐ���`
	static int target[3] = { 0, 2, 0 };

	//�ē��쎞�̒l���Z�b�g
	if( target[1] == 2 ){
		target[1] = initfanc;
		target[0] = 0;
		//0�����Ȃ��ꍇ�̍l��(�������͕����Ȃǂ��l���ɓ���Ď���łĂ��I���\�ɂ���B�p�[�e�B�M���Ă�0�͔����Ȃ��d�l�Ȃ̂ŘM��K�v�Ȃ�
		if( initfanc == 1 ){
			while(TRUE){
				if( monster[target[0]].useflag == TRUE ){
					break;
				}
				target[0]++;
			}
		}
	}

	int mortion = ( 1 + ( GCounter % 60 ) ) / 3;

	//�`�揈��
	Draw_window( 0, 500, 0, 30 );
	if( target[1] == 0 ){
		DrawRotaGraph( 68 + ( 125 * target[0] ), 350 + mortion, 1, 0, S_Corsor, TRUE );
		DrawFormatString( 100, 5, Color[0], "%s", saveChara[Save_system.party[target[0]]].name );
	}else{
		DrawRotaGraph( 80 + ( 120 * target[0] ), 200, 1, 0, S_Corsor, TRUE );
		DrawFormatString( 100, 5, Color[0], "%s", monster[target[0]].mobObj->getName() );

		//�Ȉ�HP�Q�[�W
		SetDrawArea( 30 + ( 120 * target[0] ), 250, 30 + ( 100 * ( monster[target[0]].mobObj->getHp() / float( mobData[monster[target[0]].mobObj->getNumber()].hp ))) + ( 120 * target[0] ), 260 );
		DrawModiGraph( 30 + ( 120 * target[0] ), 250, 130 + ( 120 * target[0] ), 250, 130 + ( 120 * target[0] ), 260, 30 + ( 120 * target[0] ), 260, MiniGuage[0], TRUE );
		SetDrawArea( 0, 0, 640, 480 );

		DrawBox( 30 + ( 120 * target[0] ), 250, 130 + ( 120 * target[0] ), 260, Color[18], FALSE );

		//�^�C���Q�[�W
		DrawBox( 30 + ( 120 * target[0] ), 260, 30 + ( 120 * target[0] ) + ( ( monster[target[0]].mobObj->getNowTime(1) / float( monster[target[0]].mobObj->getMaxTime(1) ) ) * 100 ), 270, Color[18], TRUE );
		if( monster[target[0]].mobObj->getPhase() == 0 ){
			DrawBox( 30 + ( 120 * target[0] ) + ( 100 - (( monster[target[0]].mobObj->getNowTime(0) / float( monster[target[0]].mobObj->getMaxTime(0) )) * 100)), 260, 130 + ( 120 * target[0] ), 270, Color[19], TRUE );
		}
		DrawBox( 30 + ( 120 * target[0] ), 260, 130 + ( 120 * target[0] ), 270, Color[18], FALSE );
	}

	//���͊m��
	if( Keystate[KEY_INPUT_Z] == 1 ){
		target[2] = target[0] + (target[1] * 5);
		target[1] = 2;
		return target[2];
	}else if( Keystate[KEY_INPUT_X] == 1 ){
		return -2;
	}else if( Keystate[KEY_INPUT_UP] == 1 || Keystate[KEY_INPUT_DOWN] == 1){
		target[1] = ++target[1] % 2;
		for( int i = 0; i < 5; i++ ){
			if( monster[i].useflag == TRUE ){
				target[0] = i;
				break;
			}
		}
	}else if( Keystate[KEY_INPUT_LEFT] == 1 ){
		for( int i = 0; i < 6; i++ ){
			target[0]--;
			if( target[0] < 0 ){
				target[0] = 4;
			}
			if( target[1] == 1 && monster[target[0]].useflag == TRUE ){
				break;
			}else if( target[1] == 0 && Save_system.party[target[0]] != -1 ){
				break;
			}
		}
	}else if( Keystate[KEY_INPUT_RIGHT] == 1 ){
		for( int i = 0; i < 6; i++ ){
			target[0]++;
			if( target[0] > 4 ){
				target[0] = 0;
			}
			if( target[1] == 1 && monster[target[0]].useflag == TRUE ){
				break;
			}else if( target[1] == 0 && Save_system.party[target[0]] != -1 ){
				break;
			}
		}
	}
	return -1;
}

int CommandPalet::paletProc(void){
	
	switch( this->selectCommand ){
		case -1: //mainparet
			this->mainPalet();
			break;

		case 0: //�ʏ�U��
			switch( int select = battleSelect( 1 ) ){
				case -2: //�L�����Z��
					this->selectCommand = -1;
					break;

				case -1: //����O
					break;

				default: //�����
					if( select > 4 ){
						//select -= 5;
						saveChara[battle->getInputChara()].act = new Action( (saveChara[Save_system.party[battle->getInputChara()]].status[6][0] - saveChara[battle->getInputChara()].status[6][1]) / 2, (saveChara[Save_system.party[battle->getInputChara()]].status[6][0] - saveChara[battle->getInputChara()].status[6][1]) / 2, battle->getInputChara(), select, 0 );
					}else{
						saveChara[battle->getInputChara()].act = new Action( (saveChara[Save_system.party[battle->getInputChara()]].status[6][0] - saveChara[battle->getInputChara()].status[6][1]) / 2, (saveChara[Save_system.party[battle->getInputChara()]].status[6][0] - saveChara[battle->getInputChara()].status[6][1]) / 2, battle->getInputChara(), select, 0 );
					}
					return -1;
			}
			break;

		case 1:
			break;

		case 2:
			break;

		case 3:
			if( this->itemPalet() != -1 ){
				return -1;
			}
			break;

		case 4:
			break;
	}
	return 0;
}

void CommandPalet::mainPalet(void){

	int selecting = 0;

	//����
	if( Keystate[KEY_INPUT_UP] > 0 ){
		selecting = 1;
	}else if( Keystate[KEY_INPUT_RIGHT] > 0 ){
		selecting = 2;
	}else if( Keystate[KEY_INPUT_LEFT] > 0 ){
		selecting = 3;
	}else if( Keystate[KEY_INPUT_DOWN] > 0 ){
		selecting = 4;
	}

	//1������̌��ʂ�\���ɔ��f
	DrawRotaGraph( 70 + ( this->member * 124 ), 300, 1, 0, P_back, TRUE );
	if( selecting == 0 && this->time % 60 > 30 ){
		DrawRotaGraph( 70 + ( this->member * 124 ), 300, 1, 0, P_icon[1], TRUE );
	}else{
		DrawRotaGraph( 70 + ( this->member * 124 ), 300, 1, 0, P_icon[0], TRUE );
	}
	if( selecting == 1 && this->time % 60 > 30 ){
		DrawRotaGraph( 70 + ( this->member * 124 ), 271, 1, 0, P_icon[3], TRUE );
	}else{
		DrawRotaGraph( 70 + ( this->member * 124 ), 271, 1, 0, P_icon[2], TRUE );
	}
	if( selecting == 2 && this->time % 60 > 30 ){
		DrawRotaGraph( 99 + ( this->member * 124 ), 300, 1, 0, P_icon[5], TRUE );
	}else{
		DrawRotaGraph( 99 + ( this->member * 124 ), 300, 1, 0, P_icon[4], TRUE );
	}
	if( selecting == 3 && this->time % 60 > 30 ){
		DrawRotaGraph( 41 + ( this->member * 124 ), 300, 1, 0, P_icon[7], TRUE );
	}else{
		DrawRotaGraph( 41 + ( this->member * 124 ), 300, 1, 0, P_icon[6], TRUE );
	}
	if( selecting == 4 && this->time % 60 > 30 ){
		DrawRotaGraph( 70 + ( this->member * 124 ), 329, 1, 0, P_icon[9], TRUE );
	}else{
		DrawRotaGraph( 70 + ( this->member * 124 ), 329, 1, 0, P_icon[8], TRUE );
	}
	switch( selecting ){
		case 0:
			Draw_select( 59 + ( this->member * 124 ), 81 + ( this->member * 124 ), 289, 311 );
			DrawString( ( this->member * 124 ) + 70 - ( GetDrawStringWidth( "�U��", strlen( "�U��" ) ) / 2 ), 230, "�U��", Color[0] );
			simulateTimeDraw( 0 );
			break;
		case 1:
			Draw_select( 59 + ( this->member * 124 ), 81 + ( this->member * 124 ), 260, 282 );
			DrawString( ( this->member * 124 ) + 70 - ( GetDrawStringWidth( "�X�L��", strlen( "�X�L��" ) ) / 2 ), 230, "�X�L��", Color[0] );
			break;
		case 2:
			Draw_select( 88 + ( this->member * 124 ), 110 + ( this->member * 124 ), 289, 311 );
			DrawString( ( this->member * 124 ) + 70 - ( GetDrawStringWidth( "PT�Z", strlen( "PT�Z" ) ) / 2 ), 230, "PT�Z", Color[0] );
			break;
		case 3:
			Draw_select( 30 + ( this->member * 124 ), 52 + ( this->member * 124 ), 289, 311 );
			DrawString( ( this->member * 124 ) + 70 - ( GetDrawStringWidth( "����", strlen( "����" ) ) / 2 ), 230, "����", Color[0] );
			simulateTimeDraw( -1 );
			break;
		case 4:
			Draw_select( 59 + ( this->member * 124 ), 81 + ( this->member * 124 ), 318, 340 );
			DrawString( ( this->member * 124 ) + 70 - ( GetDrawStringWidth( "������", strlen( "������" ) ) / 2 ), 230, "������", Color[0] );
			simulateTimeDraw( -2 );
	}

	if( Keystate[KEY_INPUT_Z] == 1 ){
		this->selectCommand = selecting;
	}
	this->time++;
}

int CommandPalet::itemPalet(){
	
	switch( saveItem[0] ){
		case 0://���X�g����	
			saveItem[0]++;
			getListItemUse();
		case 1://�I��
			if( listMax == 0 ){
				if( message_window( 150, 200, "�g����A�C�e��������܂���", 300 ) == 1 ){
					saveItem[0] = 0;
					saveItem[1] = -2;
					this->selectCommand = -1;
					return -1;
				}else{
					break;
				}
			}
			saveItem[1] = Line2ListWindow( 90, 150, 0 );
			switch( saveItem[1] ){
				case -2://�I��
					break;

				case -1://�L�����Z��
					saveItem[0] = 0;
					saveItem[1] = -2;
					break;

				default://�I������
					saveItem[0]++;
			}
			break;
						
		case 2://�Ώۂ̑I��
			switch( saveItem[2] ){
				case -2://�L�����Z��
					saveItem[2] = -1;
					saveItem[0] = 0;
					break;

				case -1://�I��
					saveItem[2] = battleSelect( 0 );
					break;

				default://�I������
					saveChara[battle->getInputChara()].act = new Action( saveChara[battle->getInputChara()].status[6][0] - saveChara[battle->getInputChara()].status[6][1], battle->getInputChara(), saveItem[2], saveItem[1] );
					return 0;
					break;
			}
	}
	return -1;
}
