#include "BattleMob.h"
#include <Dxlib.h>
#include "initalize.h"

BattleMob::BattleMob( int number, int paturn ) : number(number){

	this->number = number;
	//�J�n���̃p�^�[���ɂ�菉���ҋ@���Ԃ��ω�
	switch( paturn ){
		case -1: //��A�h�o���e�[�W�퓬
			this->act = new Action( 1 );
			break;

		case 0: //�ʏ�퓬
			this->act = new Action( GetRand( 100 ) );
			break;

		case 1: //�A�h�o���e�[�W�퓬
			this->act = new Action( mobData[number].aspd );
			break;
	}

	//HPSP�o�^
	this->hp = mobData[number].hp;
	this->sp = mobData[number].sp;

}

int BattleMob::getTime(void){
	return this->act->getTimer();
}

int  BattleMob::getMaxTime( int phase ){
	return this->act->getMaxTime( phase );
}

int  BattleMob::getNowTime( int phase ){
	return this->act->getNowTime( phase );
}

void BattleMob::setTime( int setcount ){
	this->act->moveTimer( setcount );
}

int  BattleMob::getPhase(void){
	return this->act->getPhase();
}

void BattleMob::setAction( int actor, int target ){
	this->target = target;
	delete this->act;
	this->act = new Action( mobData[this->getNumber()].aspd / 2, mobData[this->getNumber()].aspd / 2, actor + 5, target, 0 );
	battle->setInputReady(FALSE);

}

int  BattleMob::getAction(void){
	return this->action;
}

int  BattleMob::getTarget(void){
	return this->target;
}

int  BattleMob::getHp(void){
	return this->hp;
}

void BattleMob::setHp( int volume ){
	this->hp -= volume;
}

char* BattleMob::getName(void){
	return mobData[this->number].name;
}

int  BattleMob::getNumber(void){
	return this->number;
}

BattleMob::~BattleMob(void){

	//���񂾎����ł���̂ł���Ɋւ��鏈��
}
