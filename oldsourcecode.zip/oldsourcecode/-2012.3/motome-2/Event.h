#pragma once

class Event{
private:
	int lifeTime;

public:
	static int eventStock;
	void virtual driven(void) = 0;
	void clear(void);
	void timeCount(void);
	Event(void);
	~Event(void);
};

class EventForword : public Event{

public:
	void driven(void);
};

class EventBack : public Event{

public:
	void driven(void);
};

class EventBattle : public Event{

private:

public:
	void driven(void);
};

class EventTrap : public Event{

public:
	void driven(void);
};

class EventRest : public Event{

public:
	void driven(void);
};