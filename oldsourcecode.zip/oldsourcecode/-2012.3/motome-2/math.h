/*--------------------
/math.cpp�w�b�_�t�@�C��
/
/-------------------*/

float absrand( float rand );
float rand( float rand );
int natural_num( int number );
void CharaStatusCalculate( int member_num );
