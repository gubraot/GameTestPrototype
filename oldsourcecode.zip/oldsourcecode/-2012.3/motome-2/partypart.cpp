/*--------------------
/�p�[�e�B�p�[�g�֌W�t�@�C��
/���̃t�@�C�����ĉ��H�p�[�e�B�p�[�g�Ɋ֌W����֐����܂Ƃ߂����́B
/-------------------*/

//�K�v�t�@�C���̃C���N���[�h
#include "Initalize.h"
#include "window.h"
#include "system.h"
#include "math.h"

int equipSelect( int x, int y, int category );
int Line2ListWindow( int x, int y, int paturn );

//�~�j�C���t�H(�_���W�����p)
void miniInfo(){

	//�ϐ���`
	static int pos = 200; //y���̃|�W�V����
	static int timepos = 200;

	//���W�ω�
	if( miniInfoDraw == 0 ){
		if( pos < 200 ){
			pos += 10;
		}else pos = 200;
	}else{
		if( pos > 0 ){
			pos /= 1.4;
			pos -= 1;
			if( pos < 0 ) pos = 0;
		}
	}

	//�\��(5�l��)
	for( int i = 0; i < 5; i++ ){
		if( Save_system.party[i] != -1 ){
			//��
			DrawExtendGraph( 20 + ( 125 * i ), 355 + pos, 116 + ( 125 * i ), 451 + pos, C_face[saveChara[Save_system.party[i]].face] , FALSE );
			//���O
			DrawFormatString( 10 + ( 125 * i ), 330 + pos, Color[0], "%s", saveChara[Save_system.party[i]].name );

			//�Q�[�W�֌W
			DrawCircleGauge( 68 + ( 125 * i ), 412 + pos, 62.5 + (( saveChara[Save_system.party[i]].hp / saveChara[Save_system.party[i]].HP ) * 37.5), SGuage[0] );
			DrawCircleGauge( 68 + ( 125 * i ), 412 + pos, (( saveChara[Save_system.party[i]].sp / saveChara[Save_system.party[i]].SP ) * 37.5), SGuage[1] );

			//HP��SP
			DrawFormatString( 9 + ( 125 * i ), 346 + pos, Color[16], "%d", saveChara[Save_system.party[i]].hp );
			DrawFormatInt( 129 + ( 125 * i ), 346 + pos, Color[17], saveChara[Save_system.party[i]].sp );
		}

		//�퓬���̂ݕ`�悷�����
		if( Run_part == 5 && Save_system.party[i] != -1 ){
			DrawBox( 17 + ( 125 * i ), 463, 121 + ( 125 * i ), 477, Color[18], FALSE );
			DrawBox( 19 + ( 125 * i ), 465, 19 + ( 125 * i ) + ( ( saveChara[Save_system.party[i]].act->getNowTime( 1 ) / float( saveChara[Save_system.party[i]].act->getMaxTime( 1 ) ) ) * 100 ), 475, Color[19], TRUE );
			if( saveChara[Save_system.party[i]].act->getPhase() == 0 ){
				DrawBox( 19 + ( 125 * i ), 465, 19 + ( 125 * i ) + ( ( saveChara[Save_system.party[i]].act->getNowTime( 0 ) / float( saveChara[Save_system.party[i]].act->getMaxTime( 0 ) ) ) * 100 ), 475, Color[18], TRUE );
			}
			if( battle->getInputChara() != i ){
				DrawFormatStringToHandle( 19 + (i * 125), 453, Color[18], Font[1], "%d", saveChara[Save_system.party[i]].act->getNowTime( 0 ) );
				DrawFormatStringToHandle( 80 + (i * 125), 453, Color[19], Font[1], "%d", saveChara[Save_system.party[i]].act->getNowTime( 1 ) );
			}
		}
	}

	//�`�掞�Ԃ̌���
	if( miniInfoDraw > 0 ){
		miniInfoDraw--;
	}

}

//�p�[�e�B�p�[�g�p�^�[�Q�b�g�I��
int pp_target(){

	//�ϐ���`
	static int selecting = 0;

	//�I�𒆂��l�p�̘g�ň݂͂܂�
	DrawBox( 180, 50 + ( selecting * 85 ), 600, 137 + ( selecting * 85 ), Color[5], FALSE );

	//���͎�t
	if( Keystate[KEY_INPUT_Z] == 1 ){
		int save_select = selecting;
		selecting = 0;
		return save_select;
	}else if( Keystate[KEY_INPUT_X] ){
		return -2;
	}else if( Keystate[KEY_INPUT_UP] == 1 ){
		if( selecting == 0 ){
			selecting = 4;
RETRY:
			if( Save_system.party[selecting] == -1 ){
				selecting--;
				goto RETRY;
			}
		}else{
			selecting--;
		}
	}else if( Keystate[KEY_INPUT_DOWN] == 1 ){
		if( selecting == 4 ){
			selecting = 0;
		}else{
			selecting++;
		}
	}
	return -1;
}

/*-----
�X�e�[�^�X���
-----*/
int draw_status( int member_num ){

	//�ϐ���`
	const char statusName[][10] = { "�@��","�̗�","����","��p","����","���_",
									"�U����","�h���","���@�U��","���@�h��","�U�����x","�W�����x","������","����","�K����"};

	//�\����
	Draw_window( 0, 640, 30, 350 );

	//�����Ƃ�
	info_window( 0, 0, "�L�����N�^�[�̏�Ԃ��ꗗ�\�����܂��BZ�L�[�Ń��j���[�ɖ߂�܂��B", 640, 1 );

	//��摜
	DrawExtendGraph( 32, 32, 128, 128, C_face[saveChara[Save_system.party[member_num]].face], TRUE );

	//���O
	DrawFormatString( 150, 40, Color[0], "%s", saveChara[Save_system.party[member_num]].name );
	DrawFormatString( 260, 40, Color[5], "���x��" );
	DrawFormatInt( 340, 40, Color[0], saveChara[Save_system.party[member_num]].lv );

	//hp,sp�Q�[�W
	DrawGraph( 160, 75, Guage[0], TRUE );
	SetDrawArea( 160, 75, 160 + ( 120 * ( saveChara[Save_system.party[member_num]].hp / float(saveChara[Save_system.party[member_num]].HP))),  115 );
	DrawGraph( 160, 75, Guage[1], TRUE );
	SetDrawArea( 196, 75, 196 + ( 70 * ( saveChara[Save_system.party[member_num]].sp / float(saveChara[Save_system.party[member_num]].SP))), 115 );
	DrawGraph( 160, 75, Guage[2], TRUE );
	SetDrawArea( 0, 0, 640, 480 );

	//hpsp�l
	DrawFormatInt( 240, 70, Color[0], saveChara[Save_system.party[member_num]].hp );
	DrawStringToHandle( 240, 70, "/", Color[0], Font[0] );
	DrawFormatInt( 280, 70, Color[0], int(saveChara[Save_system.party[member_num]].HP) );
	DrawFormatInt( 300, 88, Color[0], saveChara[Save_system.party[member_num]].sp );
	DrawStringToHandle( 300, 88, "/", Color[0], Font[0] );
	DrawFormatInt( 340, 88, Color[0], int(saveChara[Save_system.party[member_num]].SP) );

	//��b�X�e�[�^�X
	DrawFormatStringToHandle( 20, 130, Color[0], Font[1], "BaseStatus" );
	for( int i = 0; i < 6; i++ ){
		DrawFormatString( 20, 140 + ( i * 20 ), Color[3], "%s", statusName[i] );
		DrawFormatInt( 95, 140 + ( i * 20 ), Color[0], int(saveChara[Save_system.party[member_num]].basic_status[i + 2][1]) );
	}
	DrawFormatString( 20, 280, Color[1], "�琬Point" );
	DrawFormatInt( 95, 300, Color[0], int(saveChara[Save_system.party[member_num]].status_point) );

	//�����X�e�[�^�X
	DrawFormatStringToHandle( 120, 130, Color[0], Font[1], "EffectStatus" );
	DrawFormatString( 120, 140, Color[2], "%s", statusName[6] );
	DrawFormatString( 120, 160, Color[0], "%d�`%d: %d��", int(saveChara[Save_system.party[member_num]].status[0][0]), int(saveChara[Save_system.party[member_num]].status[1][0]), int(saveChara[Save_system.party[member_num]].status[2][0]) );
 
	for( int i = 0; i < 8; i++ ){
		DrawFormatString( 120, 180 + ( i * 20 ), Color[2], "%s", statusName[7 + i] );
		DrawFormatInt( 240, 180 + ( i * 20 ), Color[0], int( saveChara[Save_system.party[member_num]].status[3 + i][0] ) );
		//DrawFormatString( 240, 180 + ( i * 20 ), Color[0], "%d", int( saveChara[Save_system.party[member_num]].status[3 + i][0] ) );
	}

	//�����ϐ�
	DrawFormatStringToHandle( 270, 130, Color[0], Font[1], "ResistStatus" );
	for( int i = 0; i < 7; i++ ){
		DrawFormatString( 270, 140 + ( i * 20 ), Color[5], "%s", elementData[i].elementName );
		DrawFormatInt( 360, 140 + ( i * 20 ), Color[0], int( saveChara[Save_system.party[member_num]].element[i][1] ) );
	}

	//����A�h��A�X�s���b�g
	DrawFormatStringToHandle( 400, 46, Color[1], Font[1], "����" );
	//if( Save_chara[Save_system.party[member_num]].weapon != -1 ) DrawFormatString( 410, 110, Color[0], "%s", Item_matel[Save_item.weapon[Save_chara[menber_num].weapon_no][0]].name );
	DrawFormatStringToHandle( 400, 76, Color[1], Font[1], "�h��" );
	//if( Save_chara[Save_system.party[member_num]].armor != -1 ) DrawFormatString( 410, 130, Color[0], "%s", Item_armor[Save_item.armor[Save_chara[menber_num].armor_no][0]].name );
	DrawFormatStringToHandle( 400, 106, Color[1], Font[1], "�X�s���b�g" );
	//if( Save_chara[Save_system.party[member_num]].spilit != -1 ) DrawFormatString( 410, 150, Color[0], "%s", Item_spilit[Save_item.spilit[Save_chara[menber_num].spilit_no][0]].name );



	//�I�����}
	if( Keystate[KEY_INPUT_Z] == 1 ) return 1;

	//���s���Ԓl
	return 0;
}

//�L�����N�^�[�������
int status_up( int member_num ){

	//�ϐ���`
	const char statusName[][10] = { "�g�o","�r�o","�@��","�̗�","����","��p","����","���_",
									"�U����","�h���","���@�U��","���@�h��","�U�����x","�W�����x","������","����","�K����"};
	static int initFlag = 0;
	static int select = 0;
	static int stockdata[8];
	static int stockdata2[11];
	static int stockdata3;
	//�J�n���f�[�^�̈ꎞ�ۊ�
	if( initFlag == 0 ){
		for( int i = 0; i < 8; i++ ){
			stockdata[i] = saveChara[Save_system.party[member_num]].basic_status[i][0];		
		}
		for( int i = 0; i < 11; i++ ){
			stockdata2[i] = saveChara[Save_system.party[member_num]].status[i][0];
		}
		stockdata3 = saveChara[Save_system.party[member_num]].status_point;
		initFlag = 1;
	}

	//�\����
	Draw_window( 0, 360, 30, 130 );

	//�����Ƃ�
	info_window( 0, 0, "�|�C���g����Ő����B�㉺�I���A���E�C���AZ�Ō���BX�Ŏ��", 640, 1 );

	//��摜
	DrawExtendGraph( 32, 32, 128, 128, C_face[saveChara[Save_system.party[member_num]].face], TRUE );

	//���O
	DrawFormatString( 150, 40, Color[0], "%s", saveChara[Save_system.party[member_num]].name );
	DrawFormatString( 260, 40, Color[5], "���x��" );
	DrawFormatInt( 340, 40, Color[0], saveChara[Save_system.party[member_num]].lv );

	//hp,sp�Q�[�W
	DrawGraph( 160, 75, Guage[0], TRUE );
	SetDrawArea( 160, 75, 160 + ( 120 * ( saveChara[Save_system.party[member_num]].hp / float(saveChara[Save_system.party[member_num]].HP))),  115 );
	DrawGraph( 160, 75, Guage[1], TRUE );
	SetDrawArea( 196, 75, 196 + ( 70 * ( saveChara[Save_system.party[member_num]].sp / float(saveChara[Save_system.party[member_num]].SP))), 115 );
	DrawGraph( 160, 75, Guage[2], TRUE );
	SetDrawArea( 0, 0, 640, 480 );

	//hpsp�l
	DrawFormatInt( 240, 70, Color[0], saveChara[Save_system.party[member_num]].hp );
	DrawStringToHandle( 240, 70, "/", Color[0], Font[0] );
	if( int(saveChara[Save_system.party[member_num]].basic_status[0][0]) > stockdata[0] ){
		DrawFormatInt( 280, 70, Color[8], int(saveChara[Save_system.party[member_num]].HP) );
	}else{
		DrawFormatInt( 280, 70, Color[0], int(saveChara[Save_system.party[member_num]].HP) );
	}
	DrawFormatInt( 300, 88, Color[0], saveChara[Save_system.party[member_num]].sp );
	DrawStringToHandle( 300, 88, "/", Color[0], Font[0] );
	if( int(saveChara[Save_system.party[member_num]].basic_status[1][0]) > stockdata[1] ){
		DrawFormatInt( 340, 88, Color[8], int(saveChara[Save_system.party[member_num]].SP) );
	}else{
		DrawFormatInt( 340, 88, Color[0], int(saveChara[Save_system.party[member_num]].SP) );
	}
	DrawFormatString( 150, 100, Color[1], "�琬Point" );
	DrawFormatInt( 250, 100, Color[0], int(saveChara[Save_system.party[member_num]].status_point) );

	//�X�e�㏸���
	Draw_window( 10, 440, 150, 400 );

	//��b�X�e�[�^�X
	DrawFormatStringToHandle( 20, 150, Color[0], Font[1], "BaseStatus" );
	DrawFormatStringToHandle( 190, 150, Color[0], Font[1], "�K�v�|�C���g" );
	for( int i = 0; i < 8; i++ ){
		DrawFormatString( 20, 160 + ( i * 20 ), Color[3], "%s", statusName[i] );
		DrawFormatInt( 95, 160 + ( i * 20 ), Color[0], stockdata[i] );
		DrawFormatString( 110, 160 + ( i * 20 ), Color[5], "��" );
		if( stockdata[i] < int(saveChara[Save_system.party[member_num]].basic_status[i][0]) ){
			DrawFormatInt( 170, 160 + ( i * 20 ), Color[8], int(saveChara[Save_system.party[member_num]].basic_status[i][1]) );
		}else{
			DrawFormatInt( 170, 160 + ( i * 20 ), Color[0], int(saveChara[Save_system.party[member_num]].basic_status[i][1]) );
		}
		DrawFormatInt( 210, 160 + ( i * 20 ), Color[0], int(charaTypeData[saveChara[Save_system.party[member_num]].type].status[i][2]) );
		DrawFormatString( 210, 160 + ( i * 20 ), Color[5], "Points" );
		
	}

	//�����X�e�[�^�X
	DrawFormatStringToHandle( 310, 150, Color[0], Font[1], "EffectStatus" );
	DrawFormatString( 310, 160, Color[2], "%s", statusName[8] );
	//�U����
	if( saveChara[Save_system.party[member_num]].status[0][0] > stockdata2[0] || saveChara[Save_system.party[member_num]].status[1][0] > stockdata2[1] ){
		DrawFormatString( 310, 180, Color[8], "%d�`%d:", int(saveChara[Save_system.party[member_num]].status[0][0]), int(saveChara[Save_system.party[member_num]].status[1][0]) );
	}else{
		DrawFormatString( 310, 180, Color[0], "%d�`%d:", int(saveChara[Save_system.party[member_num]].status[0][0]), int(saveChara[Save_system.party[member_num]].status[1][0]) );
	}
	//�U����
	if( int(saveChara[Save_system.party[member_num]].status[2][0]) > stockdata2[2] ){
		DrawFormatInt( 420, 180, Color[8], saveChara[Save_system.party[member_num]].status[2][0] );
	}else{
		DrawFormatInt( 420, 180, Color[0], saveChara[Save_system.party[member_num]].status[2][0] );
	}
	DrawFormatString( 420, 180, Color[0], "��" );


	for( int i = 0; i < 8; i++ ){
		DrawFormatString( 310, 200 + ( i * 20 ), Color[2], "%s", statusName[9 + i] );
		if( i != 3 && i != 4 ){ //���x�ȊO�͍����ƐF�ύX
			if( int(saveChara[Save_system.party[member_num]].status[i + 3][0]) > stockdata2[i + 3] ){
				DrawFormatInt( 430, 200 + ( i * 20 ), Color[8], int( saveChara[Save_system.party[member_num]].status[i + 3][0] ) );
			}else{
				DrawFormatInt( 430, 200 + ( i * 20 ), Color[0], int( saveChara[Save_system.party[member_num]].status[i + 3][0] ) );
			}
		}else{ //���x�͒Ⴂ�ƐF�ύX
			if( int(saveChara[Save_system.party[member_num]].status[i + 3][0]) < stockdata2[i + 3] ){
				DrawFormatInt( 430, 200 + ( i * 20 ), Color[8], int( saveChara[Save_system.party[member_num]].status[i + 3][0] ) );
			}else{
				DrawFormatInt( 430, 200 + ( i * 20 ), Color[0], int( saveChara[Save_system.party[member_num]].status[i + 3][0] ) );
			}
		}
	}

	//����֌W�̉�ʔ��f
	//�g
	Draw_select( 15, 270, 159 + ( select * 20 ), 181 + ( select * 20 ) );
	//���͂̔��f
	if( Keystate[KEY_INPUT_DOWN] == 1 && 7 > select ){
		//���L�[
		select++;
	}else if( Keystate[KEY_INPUT_UP] == 1 && select > 0 ){
		//��L�[
		select--;
	}else if( Keystate[KEY_INPUT_RIGHT] == 1 && saveChara[Save_system.party[member_num]].status_point >= charaTypeData[saveChara[Save_system.party[member_num]].type].status[select][2] ){
		//�E�L�[:�l�̉��Z
		saveChara[Save_system.party[member_num]].basic_status[select][0]++;
		CharaStatusCalculate( Save_system.party[member_num] );
		saveChara[Save_system.party[member_num]].status_point -= charaTypeData[saveChara[Save_system.party[member_num]].type].status[select][2];
	}else if( Keystate[KEY_INPUT_LEFT] == 1 && saveChara[Save_system.party[member_num]].basic_status[select][0] > stockdata[select] ){
		//���L�[:�l�̌��Z
		saveChara[Save_system.party[member_num]].basic_status[select][0]--;
		CharaStatusCalculate( Save_system.party[member_num] );
		saveChara[Save_system.party[member_num]].status_point += charaTypeData[saveChara[Save_system.party[member_num]].type].status[select][2];
	}else if( Keystate[KEY_INPUT_Z] == 1 ){
		//Z�L�[:�l�̌���Ɣ��f
		initFlag = 0;
		select = 0;
		return 1;
	}else if( Keystate[KEY_INPUT_X] == 1 ){
		//X�L�[:������
		initFlag = 0;
		select = 0;
		for( int i = 0; i < 8; i++ ){
			saveChara[Save_system.party[member_num]].basic_status[i][0] = stockdata[i];
		}
		CharaStatusCalculate( Save_system.party[member_num] );
		saveChara[Save_system.party[member_num]].status_point = stockdata3;
		return 1;
	}

	//���s���Ԓl
	return 0;
}

//�����ύX��ʊ֌W

//�����̍s�\���n
void weaponDrawString( int x, int y, int weapon ){
	if( weapon == -1 ){
		DrawFormatString( x, y, Color[0], "�Ȃ�" );
	}else{
		DrawFormatString( x, y, Color[0], saveItemWeapon[weapon].name );
	}
}

void armorDrawString( int x, int y, int armor ){
	if( armor == -1 ){
		DrawFormatString( x, y, Color[0], "�Ȃ�" );
	}else{
		DrawFormatString( x, y, Color[0], saveItemArmor[armor].name );
	}
}

void wjuelDrawString( int x, int y, int wjuel ){
	if( wjuel == -1 ){
		DrawFormatString( x, y, Color[0], "�Ȃ�" );
	}else{
		//DrawFormatString( x, y, Color[0], saveItemArmor[armor].name );
	}
}

//�ύX�����I��
int equipChange( int member_num ){

	//�ϐ���`
	const char statusName[][10] = { "�g�o","�r�o","�@��","�̗�","����","��p","����","���_",
									"�U����","�h���","���@�U��","���@�h��","�U�����x","�W�����x","������","����","�K����"};
	const char elementDef[][10] = { "�Αϐ�", "���ϐ�", "�n�ϐ�", "���ϐ�", "���ϐ�", "�őϐ�", "���ϐ�" };
	const char slotstring[][20] = { "����", "�h��", "�X�s���b�g", "����X���b�g", "", "", "", "", "", "", "", "�h��X���b�g", "", "", "", "" };

	static int initFlag = 0;
	static int select[2] = {0, 0};
	static int category;
	static int section = 0;
	static int stockequip[16];
	static int stockdata[8];
	static int stockdata2[11];

	//�J�n���f�[�^�̈ꎞ�ۊ�
	if( initFlag == 0 ){
		section = 0;
		for( int i = 0; i < 8; i++ ){
			stockdata[i] = int(saveChara[Save_system.party[member_num]].basic_status[i][0]);		
		}
		for( int i = 0; i < 11; i++ ){
			stockdata2[i] = int(saveChara[Save_system.party[member_num]].status[i][0]);
		}
		stockequip[0] = saveChara[Save_system.party[member_num]].weapon;
		stockequip[1] = saveChara[Save_system.party[member_num]].armor;
		stockequip[2] = saveChara[Save_system.party[member_num]].spilit;
		for( int i = 0; i < 8; i++ ){
			stockequip[i + 3] = saveChara[Save_system.party[member_num]].w_juel[i];
		}
		for( int i = 0; i < 5; i ++ ){
			stockequip[i + 11] = saveChara[Save_system.party[member_num]].a_juel[i];
		}
		initFlag = 1;
	}

	//�\����1
	Draw_window( 0, 140, 30, 150 );


	//�����Ƃ�
	info_window( 0, 0, "�����̕ύX�B�㉺�I���AZ�Ō���BX�ŏI���B", 640, 1 );

	//��摜
	DrawExtendGraph( 12, 32, 108, 128, C_face[saveChara[Save_system.party[member_num]].face], TRUE );

	//���O
	DrawFormatString( 10, 130, Color[0], "%s", saveChara[Save_system.party[member_num]].name );

	//�I����ʂ̒��g��`��
	switch( section ){
		case 0://������ԉ��
			Draw_window( 0, 260, 150, 480 );
			for( int i = 0; i < 13; i++ ){
				DrawFormatStringToHandle( 10, 149 + (i * 20), Color[1], Font[1], slotstring[i] );
				switch( i ){
					case 0:
						weaponDrawString( 10, 155 + (i * 20), saveChara[Save_system.party[member_num]].weapon );
						break;

					case 1:
						armorDrawString( 10, 155 + (i * 20), saveChara[Save_system.party[member_num]].armor );
						break;

					default:
						break;
				}
			}

			//�Z���N�g�g
			Draw_select( 0, 258, 154 + (select[0] * 20), 176 + (select[0] * 20) );

			//���͎�t
			if( Keystate[KEY_INPUT_Z] == 1 ){
				switch( select[0] ){
					case 0:
						category = 0;
						break;

					case 1:
						category = 1;
						break;

					case 2:
						category = 2;
						break;

					default:
						category = 4;
				}
				section++;
			}else if( Keystate[KEY_INPUT_X] == 1 ){
				return 1;
			}else if( Keystate[KEY_INPUT_UP] == 1 && select[0] > 0 ){
				select[0]--;
			}else if( Keystate[KEY_INPUT_DOWN] == 1 && select[0] < 15 ){
				select[0]++;
			}
			break;

		case 1: //�����I�����
			switch( equipSelect( 0, 150, category ) ){
				case -1://�L�����Z�����ꂽ��
					//�ύX���ꂽ�f�[�^�����ɖ߂�
					saveChara[Save_system.party[member_num]].weapon = stockequip[0];
					saveChara[Save_system.party[member_num]].armor = stockequip[1];
					saveChara[Save_system.party[member_num]].spilit = stockequip[2];
					for( int i = 0; i < 8; i++ ){
						saveChara[Save_system.party[member_num]].w_juel[i] = stockequip[i + 3];
					}
					for( int i = 0; i < 5; i ++ ){
						saveChara[Save_system.party[member_num]].a_juel[i] = stockequip[i + 11];
					}
					CharaStatusCalculate( Save_system.party[member_num] );
					initFlag = 0;
					break;

				case 0://�I������Ă��Ȃ���
					switch( select[0] ){
						case 0:
							if( saveChara[Save_system.party[member_num]].weapon != list[SelectNow][0] ){
								saveChara[Save_system.party[member_num]].weapon = list[SelectNow][0];
								CharaStatusCalculate( Save_system.party[member_num] );
							}
							break;

						case 1:
							if( saveChara[Save_system.party[member_num]].armor != list[SelectNow][0] ){
								saveChara[Save_system.party[member_num]].armor = list[SelectNow][0];
								CharaStatusCalculate( Save_system.party[member_num] );
							}
							break;

						case 2:
							if( saveChara[Save_system.party[member_num]].spilit != list[SelectNow][0] ){
								saveChara[Save_system.party[member_num]].spilit = list[SelectNow][0];
								CharaStatusCalculate( Save_system.party[member_num] );
							}
							break;

						default:
							if( select[0] < 11 ){
								if( saveChara[Save_system.party[member_num]].w_juel[select[0] - 3] != list[SelectNow][0] ){
									saveChara[Save_system.party[member_num]].w_juel[select[0] - 3] = list[SelectNow][0];
									CharaStatusCalculate( Save_system.party[member_num] );
								}
							}else{
								if( saveChara[Save_system.party[member_num]].a_juel[select[0] - 11] != list[SelectNow][0] ){
									saveChara[Save_system.party[member_num]].a_juel[select[0] - 11] = list[SelectNow][0];
									CharaStatusCalculate( Save_system.party[member_num] );
								}
							}
							break;
					}
					break;

				case 1://���肳�ꂽ��
					switch( select[0] ){
						case 0:
							saveItemWeapon[list[SelectNow][0]].usingChara = Save_system.party[member_num];
							if( stockequip[0] != -1 ){
								saveItemWeapon[stockequip[0]].usingChara = -1;
							}
							break;

						case 1:
							saveItemArmor[list[SelectNow][1]].usingChara = Save_system.party[member_num];
							if( stockequip[1] != -1 ){
								saveItemArmor[stockequip[1]].usingChara = -1;
							}
							break;

						case 2:
							//saveChara[Save_system.party[member_num]].spilit = list[SelectNow][0];
							break;

						default:
							if( select[0] < 11 ){
								//saveChara[Save_system.party[member_num]].w_juel[select[0] - 3] = list[SelectNow][0];
							}else{
								//saveChara[Save_system.party[member_num]].a_juel[select[0] - 11] = list[SelectNow][0];
							}
							break;
					}
					initFlag = 0;
					break;

			}
	}


	//�X�e�[�^�X�\�����
	Draw_window( 280, 600, 150, 460 ); 
	//��b�X�e�[�^�X
	DrawFormatStringToHandle( 290, 150, Color[0], Font[1], "BaseStatus" );
	for( int i = 0; i < 8; i++ ){
		DrawFormatString( 290, 160 + ( i * 20 ), Color[3], "%s", statusName[i] );
		DrawFormatInt( 380, 160 + ( i * 20 ), Color[0], stockdata[i] );		
	}
	//�ϐ�
	for( int i = 0; i < 7; i++ ){
		DrawFormatString( 290, 320 + (i * 20), Color[1], elementDef[i] );
		DrawFormatInt( 380, 320 + (i * 20), Color[0], saveChara[Save_system.party[member_num]].element[i][1] );
	}

	//�����X�e�[�^�X
	DrawFormatStringToHandle( 450, 150, Color[0], Font[1], "EffectStatus" );
	DrawFormatString( 450, 160, Color[2], "%s", statusName[8] );
	//�U����
	if( saveChara[Save_system.party[member_num]].status[0][0] > stockdata2[0] || saveChara[Save_system.party[member_num]].status[1][0] > stockdata2[1] ){
		DrawFormatString( 450, 180, Color[8], "%d�`%d:", int(saveChara[Save_system.party[member_num]].status[0][0]), int(saveChara[Save_system.party[member_num]].status[1][0]) );
	}else if( saveChara[Save_system.party[member_num]].status[0][0] < stockdata2[0] || saveChara[Save_system.party[member_num]].status[1][0] < stockdata2[1] ){
		DrawFormatString( 450, 180, Color[1], "%d�`%d:", int(saveChara[Save_system.party[member_num]].status[0][0]), int(saveChara[Save_system.party[member_num]].status[1][0]) );
	}else{
		DrawFormatString( 450, 180, Color[0], "%d�`%d:", int(saveChara[Save_system.party[member_num]].status[0][0]), int(saveChara[Save_system.party[member_num]].status[1][0]) );
	}
	//�U����
	if( int(saveChara[Save_system.party[member_num]].status[2][0]) > stockdata2[2] ){
		DrawFormatInt( 560, 180, Color[8], saveChara[Save_system.party[member_num]].status[2][0] );
	}else if( int(saveChara[Save_system.party[member_num]].status[2][0]) < stockdata2[2] ){
		DrawFormatInt( 560, 180, Color[8], saveChara[Save_system.party[member_num]].status[2][0] );
	}else{
		DrawFormatInt( 560, 180, Color[0], saveChara[Save_system.party[member_num]].status[2][0] );
	}
	DrawFormatString( 560, 180, Color[0], "��" );


	for( int i = 0; i < 8; i++ ){
		DrawFormatString( 450, 200 + ( i * 20 ), Color[2], "%s", statusName[9 + i] );
		if( i != 3 && i != 4 ){ //���x�ȊO�͍����ƐF�ύX
			if( int(saveChara[Save_system.party[member_num]].status[i + 3][0]) > stockdata2[i + 3] ){
				DrawFormatInt( 560, 200 + ( i * 20 ), Color[8], int( saveChara[Save_system.party[member_num]].status[i + 3][0] ) );
			}else if( int(saveChara[Save_system.party[member_num]].status[i + 3][0]) < stockdata2[i + 3] ){
				DrawFormatInt( 560, 200 + ( i * 20 ), Color[1], int( saveChara[Save_system.party[member_num]].status[i + 3][0] ) );
			}else{
				DrawFormatInt( 560, 200 + ( i * 20 ), Color[0], int( saveChara[Save_system.party[member_num]].status[i + 3][0] ) );
			}
		}else{ //���x�͒Ⴂ�ƐF�ύX
			if( int(saveChara[Save_system.party[member_num]].status[i + 3][0]) < stockdata2[i + 3] ){
				DrawFormatInt( 560, 200 + ( i * 20 ), Color[8], int( saveChara[Save_system.party[member_num]].status[i + 3][0] ) );
			}else if( int(saveChara[Save_system.party[member_num]].status[i + 3][0]) > stockdata2[i + 3] ){
				DrawFormatInt( 560, 200 + ( i * 20 ), Color[1], int( saveChara[Save_system.party[member_num]].status[i + 3][0] ) );
			}else{
				DrawFormatInt( 560, 200 + ( i * 20 ), Color[0], int( saveChara[Save_system.party[member_num]].status[i + 3][0] ) );
			}
		}
	}
	return 0;
}

//�p�[�e�B�p�[�g����{��
void party_part(){

	//�ϐ���`
	static int pos[5] = { 0, 0, 0, 0, 0 };
	static int status_character = 0;
	static int Command = 0;
	static int character = -1;
	static int status_anime = 0;
	static int save_item[3] = { 0, -2, -1 };

	//�萔��`
	char spotmes[][128] = { "�X�e�[�^�X�̊m�F�����܂��B",
							"�X�e�[�^�X�|�C���g���g���ăX�e�[�^�X���㏸���܂��B",
							"����A�C�e�����g�p���܂��B",
							"�������Ă���A�C�e�����m�F���܂��B",
							//"�����X�L���̊m�F�A�X�L�����g�p���܂��B",
							//"�e�����o�̑�����ύX���܂��B",
							"���̉�ʂɖ߂�܂��B"};

	//C�Ń��j���[�Ăяo�����I��
	if( Keystate[KEY_INPUT_C] == 1 ){
		if( partyDraw == 0 ){
			partyDraw = 1;
		}else if( partyDraw == 1 && Command == 0 ){
			partyDraw = 0;
		}
	}

	//�p�[�e�B��Ԃ̕\��
	//�A�j����Ԑ���
	if( partyDraw == 1 ){
		status_anime++;
		if( status_anime > 30 ) status_anime = 30;
	}else{
		status_anime -= 5;
		if( status_anime < 0 ) status_anime = 0;
	}

	//�A�j������
	for( int i = 0; i < 5; i++ ){
		if( partyDraw == 0 ){
			if( pos[i] < 800 ){
				pos[i] += 100;
			}else pos[i] = 800;
		}else{
			if( pos[i] > 0 && status_anime > i * 2 ){
				pos[i] /= 1.6;
				pos[i] -= 1;
				if( pos[i] < 0 ) pos[i] = 0;
			}
		}
	}

	//�\������
	if( status_anime > 0 ){

		//5�l��
		for( int i = 0; i < 5; i++ ){
			if( Save_system.party[i] != -1 ){
				//��
				DrawRectGraph( 180 + pos[i], 50 + ( i * 85 ), 5, 5, 86, 86, C_face[saveChara[Save_system.party[i]].face], TRUE, FALSE );

				//���O
				DrawFormatString( 270 + pos[i], 60 + ( i * 85 ), Color[0], "%s", saveChara[Save_system.party[i]].name );

				//hp,sp�Q�[�W
				DrawGraph( 260 + pos[i], 85 + ( i * 85 ), Guage[0], TRUE );
				SetDrawArea( 260 + pos[i], 85 + ( i * 85 ), 260 + ( 120 * ( saveChara[Save_system.party[i]].hp / float(saveChara[Save_system.party[i]].HP))) + pos[i],  115 + ( i * 85 ) );
				DrawGraph( 260 + pos[i], 85 + ( i * 85 ), Guage[1], TRUE );
				SetDrawArea( 296 + pos[i], 85 + ( i * 85 ), 296 + ( 70 * ( saveChara[Save_system.party[i]].sp / float(saveChara[Save_system.party[i]].SP))) + pos[i], 115 + ( i * 85  ) );
				DrawGraph( 260 + pos[i], 85 + ( i * 85 ), Guage[2], TRUE );
				SetDrawArea( 0, 0, 640, 480 );

				//hpsp�l
				DrawFormatInt( 340 + pos[i], 80 + ( i * 85 ), Color[0], saveChara[Save_system.party[i]].hp );
				DrawStringToHandle( 340 + pos[i], 80 + ( i * 85 ), "/", Color[0], Font[0] );
				DrawFormatInt( 380 + pos[i], 80 + ( i * 85 ), Color[0], int(saveChara[Save_system.party[i]].HP) );
				DrawFormatInt( 390 + pos[i], 103 + ( i * 85 ), Color[0], saveChara[Save_system.party[i]].sp );
				DrawStringToHandle( 390 + pos[i], 103 + ( i * 85 ), "/", Color[0], Font[0] );
				DrawFormatInt( 430 + pos[i], 103 + ( i * 85 ), Color[0], int(saveChara[Save_system.party[i]].SP) );

				//lv,exp
				SetDrawArea( 450 + pos[i], 112 + ( i * 85 ), 450 + pos[i] + ( 100 * ( saveChara[Save_system.party[i]].exp / float( exp_table[saveChara[Save_system.party[i]].lv] ))), 122 + ( i * 85 ) );
				DrawGraph( 450 + pos[i], 112 + ( i * 85 ), MiniGuage[1], FALSE );
				SetDrawArea( 0, 0, 640, 480 );
				DrawBox( 450 + pos[i], 112 + ( i * 85 ), 550 + pos[i], 122 + ( i * 85 ), Color[7], FALSE );
				
				DrawFormatString( 450 + pos[i], 95 + ( i * 85 ), Color[0], "Lv:      ��%d", ( exp_table[saveChara[Save_system.party[i]].lv] - saveChara[Save_system.party[i]].exp ) );
				DrawFormatString( 480 + pos[i], 95 + ( i * 85 ), Color[5], "%d", saveChara[Save_system.party[i]].lv );

				


			}
		}
		//����
		DrawString( 455, 35, "Money:          �e�B��", Color[1] );
		DrawFormatInt( 570, 35, Color[0], Save_system.money );
	}
	if( partyDraw == 1 ){
		//�R�}���h
		switch( Command ){
			case 0: //�I��
				Command = manu_draw_y( 0, 150, 150, 4, "�X�e�[�^�X", "SP����", "�����ύX", "�A�C�e���g�p", "�����i�m�F", "�߂�" );
				break;

			case 1: //�X�e�[�^�X
				switch( character ){
					case -2://�L�����Z��
						character = -1;
						Command = 0;
						break;
					case -1://�I��
						character = pp_target();
						break;

					default://�I���ς�
						if( draw_status( character ) == 1 ){
							character = -1;
							Command = 0;
						}
				}
				break;

			case 2: //����
				switch( character ){
					case -2://�L�����Z��
						character = -1;
						Command = 0;
						break;

					case -1://�I��
						character = pp_target();
						break;

					default://�I���ς�
						if( status_up( character ) == 1 ){
							character = -1;
							Command = 0;
						}
				}
				break;

			case 3: //�����ύX
				switch( character ){
					case -2://�L�����Z��
						character = -1;
						Command = 0;
						break;

					case -1://�I��
						character = pp_target();
						break;

					default://�I���ς�
						if( equipChange( character ) == 1 ){
							character = -1;
							Command = 0;
						}
				}
				break;

			case 4: //�A�C�e��
				switch( save_item[0] ){
					case 0://���X�g����
						save_item[0]++;
						getListItemUse();
					case 1://�I��
						if( listMax == 0 ){
							if( message_window( 150, 200, "�g����A�C�e��������܂���", 300 ) == 1 ){
								Command = 0;
								save_item[0] = 0;
								save_item[1] = -2;
								break;
							}else{
								break;
							}
						}
						save_item[1] = Line2ListWindow( 90, 150, 0 );
						switch( save_item[1] ){
							case -2://�I��
								break;

							case -1://�L�����Z��
								Command = 0;
								save_item[0] = 0;
								save_item[1] = -2;
								break;

							default://�I������
								save_item[0]++;
						}
						break;
						
					case 2://�Ώۂ̑I��
						switch( save_item[2] ){
							case -2://�L�����Z��
								save_item[2] = -1;
								save_item[0] = 0;
								break;

							case -1://�I��
								save_item[2] = pp_target();
								break;

							default://�I������
								//�A�C�e���g�p�������{���Ȃ񂽂�
								if( partyItemUse( save_item[1], save_item[2] ) == -1 ){
									//���ʃA�C�e�����Ȃ��Ȃ�����
									save_item[2] = -2;
								}else{
									save_item[2] = -1;
								}
								break;
						}
				}
				break; 

			case 5: //�����A�C�e���m�F

			case 6: //�߂�
				Command = 0;
				partyDraw = 0;
		}
	}

}