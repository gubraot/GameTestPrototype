#pragma once

//���C�x���g�������̈ڐA
//���b�Z�[�W���M��������֌W�ɂ܂Ƃ߂ĔC���邱�Ƃɂ���
class Cue{

private:
	int  needCount;
	int  count;
	bool runEnd;

public:
	static int stock;
	bool needKey;

	void switchRunEnd(void);
	bool getRunEnd(void);
	bool countup(void);
	Cue(bool needKey, int needCount);
	virtual void running(void) = 0;
	virtual ~Cue(void);
};

//ForwordCue
class ForwordCue : public Cue{

private:

public:
	ForwordCue(void);
	~ForwordCue(void);
	void running(void);
};

//ResultCue
class ResultCue : public Cue{

private:
	int getExp;
	int getMoney;

public:
	ResultCue(void);
	~ResultCue(void);
	void running(void);
};

//FailedCue
class FailedCue : public Cue{

private:

public:
	FailedCue(void);
	~FailedCue(void);
	void running(void);
};

//levelupCue
class LevelupCue : public Cue{

private:
	char sendmes[100];
	int  character; 

public:
	LevelupCue( int character );
	void running(void);
	
};

//messageCue
class MessageCue : public Cue{

private:
	char sendmes[100];

public:
	MessageCue(char *sendmes, bool needKey, int needCount);
	void running(void);
};

//addDamageCue
class AddDamageCue : public Cue{

private:
	int damage;
	int target;
	int group;

public:
	AddDamageCue( int dmg_vol, int target, int group, bool needKey, int needCount );
	void running(void);
};