void mes_send( char *sendmes, bool needKey );
void mes_order();
void D_mes_draw();
void addEvent( int eventNum );
void deleteEvent();
void mes_alldelete();
void addDamage( int dmg_vol, int target, int group );
void addHealHp( int heal_vol, int target, int group );

void createMessageCue(char *sendmes, bool needKey, int needCount, int addPosition);
void createAddDamageCue( int dmg_vol, int target, int group, bool needKey, int needCount, int addPosition );
void createResultCue(void);
void createFailedCue(void);
void createForwordCue(void);
void createLevelupCue( int character );

void cue_main();
