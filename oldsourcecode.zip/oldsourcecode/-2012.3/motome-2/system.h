
void DrawFormatInt( int x, int y, int color, int integer );
void Keycontrol();
void Mousecontrol();
void system_process();
void deleteEffect( int adless );
void addEffect( int effectNum, int x, int y, int propaty );
void effect_main();
void getListItemUse(void);
int  characterListSelect( int sort );

int  partyItemUse(int itemNum, int partynum);
void battleItemUse(int itemNum, int targetnum, int party);

void itemInfoString( int itemNum, int x, int y );
void weaponInfoString( int itemNum, int x, int y );
void weaponInfoStringTake( int itemNum, int x, int y );
void armorInfoString( int itemNum, int x, int y );
void armorInfoStringTake( int itemNum, int x, int y );