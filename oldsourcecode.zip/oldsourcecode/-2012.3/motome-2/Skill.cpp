#include "Skill.h"
#include "Cue.h"
#include "initalize.h"
#include "dungeonpart.h"
#include "battlepart.h"
#include "system.h"

Skill::Skill( int skillNum, int group, int target ){
	this->sp = skillData[skillNum].sp;
	this->effect[0] = skillData[skillNum].effect[0];
	this->effect[1] = skillData[skillNum].effect[1];

	strcpy( this->actionstring, skillData[skillNum].lunchString );

	this->group = group;
	this->target = target;
}

//�ʏ�X�L���ȊO�̃R���X�g���N�^
Skill::Skill( int Num, int group, int category, int target ){
	switch( category ){
		case 0:
			this->effect[0] = Num;
			break;
	}

	this->group = group;
	this->target = target;
}


//usingitemskill�֌W
Skill::~Skill(void){
}

UsingItemSkill::UsingItemSkill( int Num, int group, int target ) : Skill( Num, group, 0, target ){
}

void UsingItemSkill::lunchSkill(void){
	int party = 0;
	int tparty = 0;
	if( this->group > 4 ){
		party = 1;
		this->group -= 5;
	}
	if( this->target > 4 ){
		tparty = 1;
		this->target -= 5;
	}

	char str[100];

	strcpy( str, saveChara[Save_system.party[group]].name );
	strcat( str, "��" );
	strcat( str, itemDataUse[this->effect[0]].name );
	strcat( str, "���g�����I" );
	createMessageCue( str, FALSE, 30, 0 );
	battleItemUse( this->effect[0], this->target, party );
}


//AttackDamageSkill�֌W
AttackDamageSkill::AttackDamageSkill( int skillNum, int group, int target ): Skill( skillNum, group, target ){
}

void AttackDamageSkill::lunchSkill(void){

	int i = 0;
	int party = 0;
	int tparty = 0;
	if( this->group > 4 ){
		party = 1;
		this->group -= 5;
	}
	if( this->target > 4 ){
		tparty = 1;
		this->target -= 5;
		//�Ώۂ����łɎ��񂾂肵�Ă��Ȃ��ꍇ
		while( 1 ){
			if( monster[this->target].useflag == TRUE ){
				break;
			}else if( i == 100 ){
				this->target = -1;
				break;
			}
			this->target = GetRand( 4 );
			i++;
		}
	}else{
		//�Ώۂ����łɎ��񂾂肵�Ă��Ȃ��ꍇ
		while( 1 ){
			if( Save_system.party[this->target] != -1 && saveChara[Save_system.party[this->target]].hp > 0 ){
				break;
			}else if( i == 100 ){
				this->target = -1;
				break;
			}
			this->target = GetRand( 4 );
		}
	}

	char str[100];
	char numstr[10];

	if( party == 0 ){
		strcpy( str, saveChara[Save_system.party[group]].name );
	}else{
		strcpy( str, mobData[monster[group].mobObj->getNumber()].name );
	}
	strcat( str, this->actionstring );
	createMessageCue( str, TRUE, 0, 0 );
	int atk = calcNormalAttack( party, this->group, this->effect[0] );
	int def = calcNormalDefence( tparty, this->target );
	int dmg = atk - def;
	if( dmg < 0 ) dmg = 1;

	if( hitJudge( party, this->group, tparty, this->target ) == 1 ){ 
		createAddDamageCue( dmg, this->target, tparty, FALSE, 30, 0 );
		return;
	}
}
