#pragma once

class CommandPalet
{

private:
	int member;
	int selectCommand;
	int time;
	int saveItem[3];

public:
	//�z��s�����Ԃ̕\��
	void simulateTimeDraw( int skillnum ); 

	//��b�p���b�g��
	int  paletProc(void);
	void mainPalet(void);
	int  itemPalet(void);
	void skillPalet(void);
	void partyPalet(void);
	int battleSelect( int initfanc );
	CommandPalet( int member );
	~CommandPalet(void);
};
