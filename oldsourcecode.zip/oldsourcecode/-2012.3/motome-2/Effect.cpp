#include "Effect.h"
#include "initalize.h"
#include <Dxlib.h>

//�ÓI�����o�ϐ��̎���
int Effect::stockEffect = 0;

Effect::Effect( int x, int y ) : positionX(x), positionY(y), lifeTime(0){
	adless = stockEffect;
	Effect::stockEffect++;
}

Effect::~Effect(void){
	Effect::stockEffect--;
}

void Effect::Clear(void){
	deleteEffect( this->adless );
}

int Effect::getLifeTime(void){
	return this->lifeTime;
}

void Effect::countLifeTime(void){
	this->lifeTime++;
}

int Effect::getPositionX(void){
	return this->positionX;
}

int Effect::getPositionY(void){
	return this->positionY;
}

void Effect::setAdless( int adless ){
	this->adless = adless;
}

//EffectDamageNum class

EffectDamageNum::EffectDamageNum( int x, int y, int number ) : Effect( x, y ){
	this->number = number;
	this->alpha = 0;
}

void EffectDamageNum::Draw(void){

	if( this->getLifeTime() < 6 ){
		DrawFormatStringToHandle( this->getPositionX(), this->getPositionY() - (( this->getLifeTime() % 3 ) * 5 ), Color[0], Font[3], "%d", number );
	}else{
		SetDrawBlendMode( DX_BLENDMODE_ALPHA, 255 - alpha );
		DrawFormatStringToHandle( this->getPositionX(), this->getPositionY(), Color[0], Font[3], "%d", number );
		SetDrawBlendMode( DX_BLENDMODE_NOBLEND, 0 );
		alpha += 15;
	}

	this->countLifeTime();

	if( alpha > 255 ){
		this->Clear();
	}
}

//EffectHealHpNum class

EffectHealHpNum::EffectHealHpNum( int x, int y, int number ) : Effect( x, y ), yAdd(0){
	this->number = number;
	this->alpha = 0;
}

void EffectHealHpNum::addYAdd(int addY){
	this->yAdd += addY;
}

void EffectHealHpNum::Draw(void){

	this->addYAdd( 10 - (this->getLifeTime() / 2) );
	
	SetDrawBlendMode( DX_BLENDMODE_ALPHA, 255 - alpha );
	DrawFormatStringToHandle( this->getPositionX(), this->getPositionY() - yAdd, Color[14], Font[3], "%d", number );
	SetDrawBlendMode( DX_BLENDMODE_NOBLEND, 0 );

	if( this->getLifeTime() > 20 ){
		alpha += 15;
	}

	this->countLifeTime();

	if( alpha > 255 ){
		this->Clear();
	}
}

//EffectHealSpNum class
EffectHealSpNum::EffectHealSpNum( int x, int y, int number ) : Effect( x, y ), yAdd(0){
	this->number = number;
	this->alpha = 0;
}

void EffectHealSpNum::addYAdd(int addY){
	this->yAdd += addY;
}

void EffectHealSpNum::Draw(void){

	this->addYAdd( 10 - (this->getLifeTime() / 2) );
	
	SetDrawBlendMode( DX_BLENDMODE_ALPHA, 255 - alpha );
	DrawFormatStringToHandle( this->getPositionX(), this->getPositionY() - yAdd, Color[15], Font[3], "%d", number );
	SetDrawBlendMode( DX_BLENDMODE_NOBLEND, 0 );

	if( this->getLifeTime() > 20 ){
		alpha += 15;
	}

	this->countLifeTime();

	if( alpha > 255 ){
		this->Clear();
	}
}

//EffectLevelup
EffectLevelup::EffectLevelup( int x, int y, int level ) : Effect( x, y ){
	this->level = level;
	this->alpha = 0;
}

void EffectLevelup::Draw(void){

	SetDrawBlendMode( DX_BLENDMODE_ALPHA, 255 - alpha );
	DrawFormatStringToHandle( this->getPositionX(), this->getPositionY(), Color[0], Font[3], "LevelUP!��Lv%d", this->level );
	SetDrawBlendMode( DX_BLENDMODE_NOBLEND, 0 );

	this->countLifeTime();
	
	if( this->getLifeTime() > 60 ){
		alpha += 5;
		if( alpha > 260 ){
			this->Clear();
		}
	}
}

