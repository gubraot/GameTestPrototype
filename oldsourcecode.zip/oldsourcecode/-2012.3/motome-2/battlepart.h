int calcNormalAttack( int group, int attackuser, int skillrate );
int calcMagicAttack( int group, int attackuser, int skillrate );
int calcNormalDefence( int group, int defenceuser );
int calcMagicDefence( int group, int defenceuser );
int hitJudge( int attackgroup, int attackuser, int defencegroup, int defenceuser );
