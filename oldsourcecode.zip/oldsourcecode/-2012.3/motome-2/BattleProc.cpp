#include "BattleProc.h"
#include "initalize.h"
#include "dungeonpart.h"
#include <Dxlib.h>

BattleProc::BattleProc( int paturn ){

	int pop = 1 + GetRand( 4 );
	int number = dungeon->getMonster();
	//�k������
	for( int i = 0; i < 5; i++ ){
		monster[i].mobObj = NULL;
		monster[i].useflag = FALSE;
	}
	//�G�̓o�^
	switch( paturn ){
		case -1: //��A�h�o���e�[�W�퓬
		case 0: //�ʏ�
		case 1: //�A�h�o���e�[�W�퓬
			for( int i = 0; i < pop; i++ ){
				number = dungeon->getMonster();
				monster[i].mobObj = new BattleMob( number, paturn );
				monster[i].useflag = TRUE;
				mes_send( "�����X�^�[�������ꂽ�I", FALSE );
			}
			break;
		case 2: //�{�X�퓬
			break;
		case 3: //����퓬
			break;
	}
	//�p�[�e�B�̏����l�Z�b�g
	for( int i = 0; i < 5; i++ ){
		if( Save_system.party[i] != -1 ){
			switch( paturn ){
				case -1: //��A�h�o���e�[�W�퓬				
					saveChara[Save_system.party[i]].act = new Action( saveChara[Save_system.party[i]].status[6][0] );
					break;
				case 0: //�ʏ�
					saveChara[Save_system.party[i]].act = new Action( 100 );
					saveChara[Save_system.party[i]].act = new Action( GetRand( 100 ) );
					break;
				case 1: //�A�h�o���e�[�W�퓬
					saveChara[Save_system.party[i]].act = new Action( 1 );
					break;
				case 2: //�{�X�퓬
					break;
				case 3: //����퓬
					break; 
			}
		}
	}

	//�I�u�W�F�N�g�����l�̃Z�b�g
	this->plusExp = 0;
	this->plusMoney = 0;
	this->battleTime = 0;
	this->inputChara = -1;
	this->inputReady = FALSE;
	this->skillUsed  = FALSE;
	dungeon->setBattleflag( TRUE );

	//�K��l�̃Z�b�g������
	paret = NULL;
}

void BattleProc::setInputReady( bool set ){
	this->inputReady = set; 
}

bool BattleProc::getInputReady(void){
	return this->inputReady;
}

void BattleProc::countBattleTime( int count ){
	this->battleTime += count;
}

int BattleProc::getBattleTime(void){
	return this->battleTime;
}

void BattleProc::addMoney( int volume ){
	this->plusMoney += volume;
}

int BattleProc::getMoney(void){
	return this->plusMoney;
}

void BattleProc::addExp( int volume ){
	this->plusExp += volume;
}

int BattleProc::getExp(void){
	return this->plusExp;
}

int  BattleProc::getInputChara(void){
	return this->inputChara;
}

void BattleProc::setInputChara( int setchara ){
	this->inputChara = setchara;
}

void BattleProc::setSkillUsed( bool set ){
	this->skillUsed = set;
}

bool BattleProc::getSkillUsed(void){
	return this->skillUsed;
}

void BattleProc::drawInfomation(void){
	DrawFormatStringToHandle( 400,  0, Color[0], Font[1], "BattleTime:%d", this->battleTime );
	DrawFormatStringToHandle( 400, 10, Color[0], Font[1], "Turn:%d", this->battleTime / 1000 );
}

BattleProc::~BattleProc(void){

	//�퓬�𔲂���
	battle = FALSE;
	dungeon->setBattleflag( FALSE );

	for( int i = 0; i < 5; i++ ){
		//Action�̏���
		if( Save_system.party[i] != -1 ){
			delete saveChara[Save_system.party[i]].act;
		}

		//monster�̏���
		if( monster[i].useflag == TRUE ){
			delete monster[i].mobObj;
		}
	}
}
