
void Typedata_load();
void Typeinfo_load();

void Elementdata_load();
void Elementinfo_load();

void mobDataLoad();

void skillDataLoad();

void itemWeaponDataLoad();
void itemUseDataLoad();