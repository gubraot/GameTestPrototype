
void miniInfo();
void party_part();