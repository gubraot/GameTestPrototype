void Hit_recover_calc( int *space, int acter, int target, int skill );
void B_initalize( int paturn );
void B_main();
int  B_target_select( int character, int fanc );