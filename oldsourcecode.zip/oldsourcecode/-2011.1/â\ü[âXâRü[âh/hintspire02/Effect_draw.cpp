//�G�t�F�N�g,�`����֌W
//����{�I�ɓ��͊X��Ԃł��`����s�����̂ł��I

#include "Initalize.h"
#include "Dxlib.h"
#include <math.h>

//�V�X�e���֌W

/*-----
�����`���b
-----*/

void GnumDraw( int Num, int type, int x, int y ){
	int i, BeamWidth, width = 10;

	BeamWidth = 0 ;
	for( i = 10 ; Num >= i ; i *= 10 ) BeamWidth ++;

	// ��ʍ���ɃO���t�B�b�N�ŕ`��
	// x �͐����O���t�B�b�N��`����`�̍��[�̍��W�ł�
	for( i = 0 ; i <= BeamWidth ; i ++ ){
		DrawGraph( x , y , Maternum[( type * 10 ) + ( Num % 10 )], TRUE );
		Num /= 10 ;
		x -= width;
	}
}
/*-----
�_���[�W�p�����`��
-----*/
void Damage_num_draw(){

	//�ϐ���`
	float bound;
	int	  f_out;

	for( int i = 0; i < 30; i++ ){
		if( Damage_num[i].Flag == 1 ){
			if( Damage_num[i].Drawtime < 50 ){
				bound = 62.5 - ( pow( float(Damage_num[i].Drawtime - 25), 2 ) / 10.0 );
				f_out = 256;
			}else{
				bound = 14.4 - ( pow( float(Damage_num[i].Drawtime - 62), 2 ) / 10.0 );
				f_out = ( 74 - Damage_num[i].Drawtime ) * 11;
			}
			SetDrawBlendMode( DX_BLENDMODE_ALPHA, f_out );
			DrawFormatStringToHandle( Damage_num[i].Pos[0], Damage_num[i].Pos[1] - bound, Color[Damage_num[i].Drawtype], Font[4], "%d", Damage_num[i].Damage );
			SetDrawBlendMode( DX_BLENDMODE_NOBLEND, 0 );
			Damage_num[i].Drawtime++;
			if( Damage_num[i].Drawtime == 75 ) Damage_num[i].Flag = 0;
		}
	}
}

/*-----
���b�Z�[�W�\����b
-----*/
void Message_draw( int x, int y, char *message, int maxwidth, int drawingtime ){

	//�ϐ���`
	char drawingword[256] = "";
	int word_num;
	int word_width;
	int drawword_num;

	//1�s�̕�����,���ԕ\�����Z�o
	drawword_num = strlen( message );
	word_num = drawingtime * 2;
	if( word_num > drawword_num ) word_num = drawword_num;
	word_width = maxwidth / 10;
	
	//�\����
	for( int i = 0; i < 3; i++ ){
		if( word_num < word_width * ( i + 1 ) ){
			strncpy( drawingword, message + ( i * word_width ), word_num - ( word_width * i ));
			//���[�����}��
			drawingword[word_num - ( word_width * i )] = '\0'; 
			DrawFormatString( x, y + ( i * 20 ), GetColor( 255, 255, 255 ), "%s", drawingword );
			return;
		}else{
			strncpy( drawingword, message + ( i * word_width ), word_width );
			DrawFormatString( x, y + ( i * 20 ), GetColor( 255, 255, 255 ), "%s", drawingword );
		}
	}
}

/*-----
��̏�ɕ`��
�L�����G�AHPSP�n�X�e�[�^�X
-----*/
void player_mini_info(){

	//�ϐ���`
	static int pos = 200; //y���̃|�W�V����
	static int timepos = 200;

	//���W�ω�
	if( Sinfo_status == 0 && D_info_waiting == 0 ){
		if( pos < 200 ){
			pos += 10;
		}else pos = 200;
	}else{
		if( pos > 0 ){
			pos /= 1.4;
			pos -= 1;
			if( pos < 0 ) pos = 0;
		}
	}
	if( Battle_flag == 0 ){
		if( timepos < 200 ){
			timepos += 10;
		}else timepos = 200;
	}else{
		if( timepos > 0 ){
			timepos /= 1.4;
			timepos -= 1;
			if( timepos < 0 ) timepos = 0;
		}
	}


	//�Ƃ肠�����\��
	for( int i = 0; i < 5; i++ ){
		if( System_save_data.party_no[i] != -1 ){
			//����
			DrawExtendGraph( ( 125 * i ), 400 + pos, 120 + ( 125 * i ), 520 + pos, imgtest , FALSE );

			//���O
			DrawFormatString( 10 + ( 125 * i ), 360 + pos, Color[0], "%s", Charaname[System_save_data.party_no[i]] );
			DrawFormatString( 110 + ( 125 * i ), 360 + pos, Color[0], "%d", System_save_data.party_no[i] );

			//HP�ϓ�����
			if( Member_hp[i] == -1 ){
				Member_hp[i] = Chara_save_data[System_save_data.party_no[i]].hp;
			}else if( Member_hp[i] > Chara_save_data[System_save_data.party_no[i]].hp && GCounter % 2 == 0 ){
				Member_hp[i]--;
				if( Member_hp[i] == Chara_save_data[System_save_data.party_no[i]].hp ) D_info_waiting = 30;
				else D_info_waiting = 999;
			}else if( Member_hp[i] < Chara_save_data[System_save_data.party_no[i]].hp ){
				Member_hp[i] = Chara_save_data[System_save_data.party_no[i]].hp;
			}
			//hpsp�Q�[�W
			DrawGraph( ( 125 * i ), 380 + pos, Guage[0], TRUE );
			SetDrawArea( ( 125 * i ), 380 + pos, ( 125 * i ) + ( 120 * ( Member_hp[i] / float(Chara_save_data[System_save_data.party_no[i]].main_status[0][0]))), 530 + pos );
			DrawGraph( ( 125 * i ), 380 + pos, Guage[3], TRUE );
			SetDrawArea( ( 125 * i ), 380 + pos, ( 125 * i ) + ( 120 * ( Chara_save_data[System_save_data.party_no[i]].hp / float(Chara_save_data[System_save_data.party_no[i]].main_status[0][0]))), 530 + pos );
			DrawGraph( ( 125 * i ), 380 + pos, Guage[1], TRUE );
			SetDrawArea( 36 + ( 125 * i ), 380 + pos, 36 + ( 125 * i ) + ( 70 * ( Chara_save_data[System_save_data.party_no[i]].sp / float(Chara_save_data[System_save_data.party_no[i]].main_status[1][0]))), 530 + pos );
			DrawGraph( ( 125 * i ), 380 + pos, Guage[2], TRUE );
			SetDrawArea( 0, 0, 640, 480 );

			//�^�C���Q�[�W
			DrawBox( 10 + ( 125 * i ), 463 + timepos, 114 + ( 125 * i ), 477 + timepos, Color[5], FALSE );
			DrawBox( 12 + ( 125 * i ), 465 + timepos, 12 + ( 125 * i ) + ( ( Battle_pt[i].time[1][0] / float( Battle_pt[i].time[1][1] ) ) * 100 ), 475 + timepos, Color[6], TRUE );
			if( Battle_pt[i].task == 0 ){
				DrawBox( 12 + ( 125 * i ) + ( 100 - (( Battle_pt[i].time[0][0] / float( Battle_pt[i].time[0][1] ) ) * 100)), 465 + timepos, 112 + ( 125 * i ), 475 + timepos, Color[5], TRUE );
			}
			DrawFormatStringToHandle( 85 + ( 125 * i ), 455 + timepos, Color[5 + Battle_pt[i].task], Font[5], "%d", Battle_pt[i].time[Battle_pt[i].task][0] );

			//hpsp����
			GnumDraw( Member_hp[i], 0, 110 + ( 125 * i ), 380 + pos );
			GnumDraw( Chara_save_data[System_save_data.party_no[i]].sp, 0, 110 + ( 125 * i ), 398 + pos );
		}
	}
	if( D_info_waiting > 0 ) D_info_waiting--;
	return;
}

//�G�t�F�N�g�p�[�c�̕`��o�^
void eff_send( int type, int x, int y ){
	for( int i = 0; i < 100; i++ ){
		if( Effect_parts[i].drawflag == 0 ){
			Effect_parts[i].position[0] = x;
			Effect_parts[i].position[1] = y;
			Effect_parts[i].starttime = GCounter;
			Effect_parts[i].type = type;
			Effect_parts[i].drawflag = 1;
			break;
		}
	}
}

//�G�t�F�N�g�p�[�c�`��
void Effect_draw(){

	//�ϐ���`
	int endtime;

	//�`�揈��
	for( int i = 0; i < 100; i++ ){
		if( Effect_parts[i].drawflag == 1 ){
			switch( Effect_parts[i].type ){
				case 0://�i�s���[�V����
					endtime = Effect_parts[i].starttime + 40;
					Effect_parts[i].config[0] = pow( endtime - GCounter, 2.0 );
					DrawRotaGraph( 320, 240, 1.0 - ( float( Effect_parts[i].config[0] ) / 1600.0), 0, Move_mortion, TRUE );
					break;

				case 1://��ރ��[�V����
					endtime = Effect_parts[i].starttime + 40;
					Effect_parts[i].config[0] = pow( endtime - GCounter, 2.0 );
					DrawRotaGraph( 320, 240, float( Effect_parts[i].config[0] ) / 1600.0, 0, Move_mortion, TRUE );
					break;

				case 2://�t���b�V��
					endtime = Effect_parts[i].starttime + 30;
					Effect_parts[i].config[0] = ( endtime - GCounter ) * 9;
					SetDrawBlendMode( DX_BLENDMODE_ALPHA, Effect_parts[i].config[0] );
					DrawBox( 0, 0, 640, 480, Color[0], TRUE );
					SetDrawBlendMode( DX_BLENDMODE_NOBLEND, 0 );
					break;

				case 3://�Ó]
					endtime = Effect_parts[i].starttime + 60;
					Effect_parts[i].config[0] = ( GCounter - Effect_parts[i].starttime ) * 7;
					SetDrawBlendMode( DX_BLENDMODE_ALPHA, Effect_parts[i].config[0] );
					DrawBox( 0, 0, 640, 480, GetColor( 0, 0, 0 ), TRUE );
					SetDrawBlendMode( DX_BLENDMODE_NOBLEND, 0 );
					break;
			}
			if( endtime <= GCounter ) Effect_parts[i].drawflag = 0;
		}
	}

}

//�_���W�����֌W
