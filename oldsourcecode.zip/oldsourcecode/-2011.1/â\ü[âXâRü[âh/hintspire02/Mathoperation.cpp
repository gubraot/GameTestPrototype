/*----------
�v�Z�֐��֌W
----------*/

#include <math.h>
#include "Initalize.h"
#include "dxlib.h"

//0�ȉ��ɂȂ����ꍇ0��Ԃ��֐�
//����:���肷��l
int natural_num( int number ){
	if( number <= 0 ) return 0;
	else return number;
}


//-�w��l�`�w��l�ŗ�����Ԃ��֐�
//����:�����̍ő�l
float rand( float rand ){
    return ( -rand + rand*2 * GetRand(50000)/50000.0 );
}

//���������_�t������Ԃ��֐�
//����:�����̍ő�l
float absrand( float rand ){
    return ( rand * GetRand(50000)/50000.0 );
}

//�����X�e�[�^�X�����ׂčČv�Z�A�ۑ�����֐�
//����:�Čv�Z����p�[�e�B�̔ԍ�
void Chara_status_calculate( int menber_num ){

	//��b�X�e�[�^�X9��
	for( int j = 0; j < 9; j++ ){
		Chara_save_data[System_save_data.party_no[menber_num]].fix_status[j] = Chara_save_data[System_save_data.party_no[menber_num]].main_status[j][0];
		for( int i = 0; i < 13; i++ ){
			if( i < 8 && Chara_save_data[System_save_data.party_no[menber_num]].weapon_juel_no[i] != -1 ){
				Chara_save_data[System_save_data.party_no[menber_num]].fix_status[j] +=	Item_juel_data[Chara_save_data[System_save_data.party_no[menber_num]].weapon_juel_no[i]].add_st[j];
			}else if( i >= 8 && Chara_save_data[System_save_data.party_no[menber_num]].armor_juel_no[i - 8] != -1 ) { 
				Chara_save_data[System_save_data.party_no[menber_num]].fix_status[j] +=	Item_juel_data[Chara_save_data[System_save_data.party_no[menber_num]].armor_juel_no[i - 8]].add_st[j];
			}
		}
		if( Chara_save_data[System_save_data.party_no[menber_num]].spilit_no != -1 ){
			Chara_save_data[System_save_data.party_no[menber_num]].fix_status[j] *= ( 100 + Item_spilit_data[Chara_save_data[System_save_data.party_no[menber_num]].spilit_no].rank[j] ) / 100;
		}
	}

	//�����ŏ�,�ő�U��
	Chara_save_data[System_save_data.party_no[menber_num]].fix_status[9] = ( Chara_save_data[System_save_data.party_no[menber_num]].fix_status[2] * ( 0.8 + ( Chara_save_data[System_save_data.party_no[menber_num]].fix_status[8] * 0.002 )));
	for( int i = 0; i < 8; i++ ){
		if( Chara_save_data[System_save_data.party_no[menber_num]].weapon_juel_no[i] != -1 ){
			Chara_save_data[System_save_data.party_no[menber_num]].fix_status[9] += Item_juel_data[Chara_save_data[System_save_data.party_no[menber_num]].weapon_juel_no[i]].add_st[9];
		}
		if( Chara_save_data[System_save_data.party_no[menber_num]].armor_juel_no[i] != -1 && i < 5 ){
			Chara_save_data[System_save_data.party_no[menber_num]].fix_status[9] += Item_juel_data[Chara_save_data[System_save_data.party_no[menber_num]].armor_juel_no[i]].add_st[9];
		}
	}
	if( Chara_save_data[menber_num].weapon_no != -1 ){
		Chara_save_data[System_save_data.party_no[menber_num]].fix_status[10] = Chara_save_data[System_save_data.party_no[menber_num]].fix_status[9] + Item_save_data.weapon[Chara_save_data[menber_num].weapon_no][3];
		Chara_save_data[System_save_data.party_no[menber_num]].fix_status[9] += Item_save_data.weapon[Chara_save_data[menber_num].weapon_no][2];
	}else{
		Chara_save_data[System_save_data.party_no[menber_num]].fix_status[10] = Chara_save_data[System_save_data.party_no[menber_num]].fix_status[9];
	}


	//�����U����
	Chara_save_data[System_save_data.party_no[menber_num]].fix_status[11] = 85 + ( ( Chara_save_data[System_save_data.party_no[menber_num]].fix_status[4] * 0.02 ) + ( Chara_save_data[System_save_data.party_no[menber_num]].fix_status[8] * 0.01 ));
	if( Chara_save_data[menber_num].weapon_no != -1 ){
		Chara_save_data[System_save_data.party_no[menber_num]].fix_status[11] += Item_save_data.weapon[Chara_save_data[menber_num].weapon_no][4];
	}

	//�����h��
	Chara_save_data[System_save_data.party_no[menber_num]].fix_status[12] = Chara_save_data[System_save_data.party_no[menber_num]].fix_status[3];
	for( int i = 0; i < 13; i++ ){
		if( i < 8 && Chara_save_data[System_save_data.party_no[menber_num]].weapon_juel_no[i] != -1 ){
			Chara_save_data[System_save_data.party_no[menber_num]].fix_status[12] += Item_juel_data[Chara_save_data[System_save_data.party_no[menber_num]].weapon_juel_no[i]].add_st[11];
		}else if( i >= 8 && Chara_save_data[System_save_data.party_no[menber_num]].armor_juel_no[i - 8] != -1 ) { 
			Chara_save_data[System_save_data.party_no[menber_num]].fix_status[12] += Item_juel_data[Chara_save_data[System_save_data.party_no[menber_num]].armor_juel_no[i - 8]].add_st[11];
		}
	}
	if( Chara_save_data[menber_num].armor_no != -1 ){
		Chara_save_data[System_save_data.party_no[menber_num]].fix_status[12] += Item_save_data.armor[Chara_save_data[menber_num].armor_no][2];
	}


	//������
	Chara_save_data[System_save_data.party_no[menber_num]].fix_status[13]= 70 * ( 1 + ( Chara_save_data[System_save_data.party_no[menber_num]].fix_status[8] * 0.005 )) + Chara_save_data[System_save_data.party_no[menber_num]].fix_status[4];
	for( int i = 0; i < 13; i++ ){
		if( i < 8 && Chara_save_data[System_save_data.party_no[menber_num]].weapon_juel_no[i] != -1 ){
			Chara_save_data[System_save_data.party_no[menber_num]].fix_status[12] += Item_juel_data[Chara_save_data[System_save_data.party_no[menber_num]].weapon_juel_no[i]].add_st[13];
		}else if( i >= 8 && Chara_save_data[System_save_data.party_no[menber_num]].armor_juel_no[i - 8] != -1 ) { 
			Chara_save_data[System_save_data.party_no[menber_num]].fix_status[12] += Item_juel_data[Chara_save_data[System_save_data.party_no[menber_num]].armor_juel_no[i - 8]].add_st[13];
		}
	}
	if( Chara_save_data[menber_num].weapon_no != -1 ){
		Chara_save_data[System_save_data.party_no[menber_num]].fix_status[13] += Item_weapon_data[Item_save_data.weapon[Chara_save_data[System_save_data.party_no[menber_num]].weapon_no][0]].hit;
	}

	//����
	Chara_save_data[System_save_data.party_no[menber_num]].fix_status[14] = Chara_save_data[System_save_data.party_no[menber_num]].fix_status[5] + ( Chara_save_data[System_save_data.party_no[menber_num]].fix_status[8] * 0.05 );
	for( int i = 0; i < 13; i++ ){
		if( i < 8 && Chara_save_data[System_save_data.party_no[menber_num]].weapon_juel_no[i] != -1 ){
			Chara_save_data[System_save_data.party_no[menber_num]].fix_status[14] += Item_juel_data[Chara_save_data[System_save_data.party_no[menber_num]].weapon_juel_no[i]].add_st[14];
		}else if( i >= 8 && Chara_save_data[System_save_data.party_no[menber_num]].armor_juel_no[i - 8] != -1 ) { 
			Chara_save_data[System_save_data.party_no[menber_num]].fix_status[14] += Item_juel_data[Chara_save_data[System_save_data.party_no[menber_num]].armor_juel_no[i - 8]].add_st[14];
		}
	}
	if( Chara_save_data[menber_num].armor_no != -1 ){
		Chara_save_data[System_save_data.party_no[menber_num]].fix_status[14] += Item_armor_data[Item_save_data.armor[Chara_save_data[System_save_data.party_no[menber_num]].armor_no][0]].avd;
	}

	//�U�����x
	Chara_save_data[System_save_data.party_no[menber_num]].fix_status[15]= 1000 - ( Chara_save_data[System_save_data.party_no[menber_num]].fix_status[5] * 1.25 );
	for( int i = 0; i < 13; i++ ){
		if( i < 8 && Chara_save_data[System_save_data.party_no[menber_num]].weapon_juel_no[i] != -1 ){
			Chara_save_data[System_save_data.party_no[menber_num]].fix_status[15] += Item_juel_data[Chara_save_data[System_save_data.party_no[menber_num]].weapon_juel_no[i]].add_st[16];
		}else if( i >= 8 && Chara_save_data[System_save_data.party_no[menber_num]].armor_juel_no[i - 8] != -1 ) { 
			Chara_save_data[System_save_data.party_no[menber_num]].fix_status[15] += Item_juel_data[Chara_save_data[System_save_data.party_no[menber_num]].armor_juel_no[i - 8]].add_st[16];
		}
	}
	if( Chara_save_data[menber_num].weapon_no != -1 ){
		Chara_save_data[System_save_data.party_no[menber_num]].fix_status[15] += Item_weapon_data[Item_save_data.weapon[Chara_save_data[System_save_data.party_no[menber_num]].weapon_no][0]].spd;
	}

	//���_�U����
	Chara_save_data[System_save_data.party_no[menber_num]].fix_status[16]= Chara_save_data[System_save_data.party_no[menber_num]].fix_status[6] + ( Chara_save_data[System_save_data.party_no[menber_num]].fix_status[7] * 0.25 ) + ( Chara_save_data[System_save_data.party_no[menber_num]].fix_status[8] * 0.1 );
	for( int i = 0; i < 13; i++ ){
		if( i < 8 && Chara_save_data[System_save_data.party_no[menber_num]].weapon_juel_no[i] != -1 ){
			Chara_save_data[System_save_data.party_no[menber_num]].fix_status[16] += Item_juel_data[Chara_save_data[System_save_data.party_no[menber_num]].weapon_juel_no[i]].add_st[10];
		}else if( i >= 8 && Chara_save_data[System_save_data.party_no[menber_num]].armor_juel_no[i - 8] != -1 ) { 
			Chara_save_data[System_save_data.party_no[menber_num]].fix_status[16] += Item_juel_data[Chara_save_data[System_save_data.party_no[menber_num]].armor_juel_no[i - 8]].add_st[10];
		}
	}
	if( Chara_save_data[menber_num].weapon_no != -1 ){
		Chara_save_data[System_save_data.party_no[menber_num]].fix_status[16] += Item_weapon_data[Item_save_data.weapon[Chara_save_data[System_save_data.party_no[menber_num]].weapon_no][0]].magic;
	}

	//���_�h���
	Chara_save_data[System_save_data.party_no[menber_num]].fix_status[17]= Chara_save_data[System_save_data.party_no[menber_num]].fix_status[7] * ( 1 + ( Chara_save_data[System_save_data.party_no[menber_num]].fix_status[8] * 0.001 ));
	for( int i = 0; i < 13; i++ ){
		if( i < 8 && Chara_save_data[System_save_data.party_no[menber_num]].weapon_juel_no[i] != -1 ){
			Chara_save_data[System_save_data.party_no[menber_num]].fix_status[17] += Item_juel_data[Chara_save_data[System_save_data.party_no[menber_num]].weapon_juel_no[i]].add_st[12];
		}else if( i >= 8 && Chara_save_data[System_save_data.party_no[menber_num]].armor_juel_no[i - 8] != -1 ) { 
			Chara_save_data[System_save_data.party_no[menber_num]].fix_status[17] += Item_juel_data[Chara_save_data[System_save_data.party_no[menber_num]].armor_juel_no[i - 8]].add_st[12];
		}
	}
	if( Chara_save_data[menber_num].armor_no != -1 ){
		Chara_save_data[System_save_data.party_no[menber_num]].fix_status[17] += Item_save_data.armor[Chara_save_data[menber_num].armor_no][3];
	}

	//�W�����x
	Chara_save_data[System_save_data.party_no[menber_num]].fix_status[18]= 1000 - ( Chara_save_data[System_save_data.party_no[menber_num]].fix_status[4] + ( Chara_save_data[System_save_data.party_no[menber_num]].fix_status[7] * 2 ) / 2.0);
	for( int i = 0; i < 13; i++ ){
		if( i < 8 && Chara_save_data[System_save_data.party_no[menber_num]].weapon_juel_no[i] != -1 ){
			Chara_save_data[System_save_data.party_no[menber_num]].fix_status[18] += Item_juel_data[Chara_save_data[System_save_data.party_no[menber_num]].weapon_juel_no[i]].add_st[17];
		}else if( i >= 8 && Chara_save_data[System_save_data.party_no[menber_num]].armor_juel_no[i - 8] != -1 ) { 
			Chara_save_data[System_save_data.party_no[menber_num]].fix_status[18] += Item_juel_data[Chara_save_data[System_save_data.party_no[menber_num]].armor_juel_no[i - 8]].add_st[17];
		}
	}

	//���_�K��
	Chara_save_data[System_save_data.party_no[menber_num]].fix_status[19] = 50 + ( Chara_save_data[System_save_data.party_no[menber_num]].fix_status[7] * 0.2 );
	for( int i = 0; i < 13; i++ ){
		if( i < 8 && Chara_save_data[System_save_data.party_no[menber_num]].weapon_juel_no[i] != -1 ){
			Chara_save_data[System_save_data.party_no[menber_num]].fix_status[19] += Item_juel_data[Chara_save_data[System_save_data.party_no[menber_num]].weapon_juel_no[i]].add_st[17];
		}else if( i >= 8 && Chara_save_data[System_save_data.party_no[menber_num]].armor_juel_no[i - 8] != -1 ) { 
			Chara_save_data[System_save_data.party_no[menber_num]].fix_status[19] += Item_juel_data[Chara_save_data[System_save_data.party_no[menber_num]].armor_juel_no[i - 8]].add_st[17];
		}
	}

	//�N���e�B�J��
	Chara_save_data[System_save_data.party_no[menber_num]].fix_status[20] = 0;
	for( int i = 0; i < 13; i++ ){
		if( i < 8 && Chara_save_data[System_save_data.party_no[menber_num]].weapon_juel_no[i] != -1 ){
			Chara_save_data[System_save_data.party_no[menber_num]].fix_status[20] += Item_juel_data[Chara_save_data[System_save_data.party_no[menber_num]].weapon_juel_no[i]].add_st[15];
		}else if( i >= 8 && Chara_save_data[System_save_data.party_no[menber_num]].armor_juel_no[i - 8] != -1 ) { 
			Chara_save_data[System_save_data.party_no[menber_num]].fix_status[20] += Item_juel_data[Chara_save_data[System_save_data.party_no[menber_num]].armor_juel_no[i - 8]].add_st[15];
		}
	}
	if( Chara_save_data[menber_num].weapon_no != -1 ){
		Chara_save_data[System_save_data.party_no[menber_num]].fix_status[20] += Item_weapon_data[Item_save_data.weapon[Chara_save_data[System_save_data.party_no[menber_num]].weapon_no][0]].critical;
	}
}

//�����X�e�[�^�X���w��z��Ɋi�[����֐�
//����:�L�����N�^�[�ԍ�, �i�[�z��21,�����ԍ����Ԃɒ��ڎw��15
void Chara_status_calculate_int( int menber_num, int *buf, int *equip ){

	//��b�X�e�[�^�X9��
	for( int j = 0; j < 9; j++ ){
		buf[j] = Chara_save_data[System_save_data.party_no[menber_num]].main_status[j][0];
		for( int i = 0; i < 13; i++ ){
			if( equip[i + 3] != -1 ){
				buf[j] +=	Item_juel_data[equip[i + 3]].add_st[j];
			}
		}
		if( equip[2] != -1 ){
			buf[j] *= ( 100 + Item_spilit_data[equip[2]].rank[j] ) / 100;
		}
	}
	
	//�����ŏ�,�ő�U��
	buf[9] = ( buf[2] * ( 0.8 + ( buf[8] * 0.002 )));
	for( int i = 0; i < 13; i++ ){
		if( equip[i + 3] != -1 ){
			buf[9] += Item_juel_data[equip[i + 3]].add_st[9];
		}
	}
	if( equip[0] != -1 ){
		buf[10] = buf[9] + Item_save_data.weapon[equip[0]][3];
		buf[9] += Item_save_data.weapon[equip[0]][2];
	}else{
		buf[10] = buf[9];
	}


	//�����U����
	buf[11] = 85 + ( ( buf[4] * 0.02 ) + ( buf[8] * 0.01 ));
	if( equip[0] != -1 ){
		buf[11] += Item_save_data.weapon[equip[0]][4];
	}

	//�����h��
	buf[12] = buf[3];
	for( int i = 0; i < 13; i++ ){
		if( equip[i + 3] != -1 ){
			buf[12] += Item_juel_data[equip[i + 3]].add_st[11];
		}
	}
	if( equip[1] != -1 ){
		buf[12] += Item_save_data.armor[equip[1]][2];
	}


	//������
	buf[13]= 70 * ( 1 + ( buf[8] * 0.005 )) + buf[4];
	for( int i = 0; i < 13; i++ ){
		if( equip[i + 3] != -1 ){
			buf[13] += Item_juel_data[equip[i + 3]].add_st[13];
		}
	}
	if( equip[0] != -1 ){
		buf[13] += Item_weapon_data[Item_save_data.weapon[equip[0]][0]].hit;
	}

	//����
	buf[14] = buf[5] + ( buf[8] * 0.05 );
	for( int i = 0; i < 13; i++ ){
		if( equip[i + 3] != -1 ){
			buf[14] += Item_juel_data[equip[i + 3]].add_st[14];
		}
	}
	if( equip[1] != -1 ){
		buf[14] += Item_armor_data[Item_save_data.armor[equip[0]][0]].avd;
	}

	//�U�����x
	buf[15]= 1000 - ( buf[5] * 1.25 );
	for( int i = 0; i < 13; i++ ){
		if( equip[i + 3] != -1 ){
			buf[15] += Item_juel_data[equip[i + 3]].add_st[16];
		}
	}
	if( equip[0] != -1 ){
		buf[15] += Item_weapon_data[Item_save_data.weapon[equip[0]][0]].spd;
	}

	//���_�U����
	buf[16]= buf[6] + ( buf[7] * 0.25 ) + ( buf[8] * 0.1 );
	for( int i = 0; i < 13; i++ ){
		if( equip[i + 3] != -1 ){
			buf[16] += Item_juel_data[equip[i + 3]].add_st[10];
		}
	}
	if( equip[0] != -1 ){
		buf[16] += Item_weapon_data[Item_save_data.weapon[equip[0]][0]].magic;
	}

	//���_�h���
	buf[17]= buf[7] * ( 1 + ( buf[8] * 0.001 ));
	for( int i = 0; i < 13; i++ ){
		if( equip[i + 3] != -1 ){
			buf[17] += Item_juel_data[equip[i + 3]].add_st[12];
		}
	}
	if( equip[1] != -1 ){
		buf[17] += Item_save_data.armor[equip[1]][3];
	}

	//�W�����x
	buf[18]= 1000 - ( buf[4] + ( buf[7] * 2 ) / 2.0);
	for( int i = 0; i < 13; i++ ){
		if( equip[i + 3] != -1 ){
			buf[18] += Item_juel_data[equip[i + 3]].add_st[17];
		}
	}

	//���_�K��
	buf[19]= 50 + ( buf[7] * 0.2 );
	for( int i = 0; i < 13; i++ ){
		if( equip[i + 3] != -1 ){
			buf[19] += Item_juel_data[equip[i + 3]].add_st[17];
		}
	}

	//�N���e�B�J��
	buf[20] = 0;
	for( int i = 0; i < 13; i++ ){
		if( equip[i + 3] != -1 ){
			buf[20] += Item_juel_data[equip[i + 3]].add_st[15];
		}
	}
	if( equip[0] != -1 ){
		buf[20] += Item_weapon_data[Item_save_data.weapon[equip[0]][0]].critical;
	}
}

//���݃X�L������
//��������L�����N�^�[�ԍ�
void Chara_skill_calculate( int member_num ){
	
	//�X�L����Ԃ̏�����
	for( int i = 0; i < 200; i++ ){
		Chara_save_data[member_num].skill_no[i] = 0;
	}

	//��΃X�L���̔��f
	for( int i = 0; i < 8; i++ ){
		for( int j = 0; j < 3; j++ ){
			if( Chara_save_data[member_num].weapon_juel_no[i] == -1 || Item_juel_data[Chara_save_data[member_num].weapon_juel_no[i]].skill[j] == -1 ) break;
			else Chara_save_data[member_num].skill_no[ Item_juel_data[Chara_save_data[member_num].weapon_juel_no[i]].skill[j]]++;
		}
	}
	for( int i = 0; i < 5; i++ ){
		for( int j = 0; j < 3; j++ ){
			if( Chara_save_data[member_num].armor_juel_no[i] == -1 || Item_juel_data[Chara_save_data[member_num].armor_juel_no[i]].skill[j] == -1 ) break;
			else Chara_save_data[member_num].skill_no[ Item_juel_data[Chara_save_data[member_num].armor_juel_no[i]].skill[j]]++;
		}
	}
}
