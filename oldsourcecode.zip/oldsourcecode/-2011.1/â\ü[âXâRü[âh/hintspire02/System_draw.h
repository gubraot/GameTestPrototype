
void GnumDraw( int Num, int type, int x, int y );
void Draw_window( int x1, int x2, int y1, int y2 );
void Message_draw( int x, int y, char *message, int maxwidth, int drawingtime );
void Draw_select( int x1, int x2, int y1, int y2 );
void chara_edit( int member_num );
void player_mini_info();
int manu_draw_y( int x, int y, int width, int num, ...);
void Party_manu();
int Create_chara( int member_num );
int buy_item( int category, int shop_level );
int yes_no_message( char *message, char *message2 );
int ok_message( char *message );
int Dungeon_select();
void item_use( int number, int target, int usemember, int paturn );
int Member_change();
void item_write( int category, int number );
int Skill_manu( int character );