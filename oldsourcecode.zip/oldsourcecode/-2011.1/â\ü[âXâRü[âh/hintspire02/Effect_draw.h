

void GnumDraw( int Num, int type, int x, int y );
void Damage_num_draw();
void Message_draw( int x, int y, char *message, int maxwidth, int drawingtime );
void player_mini_info();
void Effect_draw();
void eff_send( int type, int x, int y );
