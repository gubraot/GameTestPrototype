//�V�X�e���n�`��֐����C�u����

#include <Dxlib.h>
#include <math.h>
#include "Initalize.h"
#include "Mathoperation.h"
#include "Datasave.h"
#include "Dungeon_draw.h"
#include "Effect_draw.h"
#include "Battle_draw.h"

/*-----
�E�C���h�E�`���b
-----*/
void Draw_window( int x1, int x2, int y1, int y2 ){
	
	//�ϐ���`
	int draw_point_x[4][4]; //�p�[�c�`��ɕK�v�ȍ���x���W16�_
	int draw_point_y[4][4]; //�p�[�c�`��ɕK�v�ȍ���y���W16�_
	int parts_number = 0;

	//�`��|�C���g�̎Z�o
	for( int i = 0; i < 4; i++ ){
		draw_point_x[i][0] = x1;
		draw_point_y[0][i] = y1;
		draw_point_x[i][1] = x1 + 6;
		draw_point_y[1][i] = y1 + 6;
		draw_point_x[i][2] = x2 - 6;
		draw_point_y[2][i] = y2 - 6;
		draw_point_x[i][3] = x2;
		draw_point_y[3][i] = y2;
	}

	//�`��{��
	for( int i = 0; i < 3; i++ ){
		for( int j = 0; j < 3; j++ ){
			if( i != 1 && j != 1 ){
				DrawGraph( draw_point_x[i][j], draw_point_y[i][j], Window_parts[parts_number], TRUE );
			}else{
				DrawExtendGraph( draw_point_x[i][j], draw_point_y[i][j], draw_point_x[i + 1][j + 1], draw_point_y[i + 1][j + 1], Window_parts[parts_number], TRUE );
			}
			parts_number++;
		}
	}
}

//�I�𒆘g�̕\��
void Draw_select( int x1, int x2, int y1, int y2 ){
	
	//�ϐ���`
	int draw_point_x[4][4]; //�p�[�c�`��ɕK�v�ȍ���x���W16�_
	int draw_point_y[4][4]; //�p�[�c�`��ɕK�v�ȍ���y���W16�_
	int parts_number = 0;
	int alpha;

	//�`��|�C���g�̎Z�o
	for( int i = 0; i < 4; i++ ){
		draw_point_x[i][0] = x1;
		draw_point_y[0][i] = y1;
		draw_point_x[i][1] = x1 + 6;
		draw_point_y[1][i] = y1 + 6;
		draw_point_x[i][2] = x2 - 6;
		draw_point_y[2][i] = y2 - 6;
		draw_point_x[i][3] = x2;
		draw_point_y[3][i] = y2;
	}

	//�O���f�[�V�����l�̌v�Z
	alpha = abs((( GCounter % 64 ) * 4 )  - 128 ) + 128;

	//�`��{��
	SetDrawBlendMode( DX_BLENDMODE_ALPHA, alpha );
	for( int i = 0; i < 3; i++ ){
		for( int j = 0; j < 3; j++ ){
			if( i != 1 && j != 1 ){
				DrawGraph( draw_point_x[i][j], draw_point_y[i][j], Window_select[parts_number], TRUE );
			}else{
				DrawExtendGraph( draw_point_x[i][j], draw_point_y[i][j], draw_point_x[i + 1][j + 1], draw_point_y[i + 1][j + 1], Window_select[parts_number], TRUE );
			}
			parts_number++;
		}
	}
	SetDrawBlendMode( DX_BLENDMODE_NOBLEND, 0 );
}

/*-----
�c�I�����j���[�̕\��
-----*/
int manu_draw_y( int x, int y, int width, int num, ...){

	//�ϐ���`
	va_list list;
	int i;
	char manutxt[100];
	
	//�E�C���h�E�\��
	Draw_window( x, x + width, y, y + 10 + ( 20 * num )); 

	//���X�g�\������
	va_start( list, num );
	
	for(i = 0; i < num; i++ ){
		strcpy( manutxt, va_arg(list, char *) );
		DrawFormatString( x + 5, y + 5 + ( 20 * i ), Color[0], "%s", manutxt );
	}
	
	va_end( list );

	//serect�g�\��
	Draw_select( x + 3, x + width - 3, y + 5 + ( 20 * (Selecting - 1)) - 1, y + 26 + ( 20 * (Selecting - 1)));

	//�����t
	if( Keystate[KEY_INPUT_Z] == 1 ){
		int save_select = Selecting;
		Selecting = 1;
		return save_select;
	}else if( Keystate[KEY_INPUT_UP] == 1 && Selecting > 1 ){
		Selecting--;
	}else if( Keystate[KEY_INPUT_DOWN] == 1 && Selecting < num ){
		Selecting++;
	}

	//��������̗��R�ł͂ݏo���ꍇ���ɖ߂��B
	if( Selecting < 1 ) Selecting = 1;
	else if( Selecting > num ) Selecting = num;

	//�I�𖢊�����return
	return 0;
}

//�͂��A������
//�����A���b�Z�[�W*2
//�Ԓl:�͂�:1�@������:2
int yes_no_message( char *message, char *message2 ){

	//�ϐ���`
	static int select = 0;
	int ret_select;

	Draw_window( 150, 490, 150, 230 );
	DrawFormatString( 155, 155, Color[0], "%s", message );
	DrawFormatString( 155, 175, Color[0], "%s", message2 );
	DrawString( 260, 200, " �͂�", Color[0] );
	DrawString( 360, 200, "������", Color[0] );
	Draw_select( 248 + ( select * 100 ), 352 + ( select * 100 ), 198, 222 ); 
	
	//���͎�t
	if( Keystate[KEY_INPUT_Z] == 1 ){
		ret_select = 1 + select;
		select = 0;
		return ret_select;
	}else if( Keystate[KEY_INPUT_LEFT] == 1 && select == 1 ){
		select--;
	}else if( Keystate[KEY_INPUT_RIGHT] == 1 && select == 0 ){
		select++;
	}

	//�I��O
	return 0;
}

int ok_message( char *message ){

	Draw_window( 180, 460, 170, 220 );
	DrawFormatString( 185, 185, Color[0], "%s", message );
	
	//���͎�t
	if( Keystate[KEY_INPUT_Z] == 1 ){
		return 1;
	}

	//�I��O
	return 0;
}

/*-----
�L�����N�^�[�쐬�֌W
-----*/

//���O���͉��
int Name_input( int member_num, int Face_grphic_num ){
	
	//�ϐ���`
	static char Imput_name[6][3] = {"","","","","",""}; //2�o�C�g������6�������p��
	static int name_pos = 0;
	static int Select_point[2] ={ 0, 0 }; //�p�ӂ���}�X�w��
	static int kana = 0;
	int	keypad_draw = 0;
	int select_plus = 0;
	//�萔��` 
	const char fanc[4][5] = { "����","�߂�","�J�i","���~" };
	const char hira[320][3] = {	"��","��","��","��","��","��","��","��","��","��",
								"��","��","��","��","��","��","��","��","��","��",
								"��","��","��","��","��","��","��","��","��","��",
								"��","��","��","��","��","��","�@","��","�@","��",
								"��","��","��","��","��","��","�@","��","�@","��",
								"��","��","��","��","��","��","��","��","��","��",
								"��","��","��","��","��","��","��","��","��","��",
								"��","��","��","��","��","��","��","��","�[","�`",
								"�A","�C","�E","�G","�I","�J","�L","�N","�P","�R",
								"�T","�V","�X","�Z","�\","�^","�`","�c","�e","�g",
								"�i","�j","�k","�l","�m","�n","�q","�t","�w","�z",
								"�}","�~","��","��","��","��","�@","��","�@","��",
								"��","��","��","��","��","��","�@","��","�@","��",
								"�K","�M","�O","�Q","�S","�U","�W","�Y","�[","�]",
								"�_","�a","�d","�f","�h","�o","�r","�u","�x","�{",
								"�@","�B","�D","�F","�H","��","��","��","��","��"};

	//�`�敔��
	//�܂�
	Draw_window( 0, 560, 0, 30 );
	Draw_window( 0, 560, 30, 160 );
	Draw_window( 0, 560, 160, 320 );

	//����
	DrawExtendGraph( 35, 35, 155, 155, imgtest , FALSE );

	//����
	DrawString( 10, 5, "�L�����N�^�[�������߂Ă��������B", Color[0] );

	for( int i = 0; i < 17; i++ ){
			for( int j = 0; j < 5; j++ ){
				if( i != 16 ){
					DrawFormatString( 10 + ( i * 30 ), 170 + ( j * 30 ), Color[0], "%s", hira[ keypad_draw + ( kana * 80 )] );
					keypad_draw++;
				}else{
					DrawFormatString( 10 + ( i * 30 ), 170 + ( j * 30 ), Color[0], "%s", fanc[j] );
					if( j == 3 ) break;
				}
			}
	}
	for( int i = 0; i < 6; i++ ){
		DrawFormatString( 200 + ( i * 30 ), 130, Color[0], "%s", Imput_name[i] );
	}

	//�I�𕔕�
	if( Select_point[0] == 16 ) select_plus = 1;
	else select_plus = 0;
	Draw_select( 9 + ( Select_point[0] * 30 ), 31 + ( Select_point[0] * 30 ) + ( select_plus * 20), 169 + (Select_point[1] * 30 ) , 191 + ( Select_point[1] * 30 ) );

	//���͎�t
	if( Keystate[KEY_INPUT_Z] == 1 ){
		if( Select_point[0] < 16 ){
			strncpy( Imput_name[name_pos], hira[Select_point[0] * 5 + Select_point[1] + ( kana * 80 )], 2);
			if( name_pos == 6 ){
				Select_point[0] = 16;
				Select_point[1] = 0;
			}else name_pos++;
		}else{
			switch( Select_point[1] ){
				case 0:
					for( int i = 0; i < 6; i++ ){
						strcat( Charaname[member_num], Imput_name[i] );
					}
					//�g�p�����f�[�^�̃��Z�b�g
					for( int i = 0; i < 6; i++ ){
						strcpy(Imput_name[i], "�@" );
					}
					name_pos = 0;
					for( int i = 0; i < 2; i++ ){
						Select_point[i] = 0;
					}
					kana = 0;
					keypad_draw = 0;
					select_plus = 0;
					return 1;
				case 1:
					strncpy( Imput_name[name_pos], "\0", 2);
					if( name_pos > 0 ) name_pos--;
					break;
				
				case 2:
					if( kana == 1 ) kana = 0;
					else kana = 1;
					break;
			}
		}
	}else if( Keystate[KEY_INPUT_UP] == 1 && Select_point[1] > 0 ){
		Select_point[1]--;
	}else if( Keystate[KEY_INPUT_DOWN] == 1 && Select_point[1] < 4 ){
		Select_point[1]++;
	}else if( Keystate[KEY_INPUT_LEFT] == 1 && Select_point[0] > 0 ){
		Select_point[0]--;
	}else if( Keystate[KEY_INPUT_RIGHT] == 1 && Select_point[0] < 16 ){
		Select_point[0]++;
	}else if( Keystate[KEY_INPUT_Y] == 1 ){
		strncpy( Imput_name[name_pos - 1], "\0", 2);
		if( name_pos > 0 ) name_pos--;
	}
	//�ʏ�I��
	return 0;
}

//�^�C�v�A�����ݒ���
int chara_edit( int member_num ){
	
	//�ϐ���`
	static int number = 0;
	static int select_type;
	static int type_ok = 0;
	static int draw_time = GCounter;
	static int element_point = 5;
	static int select_element[7] = { 0, 0, 0, 0, 0, 0, 0 };
	static float element_plus[15] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
	int state_color;

	//�萔��`
	const char state_info[][12] = { "�ő�HP","�ő�SP","��","�̗�",
									"��p","����","����","���_",
									"�V��","�Αϐ�","���ϐ�","�n�ϐ�",
									"���ϐ�","���ϐ�","�őϐ�","���ϐ�"};

	const char y_n[][12] = { "�͂�", "������" };

	//�E�C���h�E
	Draw_window( 0, 500, 0, 30 );
	Draw_window( 500, 640, 0, 160 );
	Draw_window( 0, 500, 30, 120 );
	Draw_window( 500, 640, 160, 190 ); 
	Draw_window( 500, 640, 190, 410 );
	Draw_window( 0, 500, 120, 480 ); 

	//����
	DrawExtendGraph( 510, 10, 630, 130, imgtest , FALSE );

	//�Œ蕶,������
	DrawString( 10, 5, "�L�����N�^�[�̐����^�C�v�Ƒ����l�����߂Ă��������B", Color[0] );
	if( type_ok == 0 ){
		DrawFormatString( 10, 35, Color[7 + Chara_type_info[number].color], "%s", Chara_type_info[number].style );
		Message_draw( 10, 55, Chara_type_info[number].comment, 500, GCounter - draw_time );
	}else{
		DrawFormatString( 10, 35, Color[8], "%s", Element_type_info[number].style ); 
		Message_draw( 10, 55, Element_type_info[number].comment, 500, GCounter - draw_time );
	}
	DrawFormatString( 520, 135, Color[0], "%s", Charaname[member_num] );
	//�\�͒l�\��
	DrawStringToHandle( 100, 130, "�\�͒l  �@�K�vPt", Color[0], Font[0] );
	for( int i = 0; i < 16; i++ ){
		if( i < 2 ) state_color = 11 + i;
		else state_color = 0;

		DrawString( 20, 150 + ( i * 20 ), state_info[i], Color[state_color] );
		if( i < 9 && type_ok == 0 ){
			DrawFormatString( 120, 150 + ( i * 20 ), Color[state_color], "%d", int(Chara_type_data[number][i]) );
			DrawFormatString( 200, 150 + ( i * 20 ), Color[state_color], "%d", int(Chara_type_data[number][18 + i]) );
		}else if( i < 9 && type_ok >= 1 ){
			DrawFormatString( 120, 150 + ( i * 20 ), Color[state_color], "%d", int(Chara_type_data[select_type][i]) );
			DrawFormatString( 200, 150 + ( i * 20 ), Color[state_color], "%d", int(Chara_type_data[select_type][18 + i]) );
			//�����␳�\����
			if( Element_data[number][i] == 0.25 && type_ok == 1 ){
				DrawString( 150, 150 + ( i * 20 ), "��", Color[13] );
			}else if( Element_data[number][i] == 0.5 && type_ok == 1 ){
				DrawString( 150, 150 + ( i * 20 ), "����", Color[13] );
			}
		}else if( i > 8 && type_ok >= 1 ){
			DrawFormatString( 120, 150 + ( i * 20 ), Color[state_color], "%d", int(element_plus[i - 1]) );
			if( type_ok == 1 ){
				DrawFormatString( 160, 150 + ( i * 20 ), Color[state_color], "(%d)", int(Element_data[number][i - 1]) );
			}
		}
	}

	//�E�����X�g�\��
	switch( type_ok ){
		case 0:
			DrawString( 510, 165, "�^�C�v�I��", Color[0] );
			break;

		case 1:
			DrawFormatString( 510, 165, Color[0], "�������U��:�c%d", element_point );
			break;

		case 2:
			DrawString( 510, 165, "�����ł����H", Color[0] );

	}
	for( int i = 0; i < 10; i++ ){
		if( type_ok == 0 ){
			DrawFormatString( 510, 200 + ( 20 * i ), Color[0], "%s", Chara_type_info[i].type_name );
		}else if( type_ok == 1 && i < 7 ){
			DrawFormatString( 510, 200 + ( 20 * i ), Color[0], "%s", Element_type_info[i].type_name );
			DrawFormatString( 580, 200 + ( 20 * i ), Color[0], "%d", select_element[i] );
		}else if( type_ok == 2 && i < 2 ){
			DrawFormatString( 510, 200 + ( 20 * i ), Color[0], "%s", y_n[i] );
		}
	}
	Draw_select( 509, 631, 199 + ( number * 20 ) , 221 + ( number * 20 ) );



	//�����t
	if( Keystate[KEY_INPUT_Z] == 1 ){
		if( type_ok == 0 ){
			select_type = number;
			number = 0;
			draw_time = GCounter;
			type_ok++;
		}else if( type_ok == 2 ){
			switch( number ){
				case 0: //�L�����f�[�^��ۑ����Ď���
					//hp,sp
					Chara_save_data[member_num].hp = Chara_type_data[select_type][0];
					Chara_save_data[member_num].sp = Chara_type_data[select_type][1];
					for( int i = 0; i < 4; i++ ){
						for( int j = 0; j < 9; j++ ){
							switch( i ){
								case 0://��b�X�e�[�^�X���l
									Chara_save_data[member_num].main_status[j][i] = Chara_type_data[select_type][j];
									break;
								case 1://��b�X�e�[�^�X�����l
									if( j < 8 ) Chara_save_data[member_num].main_status[j][i] = Chara_type_data[select_type][j + 9] + element_plus[j];
									else Chara_save_data[member_num].main_status[j][i] = Chara_type_data[select_type][j + 9];
									break;
								case 2://��b�X�e�[�^�X�z���|�C���g
									Chara_save_data[member_num].main_status[j][i] = Chara_type_data[select_type][j + 18];
									break;
								case 3://�L�����N�^�[�����ϐ�
									if( j < 7 ) Chara_save_data[member_num].element[j] = element_plus[j + 8];
							}
						}
					}

					//�p�[�e�B�󂢂Ă���΃p�[�e�B�[�ɑg�ݍ���ŕۑ�
					System_save_data.menber_ok[member_num] = 1;
					for( int i = 0; i < 5; i++ ){
						if( System_save_data.party_no[i] == -1 ){
							System_save_data.party_no[i] = member_num;
							Chara_status_calculate( member_num );
							break;
						}
					}
					Chara_skill_calculate( member_num );
					Data_save();
					//�g�p�����f�[�^�����Z�b�g
					number = 0;
					type_ok = 0;
					element_point = 5;
					for( int i = 0; i < 7; i++ ){
						select_element[i] = 0;
					}
					for( int i = 0; i < 15; i++ ){
						element_plus[i] = 0;
					}
					return 1;
					
				case 1: //���Z�b�g���čŏ��ɖ߂�
					type_ok = 0;
					number = 0;
					draw_time = GCounter;
					element_point = 5;
					for( int i = 0; i < 15; i++ ){
						element_plus[i] = 0;
						if( i < 7 ) select_element[i] = 0;
					}
					break;
			}

		}
	}else if( Keystate[KEY_INPUT_UP] == 1 && number > 0){
		number--;
		draw_time = GCounter;
	}else if( Keystate[KEY_INPUT_DOWN] == 1){
		if( type_ok == 0 && number < 9 ){
			number++;
			draw_time = GCounter;
		}else if( type_ok == 1 && number < 6 ){
			number++;
			draw_time = GCounter;
		}
	}else if( Keystate[KEY_INPUT_LEFT] == 1 ){
		if( select_element[number] > 0 && type_ok == 1 ){
			select_element[number]--;
			element_point++;
			//�����C���l�Čv�Z
			for( int i = 0; i < 15; i++ ){
				element_plus[i] = 0;
				for( int j = 0; j < 7; j++ ){
					element_plus[i] += Element_data[j][i] * select_element[j];
				}
			}
		}
	}else if( Keystate[KEY_INPUT_RIGHT] == 1 ){
		if( element_point > 0 && type_ok == 1 ){
			select_element[number]++;
			element_point--;
			//�����C���l�Čv�Z
			for( int i = 0; i < 15; i++ ){
				element_plus[i] = 0;
				for( int j = 0; j < 7; j++ ){
					element_plus[i] += Element_data[j][i] * select_element[j];
				}
			}
		//�ŏI�m�F��
			if( element_point == 0 ){
				type_ok++;
				number = 0;
			}
		}
	}
	return 0;
}

/*-----
�L�����쐬�̗���
-----*/
int Create_chara( int member_num ){

	//�ϐ���`
	static int step = 0;

	if( member_num < 10 ){

		//���g
		switch( step ){
			case 0:
				if( Name_input( member_num, 0 ) == 1 ) step++;
				break;

			case 1:
				if( chara_edit( member_num ) == 1 ){
					step = 0;
					return 1;
				}
		}
	}else{
		if( ok_message( "����ȏ�쐬�ł��܂���" ) == 1 ) return 1;
	}

	//�p����
	return 0;
}

/*-----
�����֌W
-----*/
int craft_main( int category ){

	//�ϐ���`
	static int list_ok = 0;

	//�`��Ə���
	//���X�g����
	if( list_ok == 0 ){
		switch( category ){
			case 0: //����
				break;
				
			case 1: //����
				break;

			case 2: //�h��
				break;

			case 3: //���
				break;

			case 4: //�X�s���b�g
				break;
		}
		list_ok = 1;
	}

	//�����t

	//���s��
	return 0;
}


/*-----
�X�e�[�^�X���
-----*/
int draw_status( int menber_num ){

	//�ϐ���`
	char status_name[][20] = {"�@��",
							  "�̗�",
							  "��p",
							  "����",
							  "����",
							  "���_",
							  "�V��",
							  "�����U��",
							  "�����h��",
							  "�@������",
							  "�@����",
							  "�U�����x",
							  "���_�U��",
							  "���_�h��",
							  "�W�����x",
							  "���_�K��",
							  "�����ϐ�",
							  "��ԑϐ�"};

	//�Ƃ肠�����`�悵�Ă݂�
	Draw_window( 0, 640, 30, 350 );

	//��摜
	DrawExtendGraph( 35, 35, 125, 125, imgtest , FALSE );

	//���O
	DrawFormatString( 150, 40, Color[0], "%s", Charaname[System_save_data.party_no[menber_num]] );

	//hp,sp
	DrawGraph( 150, 70, Guage[0], TRUE );
	SetDrawArea( 150, 70, 150 + ( 120 * ( Chara_save_data[System_save_data.party_no[menber_num]].hp / float(Chara_save_data[System_save_data.party_no[menber_num]].main_status[0][0]))), 100 );
	DrawGraph( 150, 70, Guage[1], TRUE );
	SetDrawArea( 186, 70, 186 + ( 70 * ( Chara_save_data[System_save_data.party_no[menber_num]].sp / float(Chara_save_data[System_save_data.party_no[menber_num]].main_status[1][0]))), 100 );
	DrawGraph( 150, 70, Guage[2], TRUE );
	SetDrawArea( 0, 0, 640, 480 );
	//�l
	GnumDraw( Chara_save_data[System_save_data.party_no[menber_num]].hp, 0, 220, 70 );
	DrawStringToHandle( 230, 70, "/", Color[0], Font[1] );
	GnumDraw( int(Chara_save_data[System_save_data.party_no[menber_num]].fix_status[0]), 0, 270, 70 );
	GnumDraw( Chara_save_data[System_save_data.party_no[menber_num]].sp, 0, 270, 88 );
	DrawStringToHandle( 280, 88, "/", Color[0], Font[1] );
	GnumDraw( int(Chara_save_data[System_save_data.party_no[menber_num]].fix_status[1]), 0, 310, 88 );

	//��b�X�e�[�^�X
	for( int i = 0; i < 7; i++ ){
		DrawFormatString( 20, 130 + ( i * 20 ), Color[9], "%s", status_name[i] );
		DrawFormatString( 90, 130 + ( i * 20 ), Color[0], "%d", int(Chara_save_data[System_save_data.party_no[menber_num]].fix_status[2 + i]) );
	}

	//�����X�e�[�^�X
	DrawFormatString( 140, 130, Color[9], "%s", status_name[7] );
	DrawFormatString( 140, 150, Color[0], "%d�`%d : %d��", Chara_save_data[System_save_data.party_no[menber_num]].fix_status[9], Chara_save_data[System_save_data.party_no[menber_num]].fix_status[10], Chara_save_data[System_save_data.party_no[menber_num]].fix_status[11] );

	for( int i = 0; i < 8; i++ ){
		DrawFormatString( 140, 170 + ( i * 20 ), Color[9], "%s", status_name[8 + i] );
		DrawFormatString( 240, 170 + ( i * 20 ), Color[0], "%d", Chara_save_data[System_save_data.party_no[menber_num]].fix_status[12 + i] );
	}
	
	//�����ϐ�
	DrawFormatString( 420, 40, Color[9], "�����ϐ�");
	DrawFormatString( 340, 60, Color[0], "��:%d", Chara_save_data[System_save_data.party_no[menber_num]].element[0] );
	DrawFormatString( 400, 60, Color[0], "��:%d", Chara_save_data[System_save_data.party_no[menber_num]].element[1] );
	DrawFormatString( 460, 60, Color[0], "�n:%d", Chara_save_data[System_save_data.party_no[menber_num]].element[2] );
	DrawFormatString( 340, 80, Color[0], "��:%d", Chara_save_data[System_save_data.party_no[menber_num]].element[3] );
	DrawFormatString( 400, 80, Color[0], "��:%d", Chara_save_data[System_save_data.party_no[menber_num]].element[4] );
	DrawFormatString( 460, 80, Color[0], "��:%d", Chara_save_data[System_save_data.party_no[menber_num]].element[5] );
	DrawFormatString( 520, 80, Color[0], "��:%d", Chara_save_data[System_save_data.party_no[menber_num]].element[6] );

	//�c�X�e�[�^�X�|�C���g
	DrawFormatString( 20, 290, Color[9], "STpt" );
	DrawFormatString( 90, 290, Color[0], "%d", Chara_save_data[System_save_data.party_no[menber_num]].status_point );

	//����A�h��A�X�s���b�g
	DrawFormatStringToHandle( 400, 106, Color[8], Font[1], "����" );
	if( Chara_save_data[menber_num].weapon_no != -1 ) DrawFormatString( 410, 110, Color[0], "%s", Item_weapon_data[Item_save_data.weapon[Chara_save_data[menber_num].weapon_no][0]].name );
	DrawFormatStringToHandle( 400, 126, Color[8], Font[1], "�h��" );
	if( Chara_save_data[menber_num].armor_no != -1 ) DrawFormatString( 410, 130, Color[0], "%s", Item_armor_data[Item_save_data.armor[Chara_save_data[menber_num].armor_no][0]].name );
	DrawFormatStringToHandle( 400, 146, Color[8], Font[1], "�X�s���b�g" );
	if( Chara_save_data[menber_num].spilit_no != -1 ) DrawFormatString( 410, 150, Color[0], "%s", Item_spilit_data[Item_save_data.spilit[Chara_save_data[menber_num].spilit_no][0]].name );

	//�I�����}
	if( Keystate[KEY_INPUT_Z] == 1 ) return 1;

	//���s���Ԓl
	return 0;
}

//�X�e�[�^�X�|�C���g�̊��U��
//����:�p�[�e�B���ʒl
int Set_status_point( int member_num ){

	//�ϐ���`
	static int setpoint[9][2];
	static int load_ok = 0;
	static int status_point;
	static int return_question = 0;
	static int select = 0;

	//�萔��`
	char status_name[][20] = {"�g�o",
							  "�r�o",
							  "�@��",
							  "�̗�",
							  "��p",
							  "����",
							  "����",
							  "���_",
							  "�V��",
							  "�����U��",
							  "�����h��",
							  "�@������",
							  "�@����",
							  "�U�����x",
							  "���_�U��",
							  "���_�h��",
							  "�W�����x",
							  "���_�K��",
							  "�����ϐ�",
							  "��ԑϐ�"};

	
	//����
	//�����J�n���̃f�[�^���Z�b�g
	if( load_ok == 0 ){
		for( int i = 0; i < 9; i++ ){
			setpoint[i][0] = 0;
			setpoint[i][1] = Chara_save_data[System_save_data.party_no[member_num]].main_status[i][2];
		}
		status_point = Chara_save_data[System_save_data.party_no[member_num]].status_point;
		select = 0;
		load_ok = 1;
	}
	//�`��
	Draw_window( 40, 480, 160, 350);
	//��b�X�e�[�^�X
	for( int i = 0; i < 9; i++ ){
		DrawFormatString( 60, 165 + ( i * 20 ), Color[9], "%s", status_name[i] );
		DrawFormatString( 110, 165 + ( i * 20 ), Color[0], "%d", int(Chara_save_data[System_save_data.party_no[member_num]].main_status[i][0]) );
		DrawFormatString( 145, 165 + ( i * 20 ), Color[0], "+%d   (%d pt)", setpoint[i][0], setpoint[i][1] );
	}
	//�I��g
	Draw_select( 58, 270, 164 + ( select * 20 ), 186 + ( select * 20 ) );

	//�����t
	if( return_question == 1 ){
		int yes_no = yes_no_message( "�I�����SP�͐U�����܂���", "�U�����������܂����H" );
		switch( yes_no ){
			case 1:
				//���U��̔��f
				for( int i = 0; i < 9; i++ ){
					Chara_save_data[member_num].main_status[i][0] += setpoint[i][0];
				}
				Chara_status_calculate( member_num );
				Chara_save_data[member_num].status_point = status_point;
				return 1;

			case 2:
				return_question = 0;
				break;
		}
	}else{
		if( Keystate[KEY_INPUT_Z] == 1 ){
			return_question = 1;
		}else if( Keystate[KEY_INPUT_X] == 1 ){
			load_ok = 0;
			return 1;
		}else if( Keystate[KEY_INPUT_UP] == 1 && select > 0 ){
			select--;
		}else if( Keystate[KEY_INPUT_DOWN] == 1 && select < 8 ){
			select++;
		}else if( Keystate[KEY_INPUT_LEFT] == 1 ){
			if( setpoint[select][0] > 0 ){
				setpoint[select][0]--;
				status_point += setpoint[select][1];
			}else{
			}
		}else if( Keystate[KEY_INPUT_RIGHT] == 1 ){
			if( setpoint[select][1] < status_point ){
				setpoint[select][0]++;
				status_point -= setpoint[select][1];
			}else{
			}
		}
	}



	//���s���Ԓl
	return 0;
}

/*-----
����
-----*/
int draw_equip( int member_num ){

	//�ϐ���`
	static int janc[2] = { 0, 0 };
	static int list[400];
	static int step = 0;
	int cr;
	static int list_ok = 1;
	static int select = 0;
	static int listnum;
	static int change[21];
	static int equip[15];
	static int draw_time = 0;

	//�萔��`

	const char Element_name[][15] = {"�y�Α����z",
									 "�y�������z",
									 "�y�n�����z",
									 "�y�������z",
									 "�y�������z",
									 "�y�ő����z",
									 "�y�������z"};	

	char info[][20] = { "����",
						"�h��",
						"�X�s���b�g",
						"������",
						"",
						"",
						"",
						"",
						"",
						"",
						"",
						"�h����",
						"",
						"",
						"",
						"",
						"",
						"",
						""};

	char status_name[][20] = {"�@�@�@��",
							  "�@�@�̗�",
							  "�@�@��p",
							  "�@�@����",
							  "�@�@����",
							  "�@�@���_",
							  "�@�@�V��",
							  "�����U��",
							  "",
							  "�����h��",
							  "�@������",
							  "�@����",
							  "�U�����x",
							  "���_�U��",
							  "���_�h��",
							  "�W�����x",
							  "���_�K��",
							  "�����ϐ�",
							  "��ԑϐ�"};

	//�����\���X�g����
	if( list_ok != 1 ){
		listnum = 0;
		for( int i = 0; i < 400; i++ ){
			list[i] = -1;
		}
		switch( janc[0] ){
			case 0:
				for( int i = 0; i < 200; i++ ){
					if( Item_save_data.weapon[i][0] != -1 && Item_save_data.weapon[i][5] == -1 ){
						list[listnum] = i;
						listnum++;
					}
				}
				break;

			case 1:
				for( int i = 0; i < 200; i++ ){
					if( Item_save_data.armor[i][0] != -1 && Item_save_data.armor[i][4] == -1 ){
						list[listnum] = i;
						listnum++;
					}
				}
				break;

			case 2:
				for( int i = 0; i < 200; i++ ){
					if( Item_save_data.spilit[i][0] != 0 ){
						list[listnum] = i;
						listnum++;
					}
				}
				break;

			default:
				for( int i = 0; i < 200; i++ ){
					if( Item_save_data.juwel[i][0] - Item_save_data.juwel[i][1] > 0 ){
						list[listnum] = i;
						listnum++;
					}
				}
				break;
		}
		list_ok = 1;
	}


	//�������\��
	Draw_window( 0, 180, 120, 360 );
	Draw_window( 0, 440, 30, 120 );
	for( int i = 0; i < 16; i++ ){
		//DrawStringToHandle( 30, 125 + ( 14 * i ), "��������", Color[0], Font[2] );
		DrawFormatStringToHandle( 5, 120 + ( 14 * i ), Color[8], Font[1], info[i] );

		switch( i ){
			case 0:
				if( Chara_save_data[System_save_data.party_no[member_num]].weapon_no != -1 ) DrawFormatStringToHandle( 30, 125 + ( 14 * i ), Color[0], Font[2], Item_weapon_data[Item_save_data.weapon[Chara_save_data[System_save_data.party_no[member_num]].weapon_no][0]].name );
				break;

			case 1:
				if( Chara_save_data[System_save_data.party_no[member_num]].armor_no != -1 ) DrawFormatStringToHandle( 30, 125 + ( 14 * i ), Color[0], Font[2], Item_armor_data[Item_save_data.armor[Chara_save_data[System_save_data.party_no[member_num]].armor_no][0]].name );
				break;

			case 2:
				if( Chara_save_data[System_save_data.party_no[member_num]].spilit_no != -1 ) DrawFormatStringToHandle( 30, 125 + ( 14 * i ), Color[0], Font[2], Item_spilit_data[Item_save_data.spilit[Chara_save_data[System_save_data.party_no[member_num]].spilit_no][0]].name );
				break;

			default:
				if( i < 11 ){
					if( Chara_save_data[System_save_data.party_no[member_num]].weapon_juel_no[i - 3] != -1 ) DrawFormatStringToHandle( 30, 125 + ( 14 * i ), Color[0], Font[2], Item_juel_data[Chara_save_data[System_save_data.party_no[member_num]].weapon_juel_no[i - 3]].name );
					else if( Item_weapon_data[Chara_save_data[System_save_data.party_no[member_num]].weapon_no].slot < i - 2 ) DrawFormatStringToHandle( 30, 125 + ( 14 * i ), Color[0], Font[2], "--No Slot--" );
				}else{
					if( Chara_save_data[System_save_data.party_no[member_num]].armor_juel_no[i - 11] != -1 ) DrawFormatStringToHandle( 30, 125 + ( 14 * i ), Color[0], Font[2], Item_juel_data[Chara_save_data[System_save_data.party_no[member_num]].armor_juel_no[i - 11]].name );	
					else if( Item_armor_data[Chara_save_data[System_save_data.party_no[member_num]].armor_no].slot < i - 10 ) DrawFormatStringToHandle( 30, 125 + ( 14 * i ), Color[0], Font[2], "--No Slot--" );
				}
		}
	}
	//�I��g,�����\��
	if( step == 0 ){
		//���������\��
		if( select == 0 && Chara_save_data[System_save_data.party_no[member_num]].weapon_no != -1 ){
			DrawFormatString( 5, 35, Color[0], "�U��%d-%d", Item_save_data.weapon[Chara_save_data[System_save_data.party_no[member_num]].weapon_no][3], Item_save_data.weapon[Chara_save_data[System_save_data.party_no[member_num]].weapon_no][2] );
			DrawFormatString( 115, 35, Color[0], "%s", Element_name[Item_weapon_data[Item_save_data.weapon[Chara_save_data[System_save_data.party_no[member_num]].weapon_no][0]].element] ); 
			DrawFormatString( 205, 35, Color[9 - Item_weapon_data[Item_save_data.weapon[Chara_save_data[System_save_data.party_no[member_num]].weapon_no][0]].info_color], "%s", Item_weapon_data[Item_save_data.weapon[Chara_save_data[System_save_data.party_no[member_num]].weapon_no][0]].infoplus );
			Message_draw( 5, 55, Item_weapon_data[Item_save_data.weapon[Chara_save_data[System_save_data.party_no[member_num]].weapon_no][0]].info, 520, GCounter - draw_time );
		}else if( select == 1 && Chara_save_data[System_save_data.party_no[member_num]].armor_no != -1 ){
			DrawFormatString( 5, 35, Color[0], "�h��%d�^%d", Item_save_data.armor[Chara_save_data[System_save_data.party_no[member_num]].armor_no][2], Item_save_data.armor[Chara_save_data[System_save_data.party_no[member_num]].armor_no][3] ); 
			DrawFormatString( 135, 35, Color[9 - Item_armor_data[Item_save_data.armor[Chara_save_data[System_save_data.party_no[member_num]].armor_no][0]].info_color], "%s", Item_armor_data[Item_save_data.armor[Chara_save_data[System_save_data.party_no[member_num]].armor_no][0]].infoplus );
			Message_draw( 5, 55, Item_armor_data[Item_save_data.armor[Chara_save_data[System_save_data.party_no[member_num]].armor_no][0]].info, 520, GCounter - draw_time );
		}else if( select == 2 ){
			DrawString( 5, 35, "�X�s���b�g�����͌��ݖ������ł��B", Color[0] );
		}else if( select > 2 && select <= 10 && Chara_save_data[System_save_data.party_no[member_num]].weapon_juel_no[select - 3] != -1 ){
			DrawFormatString( 5, 35, Color[9], "%s", Item_juel_data[Chara_save_data[System_save_data.party_no[member_num]].weapon_juel_no[select - 3]].infoplus );
			Message_draw( 5, 55, Item_juel_data[Chara_save_data[System_save_data.party_no[member_num]].weapon_juel_no[select - 3]].info, 520, GCounter - draw_time );
			Draw_window( 440, 640, 0, 120 );
			DrawString( 470, 5, "�g�p�\�X�L��", Color[0] );
			for( int i = 0; i < 3; i++ ){
				if( Item_juel_data[Chara_save_data[System_save_data.party_no[member_num]].weapon_juel_no[select - 3]].skill[i] != -1 ){
					DrawFormatStringToHandle( 450, 35 + ( 20 * i ), Color[9], Font[0], Skill_data[Item_juel_data[Chara_save_data[System_save_data.party_no[member_num]].weapon_juel_no[select - 3]].skill[i]].name );
				}else if( i == 0 ){
					DrawFormatString( 450, 35, Color[1], "NoLearnSkill" );
				}
			}
		}else if( select > 10 && Chara_save_data[System_save_data.party_no[member_num]].weapon_juel_no[select - 11] != -1 ){
			DrawFormatString( 5, 35, Color[9], "%s", Item_juel_data[Chara_save_data[System_save_data.party_no[member_num]].armor_juel_no[select - 11]].infoplus );
			Message_draw( 5, 55, Item_juel_data[Chara_save_data[System_save_data.party_no[member_num]].armor_juel_no[select - 11]].info, 520, GCounter - draw_time );
			Draw_window( 440, 640, 0, 120 );
			DrawString( 470, 5, "�g�p�\�X�L��", Color[0] );
			for( int i = 0; i < 3; i++ ){
				if( Item_juel_data[Chara_save_data[System_save_data.party_no[member_num]].armor_juel_no[select - 11]].skill[i] != -1 ){
					DrawFormatStringToHandle( 450, 35 + ( 20 * i ), Color[9], Font[0], Skill_data[Item_juel_data[Chara_save_data[System_save_data.party_no[member_num]].armor_juel_no[select - 11]].skill[i]].name );
				}else if( i == 0 ){
					DrawFormatString( 450, 35, Color[1], "NoLearnSkill" );
				}
			}
		}
		Draw_select( 2, 178, 124 + ( select * 14), 141 + ( select * 14 ));
	}else{

	}

	//�X�e�[�^�X�ϓ�
	Draw_window( 180, 440, 120, 360 );
	for( int i = 0; i < 17; i++ ){
		DrawFormatStringToHandle( 190, 120 + ( 14 * i ), Color[9], Font[2], status_name[i] );
		if( i < 7 ){
			DrawFormatStringToHandle( 250, 120 + ( 14 * i ), Color[0], Font[2], "%d", Chara_save_data[System_save_data.party_no[member_num]].fix_status[i + 2] );
		}else if( i == 7 ){
			DrawFormatStringToHandle( 190, 134 + ( 14 * i ), Color[0], Font[2], "%d�`%d:%d��", Chara_save_data[System_save_data.party_no[member_num]].fix_status[i + 2], Chara_save_data[System_save_data.party_no[member_num]].fix_status[i + 3], Chara_save_data[System_save_data.party_no[member_num]].fix_status[i + 4] );
		}else if( i > 7 && i < 16 ){
			DrawFormatStringToHandle( 250, 134 + ( 14 * i ), Color[0], Font[2], "%d", Chara_save_data[System_save_data.party_no[member_num]].fix_status[i + 4] );
		}

	}

	//�����I��
	for( int i = 0; i < 16; i++ ){
		switch( i ){
			case 0:
				if( janc[0] == i ) equip[i] = list[select + janc[1]];
				else equip[i] = Chara_save_data[System_save_data.party_no[member_num]].weapon_no;
				break;

			case 1:
				if( janc[0] == i ) equip[i] = list[select + janc[1]];
				else equip[i] = Chara_save_data[System_save_data.party_no[member_num]].armor_no;
				break;

			case 2:
				if( janc[0] == i ) equip[i] = list[select + janc[1]];
				else equip[i] = Chara_save_data[System_save_data.party_no[member_num]].spilit_no;
				break;

			default:
				if( i < 11 ){
					if( janc[0] == i ) equip[i] = list[select + janc[1]];
					 else equip[i] = Chara_save_data[System_save_data.party_no[member_num]].weapon_juel_no[i - 3];
				}else{
					if( janc[0] == i ) equip[i] = list[select + janc[1]];
					else equip[i] = Chara_save_data[System_save_data.party_no[member_num]].armor_juel_no[i - 11];
				}
		}
	}
	Chara_status_calculate_int( member_num, change, equip );
	if( step == 1 ){
		if( listnum > 0 ){
			for( int i = 0; i < 17; i++ ){
				if( i != 7 ) DrawStringToHandle( 300, 120 + ( 14 * i ), "��", Color[0], Font[2] );
				cr = 0;
				if( i < 7 ){
					if( Chara_save_data[System_save_data.party_no[member_num]].fix_status[i + 2] < change[i + 2] ) cr = 13;
					else if( Chara_save_data[System_save_data.party_no[member_num]].fix_status[i + 2] > change[i + 2] ) cr = 14;
					DrawFormatStringToHandle( 320, 120 + ( 14 * i ), Color[cr], Font[2], "%d", change[i + 2] );
				}else if( i == 7 ){
					if( Chara_save_data[System_save_data.party_no[member_num]].fix_status[i + 2] < change[i + 2] ) cr = 13;
					else if( Chara_save_data[System_save_data.party_no[member_num]].fix_status[i + 2] > change[i + 2] ) cr = 14;
					DrawFormatStringToHandle( 320, 134 + ( 14 * i ), Color[cr], Font[2], "%d", change[i + 2] );
					DrawStringToHandle( 345, 134 + ( 14 * i ), "�`", Color[0], Font[2] );
					if( Chara_save_data[System_save_data.party_no[member_num]].fix_status[i + 3] < change[i + 3] ) cr = 13;
					else if( Chara_save_data[System_save_data.party_no[member_num]].fix_status[i + 3] > change[i + 3] ) cr = 14;
					else cr = 0;
					DrawFormatStringToHandle( 360, 134 + ( 14 * i ), Color[cr], Font[2], "%d", change[i + 3] );
					DrawStringToHandle( 385, 134 + ( 14 * i ), ":", Color[0], Font[2] );
					if( Chara_save_data[System_save_data.party_no[member_num]].fix_status[i + 4] < change[i + 4] ) cr = 13;
					else if( Chara_save_data[System_save_data.party_no[member_num]].fix_status[i + 4] > change[i + 4] ) cr = 14;
					else cr = 0;
					DrawFormatStringToHandle( 395, 134 + ( 14 * i ), Color[cr], Font[2], "%d��", change[i + 4] );
				}else if( i > 7 && i < 16 ){
					if( i == 11 || i == 14 ){
						if( Chara_save_data[System_save_data.party_no[member_num]].fix_status[i + 4] < change[i + 4] ) cr = 14;
						else if( Chara_save_data[System_save_data.party_no[member_num]].fix_status[i + 4] > change[i + 4] ) cr = 13;
					}else{
						if( Chara_save_data[System_save_data.party_no[member_num]].fix_status[i + 4] < change[i + 4] ) cr = 13;
						else if( Chara_save_data[System_save_data.party_no[member_num]].fix_status[i + 4] > change[i + 4] ) cr = 14;
					}
					DrawFormatStringToHandle( 320, 134 + ( 14 * i ), Color[cr], Font[2], "%d", change[i + 4] );
				}
			}
		}

		//�������
		if( listnum > 0 ){
			Draw_window( 440, 640, 120, 350 );
			switch( janc[0] ){
				case 0:
					for( int i = 0; i < 10; i++ ){
						DrawFormatString( 445, 125 + ( i * 20 ), Color[0], "%s", Item_weapon_data[Item_save_data.weapon[list[janc[1] + i]][0]].name );
						if( janc[1] + i == listnum - 1 ) break;
					}
					break;

				case 1:
					for( int i = 0; i < 10; i++ ){
						DrawFormatString( 445, 125 + ( i * 20 ), Color[0], "%s", Item_armor_data[Item_save_data.armor[list[janc[1] + i]][0]].name );
						if( janc[1] + i == listnum - 1 ) break;
					}
					break;

				case 3:
					for( int i = 0; i < 10; i++ ){
						DrawFormatString( 445, 125 + ( i * 20 ), Color[0], "%s", Item_juel_data[list[janc[1] + i]].name );
						DrawFormatString( 445, 325 + ( i * 20 ), Color[0], "%d", Item_save_data.juwel[list[janc[1] + i]][0] - Item_save_data.juwel[list[janc[1] + i]][1] );
						if( janc[1] + i == listnum - 1 ) break;
					}
					break;

				case 4:
					for( int i = 0; i < 10; i++ ){
						DrawFormatString( 445, 125 + ( i * 20 ), Color[0], "%s", Item_juel_data[list[janc[1] + i]].name );
						DrawFormatString( 445, 325 + ( i * 20 ), Color[0], "%d", Item_save_data.juwel[list[janc[1] + i]][0] - Item_save_data.juwel[list[janc[1] + i]][1] );
						if( janc[1] + i == listnum - 1 ) break;
					}
			}
			Draw_select( 442, 638, 123 + ( select * 20), 145 + ( select * 20 ));
			//���������\��
			if( janc[0] == 0 ){
				DrawFormatString( 5, 35, Color[0], "�U��%d-%d", Item_save_data.weapon[list[janc[1] + select]][2], Item_save_data.weapon[list[janc[1] + select]][3] );
				DrawFormatString( 115, 35, Color[0], "%s", Element_name[Item_weapon_data[Item_save_data.weapon[list[janc[1] + select]][0]].element] ); 
				DrawFormatString( 205, 35, Color[9 - Item_weapon_data[Item_save_data.weapon[list[janc[1] + select]][0]].info_color], "%s", Item_weapon_data[Item_save_data.weapon[list[janc[1] + select]][0]].infoplus );
				Message_draw( 5, 55, Item_weapon_data[Item_save_data.weapon[list[janc[1] + select]][0]].info, 520, GCounter - draw_time );
			}else if( janc[0] == 1 ){
				DrawFormatString( 5, 35, Color[0], "�h��%d�^%d", Item_save_data.armor[list[janc[1] + select]][2], Item_save_data.armor[list[janc[1] + select]][3] ); 
				DrawFormatString( 135, 35, Color[9 - Item_armor_data[Item_save_data.armor[list[janc[1] + select]][0]].info_color], "%s", Item_armor_data[Item_save_data.armor[list[janc[1] + select]][0]].infoplus );
				Message_draw( 5, 55, Item_armor_data[Item_save_data.armor[list[janc[1] + select]][0]].info, 520, GCounter - draw_time );
			}else if( janc[0] == 2 ){
			}else if( janc[0] > 2 && select <= 9 ){
				DrawFormatString( 5, 35, Color[9], "%s", Item_juel_data[list[janc[1] + select]].infoplus );
				Message_draw( 5, 55, Item_juel_data[list[janc[1] + select]].info, 520, GCounter - draw_time );
				Draw_window( 440, 640, 0, 120 );
				DrawString( 470, 5, "�g�p�\�X�L��", Color[0] );
				for( int i = 0; i < 3; i++ ){
					if( Item_juel_data[list[janc[1] + select]].skill[i] != -1 ){
						DrawFormatStringToHandle( 450, 35 + ( 20 * i ), Color[9], Font[0], Skill_data[Item_juel_data[list[janc[1] + select]].skill[i]].name );
					}else if( i == 0 ){
						DrawFormatString( 450, 35, Color[1], "NoLearnSkill" );
					}
				}
			}else if( janc[0] > 9 ){
				DrawFormatString( 5, 35, Color[9], "%s", Item_juel_data[list[janc[1] + select]].infoplus );
				Message_draw( 5, 55, Item_juel_data[list[janc[1] + select]].info, 520, GCounter - draw_time );
				Draw_window( 440, 640, 0, 120 );
				DrawString( 470, 5, "�g�p�\�X�L��", Color[0] );
				for( int i = 0; i < 3; i++ ){
					if( Item_juel_data[list[janc[1] + select]].skill[i] != -1 ){
						DrawFormatStringToHandle( 450, 35 + ( 20 * i ), Color[9], Font[0], Skill_data[Item_juel_data[list[janc[1] + select]].skill[i]].name );
					}else if( i == 0 ){
						DrawFormatString( 450, 35, Color[1], "NoLearnSkill" );
					}
				}
			}
		}else{
			if( ok_message( "�����ł�����̂�����܂���B" ) == 1 ){
				step = 0;
				select = 0;
				goto END;
			}
		}

	}

	//�����t
	if( Keystate[KEY_INPUT_Z] == 1 ){
		if( step == 0 ){
			janc[0] = select;
			list_ok = 0;
			select = 0;
			step++;
		}else{
			switch( janc[0] ){
				case 0:
					if( Chara_save_data[System_save_data.party_no[member_num]].weapon_no != -1 ) Item_save_data.weapon[ Chara_save_data[System_save_data.party_no[member_num]].weapon_no ][5] = -1;
					Chara_save_data[System_save_data.party_no[member_num]].weapon_no = list[select + janc[1]];
					Item_save_data.weapon[list[select + janc[1]]][5] = System_save_data.party_no[member_num];
					break;

				case 1:
					if( Chara_save_data[System_save_data.party_no[member_num]].armor_no != -1 ) Item_save_data.armor[ Chara_save_data[System_save_data.party_no[member_num]].armor_no ][4] = -1;
					Chara_save_data[System_save_data.party_no[member_num]].armor_no = list[select + janc[1]];
					Item_save_data.armor[list[select + janc[1]]][4] = System_save_data.party_no[member_num];
					break;

				case 2:
					Chara_save_data[System_save_data.party_no[member_num]].spilit_no = select + janc[1];
					Item_save_data.spilit[select + janc[1]][4] = System_save_data.party_no[member_num];
					break;

				default:
					if( janc[0] < 9 ){
						Chara_save_data[System_save_data.party_no[member_num]].weapon_juel_no[janc[0] - 3] = list[select + janc[1]];
						Item_save_data.juwel[list[select + janc[1]]][1]++;
					}else{
						Chara_save_data[System_save_data.party_no[member_num]].armor_juel_no[janc[0] - 9] = list[select + janc[1]];
						Item_save_data.juwel[list[select + janc[1]]][1]++;
					}
					Chara_skill_calculate( System_save_data.party_no[member_num] );
			}
			Chara_status_calculate( member_num );
			step = 0;
			select = janc[0];

		}
	}else if( Keystate[KEY_INPUT_X] == 1 ){
		if( step == 1 ){
			step--;
			draw_time = GCounter;
		}else return 1;
	}else if( Keystate[KEY_INPUT_UP] == 1 && select > 0 ){
		if( step == 0 ){
			select--;
		}else if( step == 1 ){
			select--;
			if( janc[1] > select ) janc[1] = select;
		}
		draw_time = GCounter;
	}else if( Keystate[KEY_INPUT_DOWN] == 1 && select < 15 ){
		if( step == 0 ){
			select++;
		}else if( step == 1 && select < 10 && select < listnum - 1 ){
			select++;
			if( janc[1] + 9 < select ) janc[1] = select - 9;
		}
		draw_time = GCounter;
	}

END:
	//���s���Ԓl
	return 0;
}

/*-----
�A�C�e���̎g�p
-----*/
void item_use( int number, int target, int usemember, int paturn ){

	//�ϐ���`
	int mesdrawnum;
	char messagingnum[10];
	char message[100] = "";

	//�g�����I
	if( paturn != 2 ){
		strcat( message, Charaname[usemember] );
	}else{
		strcat( message, "�p�[�e�B" );
	}
	strcat( message, "�� " );
	strcat( message, Item_use_data[number].name );
	strcat( message, " ���g�����I" );
	mes_send( message );
	strcpy( message, "" );
	//����
	switch( Item_use_data[number].type ){
		case 1://hp��
			if( Battle_pt[target].effect_state[999][0] == 0 ){
				mesdrawnum = Chara_save_data[System_save_data.party_no[target]].fix_status[0] - Chara_save_data[System_save_data.party_no[target]].hp;
				if( mesdrawnum > Item_use_data[number].effect ) mesdrawnum = Item_use_data[number].effect;
				strcat( message, Charaname[target] );
				strcat( message, "��HP�� " );
				itoa( mesdrawnum, messagingnum, 10 );
				strcat( message, messagingnum );
				strcat( message, " �񕜂����I" );
				mes_send( message );
				Get_repair( mesdrawnum, 0, target, 2 );
				Item_save_data.use[number]--;
			}else{
				mes_send( "�C�₵�Ă��Ďg���Ȃ��悤���c" );
			}
			break;

		case 2://sp��
			if( Battle_pt[target].effect_state[999][0] == 0 ){
				mesdrawnum = Chara_save_data[System_save_data.party_no[target]].fix_status[1] - Chara_save_data[System_save_data.party_no[target]].sp;
				if( mesdrawnum > Item_use_data[number].effect ) mesdrawnum = Item_use_data[number].effect;
				strcat( message, Charaname[target] );
				strcat( message, "��SP�� " );
				itoa( mesdrawnum, messagingnum, 10 );
				strcat( message, messagingnum );
				strcat( message, " �񕜂����I" );
				mes_send( message );
				Get_repair( mesdrawnum, 0, target, 3 );
				Item_save_data.use[number]--;
			}else{
				mes_send( "�C�₵�Ă��Ďg���Ȃ��悤���c" );
			}
			break;

		case 3://��ԉ�
			break;

		case 4://�h��
			if( Battle_pt[target].effect_state[999][0] == 1 ){
				mesdrawnum = Chara_save_data[System_save_data.party_no[target]].fix_status[0] - Chara_save_data[System_save_data.party_no[target]].hp;
				if( mesdrawnum > Item_use_data[number].effect ) mesdrawnum = Item_use_data[number].effect;
				Chara_save_data[System_save_data.party_no[target]].hp += Item_use_data[number].effect;
				if( Chara_save_data[System_save_data.party_no[target]].hp > Chara_save_data[System_save_data.party_no[target]].fix_status[0] ) Chara_save_data[System_save_data.party_no[target]].hp = Chara_save_data[System_save_data.party_no[target]].fix_status[0];
				strcat( message, Charaname[target] );
				strcat( message, "�͍Ăї����オ�����I" );
				mes_send( message );
				Item_save_data.use[number]--;
			}else{
				mes_send( "�����������N���Ȃ������c" );
			}
			break;

		case 5://hp���W�F�l
			break;

		case 6://sp���W�F�l
			break;
	}

}

//�A�C�e���֌W��ʕ`��
int item_draw(){
	//�ϐ���`
	static int select = 0;
	static int draw_time = GCounter;
	static int use_member = 0;
	static int select_ok = 0;
	static int category = 0;
	static int list[200];
	static int list_num = 0;
	static int list_ok = 0;

	//�萔��`
	const char category_name[][20] = {"�g�p",
									  "�z�Αf��",
									  "�A���f��",
									  "�G�f��",
									  "����",
									  "�h��",
									  "�X�s���b�g",
									  "���"};

	const char effect_info[][100] ={"�yHp�񕜁z�񕜗�:",
									"�ySp�񕜁z�񕜗�:",
									"�y��ԉ񕜁z",
									"�y�C�╜�A�z�񕜗�:",
									"�yHp�����񕜁z�񕜌���:1/",
									"�ySp�����񕜁z�񕜌���:1/",
									"",
									"",
									"",
									"�y����z����̗p�r�Ŏg�p"};

	const char state_name[][15] =  {"��","���","�È�","����","�ݑ�",
									"","","","","",
									""};
	
	//�A�C�e�����X�g����
	if( list_ok == 0 ){
		list_num = 0;
		for( int i = 0; i < 200; i++ ) list[i] = 0;
		switch( category ){
			case 0:
				for( int i = 0; i < 100; i++ ){
					if( Item_save_data.use[i] > 0 ){
						list[list_num] = i;
						list_num++;
					}
				}
				break;

			case 1:
				for( int i = 0; i < ITEM_MATEL_NUM; i++ ){
					if( Item_save_data.matel[i] > 0 ){
						if( Item_matel_data[i].type <= 8 || Item_matel_data[i].type == 11 || Item_matel_data[i].type == 12 ){
							list[list_num] = i;
							list_num++;
						}
					}
				}
				break;

			case 2:
				for( int i = 0; i < ITEM_MATEL_NUM; i++ ){
					if( Item_save_data.matel[i] > 0 ){
						if( Item_matel_data[i].type == 9 || Item_matel_data[i].type == 10 ){
							list[list_num] = i;
							list_num++;
						}
					}
				}
				break;

			case 3:
				for( int i = 0; i < ITEM_MATEL_NUM; i++ ){
					if( Item_save_data.matel[i] > 0 ){
						if( Item_matel_data[i].type >= 13 ){
							list[list_num] = i;
							list_num++;
						}
					}
				}
				break;


		}
		list_ok++;
	}

	//�`��֌W
	//�J�e�S���I��\��
	Draw_window( 0, 100, 120, 150 );
	DrawFormatString( 17, 125, Color[0], "%s", category_name[category] );
	if( select_ok == 0 ){
		DrawRotaGraph( 10, 135, 1.0, 0, M_Arrow, TRUE );
		DrawRotaGraph( 90, 135, 1.0, 1 * PI, M_Arrow, TRUE );
	}

	//�����E�C���h�E
	Draw_window( 0, 440, 30, 120 );
	if( select_ok == 0 ){
		DrawString( 5, 35, "���E�Ŏg�p�A�{������J�e�S����I��", Color[0] );
	}else if( select_ok == 1 && category == 0 && list_num > 1 ){
		if( Item_use_data[list[select]].type == 10 ){
			DrawFormatString( 5, 35, Color[9], "%s", effect_info[Item_use_data[list[select]].type - 1] );
		}else if( Item_use_data[list[select]].type == 3 ){
			DrawFormatString( 5, 35, Color[9], "%s %s", effect_info[Item_use_data[list[select]].type - 1], state_name[Item_use_data[list[select]].effect - 1] );
		}else{
			DrawFormatString( 5, 35, Color[9], "%s %d", effect_info[Item_use_data[list[select]].type - 1], Item_use_data[list[select]].effect );
		}
		Message_draw( 5, 55, Item_use_data[list[select]].info, 520, GCounter - draw_time );
	}

	//�A�C�e�����X�g
	Draw_window( 100, 540, 120, 370 );
	if( list_num > 0 ){
		for( int i = 0; i < 24; i++ ){
			if(category == 0 ){
				DrawFormatString( 105 + ( ( i % 2 ) * 215 ), 125 + ( ( i / 2 ) * 20 ), Color[1 - Item_use_data[list[i]].out_use_ok], "%s", Item_use_data[list[i]].name );
				DrawFormatString( 300 + ( ( i % 2 ) * 215 ), 125 + ( ( i / 2 ) * 20 ), Color[1 - Item_use_data[list[i]].out_use_ok], "%d", Item_save_data.use[list[i]] );
			}else{
				DrawFormatString( 105 + ( ( i % 2 ) * 215 ), 125 + ( ( i / 2 ) * 20 ), Color[1], "%s", Item_matel_data[list[i]].name );
				DrawFormatString( 300 + ( ( i % 2 ) * 215 ), 125 + ( ( i / 2 ) * 20 ), Color[1], "%d", Item_save_data.matel[list[i]] );
			}
			if( i ==list_num - 1 ) break;
		}
		//�I��g
		if( select_ok == 1 ){
			Draw_select( 101, 319, 123, 147 );
		}
	}else{
		DrawString( 105, 125, "�������Ă���A�C�e��������܂���", Color[0] );
	}

	//�����t
	if( select_ok == 2 ){
		use_member = B_target_select( 0, -1 );
		if( use_member >= 0 ){
			item_use( list[select], use_member, 0, 2 );
			if( Item_save_data.use[list[select]] == 0 ){
				select_ok = 0;
				list_ok = 0;
			}
		}else if( use_member == -2 ){
			select_ok--;
		}
	}else{
		if( Keystate[KEY_INPUT_Z] == 1 ){
			if( select_ok == 0 && list_num > 0 ){
				select_ok++;
			}else if( select_ok == 1 && category == 0 ){
				if( Item_use_data[list[select]].out_use_ok == 1 ) select_ok++;
			}
		}else if( Keystate[KEY_INPUT_X] == 1 ){
			if( select_ok == 0 ){
				select = 0;
				return 1;
			}else{
				select_ok--;
			}
		}else if( Keystate[KEY_INPUT_UP] == 1 ){
			if( select_ok == 1 && select > 1 ){
				select -= 2;
				draw_time = GCounter;
			}
		}else if( Keystate[KEY_INPUT_DOWN] == 1 ){
			if( select_ok == 1 && select < list_num - 2 ){
				select += 2;
				draw_time = GCounter;
			}else if( select_ok == 1){
				select = list_num;
				draw_time = GCounter;
			}
		}else if( Keystate[KEY_INPUT_LEFT] == 1 ){
			if( select_ok == 0 ){
				if( category == 0 ) category = 3;
				else category--;
				list_ok = 0;
			}else if( select_ok == 1 && select > 0 ){
				select--;
				draw_time = GCounter;
			}
		}else if( Keystate[KEY_INPUT_RIGHT] == 1 ){
			if( select_ok == 0 ){
				if( category == 3 ) category = 0;
				else category++;
				list_ok = 0;
			}else if( select_ok == 1 && select < list_num ){
				select++;
				draw_time = GCounter;
			}
		}
	}

	//���s��
	return 0;
}

/*-----
�X�L�������֌W
-----*/

//�L�����v���X�L������
//����:����������X�L���ԍ�,�g�p��,�Ώ�
void Camp_skill( int skill_no, int acter, int target ){
	
	//�ϐ���`
	int decision[3]; //����l�i�[�p
	char message[100] = "";

	//����
	switch( Skill_data[skill_no].cls ){
		case 1: //hp��

			//���s�s����
			if( Chara_save_data[System_save_data.party_no[target]].hp == Chara_save_data[System_save_data.party_no[target]].fix_status[0] || Chara_save_data[System_save_data.party_no[target]].sp < Skill_data[skill_no].sp || Battle_pt[target].effect_state[999][0] == 1 ) break;

			//���ʂ̔��f
			Hit_recover_calc( decision, acter, target, skill_no );
			Get_repair( decision[1], 0, System_save_data.party_no[target], 2 );
			Chara_save_data[target].sp -= Skill_data[skill_no].sp;
			break;
	}
}

//�X�L�����
int Skill_manu( int character ){

	//�ϐ���`
	static int select_ok = 0;
	static int select = 0;
	static int list_ok = 1;
	static int use_member = 0;
	static int list[100];
	static int list_num;
	static int draw_time = GCounter;
	int use_color;

	//���X�g����
	if( list_ok == 0 ){
		//���X�g�̃��Z�b�g
		for( int i = 0; i < 100; i++ ){
			list[i] = 0;
		}
		list_num = 0;

		for( int i = 0; i < 200; i++ ){
			if( Chara_save_data[System_save_data.party_no[use_member]].skill_no[i] > 0 ){
				list[list_num] = i;
				list_num++;
			}
		}
		list_ok = 1;
	}

	//�`�揈��
	if( select_ok == 1 ){
		
		//�������n
		Draw_window( 0, 440, 30, 120 );
		DrawFormatString( 5, 35, Color[0], Skill_data[list[select]].infoplus );
		Message_draw( 5, 55, Skill_data[list[select]].info, 500, GCounter - draw_time );

		//���X�g�ꗗ
		Draw_window( 40, 520, 120, 330 );
		for( int i = 0; i < 20; i++ ){
			if( Skill_data[list[i]].cls == 1 || Battle_flag == 1 && Skill_data[list[i]].cls != 10 ) use_color = 0;
			else use_color = 1;
			DrawFormatString( 55 + (( i % 2 ) * 240 ), 125 + (( i / 2 ) * 20 ), Color[use_color], Skill_data[list[i]].name );
			DrawFormatString( 250 + (( i % 2 ) * 240 ), 125 + (( i / 2 ) * 20 ), Color[use_color], "%d", Skill_data[list[i]].sp );
			
			//���[���ǂ���
			if( i == list_num - 1 ) break;
		}
		Draw_select( 42 + (( select % 2 ) * 240 ), 278 + (( select % 2 ) * 240 ), 123 + (( select / 2 ) * 20 ), 147  + (( select / 2 ) * 20 ) );
	}

	//�����t
	if( select_ok == 0 ){
		//�����Ŏg�p�L���������w��
		if( character == -1 ){
			use_member = B_target_select( 0, -1 );
			if( use_member >= 0 ){
				select_ok++;
				list_ok = 0;
			}else if( use_member == -2 ){
				return -1;
			}
		//�����ŃL�������w���
		}else{
			select_ok++;
			list_ok = 0;
			use_member = character;
		}
	}else if( select_ok == 2 ){
		int target = B_target_select( 0, -1 );
		if( use_member >= 0 ){
			Camp_skill( list[select], use_member, target );
		}else if( use_member == -2 ){
			select_ok--;
		}
	}else{
		if( Keystate[KEY_INPUT_Z] == 1 ){
			if( Skill_data[list[select]].cls == 1 || Battle_flag == 1 && Skill_data[list[select]].cls != 10 ){
				if( Battle_flag == 1 ) return list[select];
				else select_ok++;
			}
		}else if( Keystate[KEY_INPUT_X] == 1 ){
			if( character == -1 ){
				select_ok--;
			}else{
				return -1;
			}
		}else if( Keystate[KEY_INPUT_UP] == 1 && select > 1 ){
				select -= 2;
				draw_time = GCounter;
		}else if( Keystate[KEY_INPUT_DOWN] == 1 && select < list_num - 2 ){
				select += 2;
				draw_time = GCounter;
		}else if( Keystate[KEY_INPUT_LEFT] == 1 && select > 0 ){
				select--;
				draw_time = GCounter;
		}else if( Keystate[KEY_INPUT_RIGHT] == 1 && select < list_num - 1 ){
				select++;
				draw_time = GCounter;
		}
	}

	//���s���Ԓl
	return 0;
}

/*-----
���荞��:�L�����v�A�_���W����(�퓬�O)
���j���[�֌W
-----*/

void Party_manu(){

	//�ϐ���`
	static int status_character = 0;
	static int junc = 0;
	static int character = -1;

	//�萔��`
	char spotmes[][128] = { "",
							"�X�e�[�^�X�̊m�F�����܂��B",
							"�X�e�[�^�X�|�C���g���g���ăX�e�[�^�X���㏸���܂��B",
							"�����A�C�e���̊m�F�A�A�C�e�����g�p���܂��B",
							"�����X�L���̊m�F�A�X�L�����g�p���܂��B",
							"�e�����o�̑�����ύX���܂��B",
							"�e�펑���A���v���m�F�ł��܂��B",
							"�Q�[���ݒ��ύX���܂��B",
							"���̉�ʂɖ߂�܂��B",
							"�L�����X�e�[�^�X��\�����Ă��܂��BZ�L�[�ŕ��܂��B",
							"������ύX���܂��B",
							"�A�C�e���̊m�F������g�p�����肵�܂��B"};


	//C�Ń��j���[�Ăяo�����I��
	if( Keystate[KEY_INPUT_C] == 1 ){
		if( Camp_draw == 0 && Battle_flag == 0 && Event_switch == 0 ){
			Camp_draw = 1;
			Sinfo_status = 1;
		}else if( Camp_draw == 1 && junc == 0 ){
			Camp_draw = 0;
			Sinfo_status = 0;
		}
	}
	
	//�Ăяo���ꂽ�ꍇ�̏���
	if( Camp_draw == 1 ){
		
		//����1�s�E�C���h�E
		Draw_window( 0, 440, 0, 30 );

		//���j���[����
		switch ( junc ){
			case 0:
				//�������\��
				DrawFormatString( 5, 5, Color[0], "%s", spotmes[Selecting] );

				//���j���[�̕\������
				junc = manu_draw_y( 0, 50, 120, 6, "�X�e�[�^�X", "SP����", "����", "�A�C�e��", "�X�L��", "����", "����������", "�I�v�V����" );
				break;

			case 1://�X�e�[�^�X���

				//�������\��
				DrawFormatString( 5, 5, Color[0], "%s", spotmes[8] );

				//���͎�t
				if( Keystate[KEY_INPUT_LEFT] == 1 && status_character > 0 ) status_character--;
				else if( Keystate[KEY_INPUT_RIGHT] == 1 && status_character < 4 && System_save_data.party_no[status_character + 1] != -1 ) status_character++;
				
				//�\��
				if( draw_status( status_character ) == 1 ){
					junc = 0;
				}
				break;

			case 2://�U�������

				//�L�����I��
				if( character == -1 ) character = B_target_select( 0, -1 );
				else{
					//�\��
					if( Set_status_point( character ) == 1 ){
						junc = 0;
						character = -1;
					}
				}
				break;

			case 4://�A�C�e�����
				//�������\��
				DrawFormatString( 5, 5, Color[0], "%s", spotmes[10] );

				if( item_draw() == 1 ) junc = 0;
				break;

			case 5://�X�L�����
				if( Skill_manu( -1 ) == -1 ) junc = 0;
				break;

			case 6://�������

				//�������\��
				DrawFormatString( 5, 5, Color[0], "%s", spotmes[9] );

				//���͎�t
				if( Keystate[KEY_INPUT_LEFT] == 1 && status_character > 0 ) status_character--;
				else if( Keystate[KEY_INPUT_RIGHT] == 1 && status_character < 4 && System_save_data.party_no[status_character + 1 ] != -1 ) status_character++;

				if( draw_equip( status_character ) == 1 ){
					junc = 0;
				}
				break;

			case 7://�������
				junc = 0;
				break;

			case 8://�I�v�V�������
				junc = 0;
				break;
		}
	}
	
}

/*-----
�A�C�e���̍w��
-----*/

//�w���̋L�^
void item_write( int category, int number ){

	switch( category ){
		case 1:
			Item_save_data.use[number]++;
			break;

		case 2:
			for( int i = 0; i < 200; i++ ){
				if( Item_save_data.weapon[i][0] == -1 ){
					Item_save_data.weapon[i][0] = number;
					Item_save_data.weapon[i][1] = 0;
					Item_save_data.weapon[i][2] = Item_weapon_data[number].std_atk[0];
					Item_save_data.weapon[i][3] = Item_weapon_data[number].std_atk[1];
					Item_save_data.weapon[i][4] = Item_weapon_data[number].std_atk[2];
					Item_save_data.weapon[i][5] = -1;
					break;
				}
			}
			break;

		case 3:
			for( int i = 0; i < 200; i++ ){
				if( Item_save_data.armor[i][0] == -1 ){
					Item_save_data.armor[i][0] = number;
					Item_save_data.armor[i][1] = 0;
					Item_save_data.armor[i][2] = Item_armor_data[number].std_def[0];
					Item_save_data.armor[i][3] = Item_armor_data[number].std_def[1];
					Item_save_data.armor[i][4] = -1;
					break;
				}
			}
			break;

	}
	return;
}

//��ʕ\���֌W
int buy_item( int category, int shop_level ){
	
	//�ϐ���`
	static int list_num; //���X�g���������v��
	static int list[100];//���X�g
	static int loaded;
	static int select;
	static int list_start;
	static int num_select;//���I��
	static int piece;
	static int draw_time;
	static int cr;
	//�萔��`
	const char effect_info[][100] ={"�yHp�񕜁z�񕜗�:",
									"�ySp�񕜁z�񕜗�:",
									"�y��ԉ񕜁z",
									"�y�C�╜�A�z�񕜗�:",
									"�yHp�����񕜁z�񕜌���:1/",
									"�ySp�����񕜁z�񕜌���:1/",
									"",
									"",
									"",
									"�y����z����̗p�r�Ŏg�p"};

	const char state_name[][15] =  {"��","���","�È�","����","",
									"","","","","",
									""};

	const char stat_name[][15] = {	"�U����",
									"",
									"�����␳",
									"Crit�␳",
									"���x�␳",
									"���͕␳",
									"�X���b�g",
									"�h���",
									"���␳",
									"�����ϐ�",
									"",
									"",
									"�X���b�g",
	};

	const char Element_name[][15] = {"�y�Α����z",
									 "�y�������z",
									 "�y�n�����z",
									 "�y�������z",
									 "�y�������z",
									 "�y�ő����z",
									 "�y�������z"};	
										
	//�����Ǎ���
	if( loaded == 0 ){

		//���X�g������
		list_num = 0;
		list_start = 0;
		select = 0;
		draw_time = 0;
		for( int i = 0; i < 100; i++ ){
			list[i] = 0;
		}

		//���X�g����
		switch( category ){
			case 1://�A�C�e��
				list_num = 0;
				for( int i = 0; i < 200; i++ ){
					if( Item_use_data[i].shop_lv <= shop_level ){
						list[list_num] = i;
						list_num++;
					}
				}
				list_num--;
				loaded = 1;
				break;
			case 2://����
				list_num = 0;
				for( int i = 0; i < 200; i++ ){
					if( Item_weapon_data[i].weapon_lv <= shop_level && Item_weapon_data[i].weapon_lv > shop_level - 5 && Item_weapon_data[i].unique == 0 ){
						list[list_num] = i;
						list_num++;
					}
				}
				list_num--;
				loaded = 1;
				break;
			case 3://�h��
				list_num = 0;
				for( int i = 0; i < 200; i++ ){
					if( Item_armor_data[i].armor_lv <= shop_level && Item_armor_data[i].armor_lv > shop_level - 5 && Item_armor_data[i].unique == 0 ){
						list[list_num] = i;
						list_num++;
					}
				}
				list_num--;
				loaded = 1;
				break;
		}
	}

	//�`��֌W
	switch( category ){

		case 1://�A�C�e��
			//1�s������

			//������
			if( Item_use_data[list[select]].type == 10 ){
				DrawFormatString( 5, 35, Color[9], "%s", effect_info[Item_use_data[list[select]].type - 1] );
			}else if( Item_use_data[list[select]].type == 3 ){
				DrawFormatString( 5, 35, Color[9], "%s %s", effect_info[Item_use_data[list[select]].type - 1], state_name[Item_use_data[list[select]].effect - 1] );
			}else{
				DrawFormatString( 5, 35, Color[9], "%s %d", effect_info[Item_use_data[list[select]].type - 1], Item_use_data[list[select]].effect );
			}
			Message_draw( 5, 55, Item_use_data[list[select]].info, 520, GCounter - draw_time );

			//���X�g��
			Draw_window( 0, 240, 120, 370 );
			for( int i = 0; i < 12; i++ ){
				if( Item_use_data[list[list_start + i]].take_num == Item_save_data.use[list_start + i] ) cr = 1;
				else cr = 0;
				DrawFormatString( 10, 125 + ( i * 20 ), Color[cr], "%s", Item_use_data[list[list_start + i]].name );
				DrawFormatString( 180, 125 + ( i * 20 ), Color[cr], "%d", Item_use_data[list[list_start + i]].price );
				if( list_start + i == list_num )break;
			}
			Draw_select( 5, 235, 124 + ( (select - list_start) * 20 ), 146 + ( (select - list_start) * 20 ));

			//�w���m�F��
			if( num_select == 1 ){
				Draw_window( 220, 420, 200, 270 );
				DrawString( 220, 205, "�����w�����܂����H", Color[0] );
				DrawFormatString( 220, 235, Color[0], "%d��", piece );
				DrawFormatString( 270, 235, Color[0], "%d�e�B��", piece * Item_use_data[list[select]].price );	
			}
			break;

		case 2://����
			//1�s������
			if( Item_weapon_data[list[select]].info_color == 0 ){
			}else{
			}
			//������
			DrawFormatString( 5, 35, Color[0], "�U��%d-%d", Item_weapon_data[list[select]].std_atk[0], Item_weapon_data[list[select]].std_atk[1] );
			DrawFormatString( 115, 35, Color[0], "%s", Element_name[Item_weapon_data[list[select]].element] ); 
			DrawFormatString( 205, 35, Color[9 - Item_weapon_data[list[select]].info_color], "%s", Item_weapon_data[list[select]].infoplus );
			Message_draw( 5, 55, Item_weapon_data[list[select]].info, 520, GCounter - draw_time );
			//���X�g��
			Draw_window( 0, 240, 120, 370 );
			SetDrawArea( 0, 120, 240, 370 );
			for( int i = 0; i < 12; i++ ){
				DrawFormatString( 10, 125 + ( i * 20 ), Color[0], "%s", Item_weapon_data[list[list_start + i]].name );
				DrawFormatString( 180, 125 + ( i * 20 ), Color[0], "%d", Item_weapon_data[list[list_start + i]].price );
				if( list_start + i == list_num )break;
			}
			Draw_select( 5, 235, 124 + ( (select - list_start) * 20 ), 146 + ( (select - list_start) * 20 ));
			SetDrawArea( 0, 0, 640, 480 );
			//���\�\����
			Draw_window( 240, 440, 120, 280 );
			for( int j = 0; j < 7; j++ ){
				DrawFormatStringToHandle( 245, 125 + ( j * 20 ), Color[9], Font[0], "%s", stat_name[j] );
			}
			DrawFormatStringToHandle( 245, 145, Color[0], Font[0], "%d�`%d:%d��", Item_weapon_data[list[select]].std_atk[0], Item_weapon_data[list[select]].std_atk[1], Item_weapon_data[list[select]].std_atk[2] );
			DrawFormatStringToHandle( 320, 165, Color[0], Font[0], "%d", Item_weapon_data[list[select]].hit );
			DrawFormatStringToHandle( 320, 185, Color[0], Font[0], "%d", Item_weapon_data[list[select]].critical );
			DrawFormatStringToHandle( 320, 205, Color[0], Font[0], "%d", Item_weapon_data[list[select]].spd );
			DrawFormatStringToHandle( 320, 225, Color[0], Font[0], "%d", Item_weapon_data[list[select]].magic );
			DrawFormatStringToHandle( 320, 245, Color[0], Font[0], "%d", Item_weapon_data[list[select]].slot );

			//�w���m�F��
			if( num_select == 1 ){
				Draw_window( 220, 420, 200, 270 );
				DrawString( 220, 205, "�����w�����܂����H", Color[0] );
				DrawFormatString( 220, 235, Color[0], "%d��", piece );
				DrawFormatString( 270, 235, Color[0], "%d�e�B��", piece * Item_weapon_data[list[select]].price );	
			}
			break;

		case 3://�h��
			//1�s������
			if( Item_armor_data[list[select]].info_color == 0 ){
			}else{
			}
			//������
			DrawFormatString( 5, 35, Color[0], "�h��%d�^%d", Item_armor_data[list[select]].std_def[0], Item_armor_data[list[select]].std_def[1] ); 
			DrawFormatString( 135, 35, Color[9 - Item_armor_data[list[select]].info_color], "%s", Item_armor_data[list[select]].infoplus );
			Message_draw( 5, 55, Item_armor_data[list[select]].info, 520, GCounter - draw_time );
			//���X�g��
			Draw_window( 0, 240, 120, 370 );
			SetDrawArea( 0, 120, 240, 370 );
			for( int i = 0; i < 12; i++ ){
				DrawFormatString( 10, 125 + ( i * 20 ), Color[0], "%s", Item_armor_data[list_start + i].name );
				DrawFormatString( 180, 125 + ( i * 20 ), Color[0], "%d", Item_armor_data[list_start + i].price );
				if( list_start + i == list_num )break;
			}
			Draw_select( 5, 235, 124 + ( (select - list_start) * 20 ), 146 + ( (select - list_start) * 20 ));
			SetDrawArea( 0, 0, 640, 480 );
			//���\�\����
			Draw_window( 240, 440, 120, 280 );
			for( int j = 0; j < 6; j++ ){
				DrawFormatStringToHandle( 245, 125 + ( j * 20 ), Color[9], Font[0], "%s", stat_name[j + 7] );
			}
			DrawFormatStringToHandle( 320, 125, Color[0], Font[0], "%d�^%d", Item_armor_data[list[select]].std_def[0], Item_armor_data[list[select]].std_def[1] );
			DrawFormatStringToHandle( 320, 145, Color[0], Font[0], "%d", Item_armor_data[list[select]].avd );
			DrawFormatStringToHandle( 320, 165, Color[0], Font[0], "��%d/��%d/�n%d", Item_armor_data[list[select]].elm_def[0], Item_armor_data[list[select]].elm_def[1], Item_armor_data[list[select]].elm_def[2] );
			DrawFormatStringToHandle( 320, 185, Color[0], Font[0], "��%d/��%d/��%d", Item_armor_data[list[select]].elm_def[3], Item_armor_data[list[select]].elm_def[4], Item_armor_data[list[select]].elm_def[5] );
			DrawFormatStringToHandle( 320, 205, Color[0], Font[0], "��%d", Item_armor_data[list[select]].elm_def[6] );
			DrawFormatStringToHandle( 320, 225, Color[0], Font[0], "%d", Item_armor_data[list[select]].slot );

			//�w���m�F��
			if( num_select == 1 ){
				Draw_window( 220, 420, 200, 270 );
				DrawString( 220, 205, "�����w�����܂����H", Color[0] );
				DrawFormatString( 220, 235, Color[0], "%d��", piece );
				DrawFormatString( 270, 235, Color[0], "%d�e�B��", piece * Item_armor_data[list[select]].price );	
			}
			break;

	}

	//�����t
	if( Keystate[KEY_INPUT_X] == 1 ){
		if( num_select == 0 ){
			//�������I��
			loaded = 0;
			return 1;
		}else{
			num_select--;
			piece = 1;
		}
	}else if( Keystate[KEY_INPUT_Z] == 1 ){
		if( num_select == 0 ){
			num_select++;
		}else{
			//�w�����L�^
			for( int i = 0; i < piece; i++ ){
				item_write( category, list[select] );
			}
			num_select = 0;
			piece = 0;
		}
	}else if( Keystate[KEY_INPUT_UP] == 1 && select > 0 ){
		select--;
		if( list_start > select ) list_start = select;
		draw_time = GCounter;
	}else if( Keystate[KEY_INPUT_DOWN] == 1 && select < list_num ){
		select++;
		if( list_start + 11 < select ){
			list_start = select - 11;
			//select = 10;
		}
		draw_time = GCounter;
	}else if( Keystate[KEY_INPUT_LEFT] == 1 && num_select == 1 ){
		if( piece > 0 ) piece--;
	}else if( Keystate[KEY_INPUT_RIGHT] == 1 && num_select == 1 ){
		if( piece < 9 && category != 1 ) piece++;
		else if( category == 1 && piece < Item_use_data[list[select + list_start]].take_num - Item_save_data.use[list[select + list_start]] ) piece++;
	}

	//���s���A�l
	return 0;
}

//�_���W�����Z���N�g
int Dungeon_select(){

	//�ϐ���`
	static int loaded = 0;
	static int list_num = 0;
	static int draw_time = GCounter;
	static int select = 0;
	static int list[10];

	//���X�g����
	if( loaded == 0 ){
		list_num = 0;
		for( int i = 0; i < 10; i++ ){
			list[i] = -1;
		}
		for( int i = 0; i < 10; i++ ){
			if( Dungeon_data[i].Enter_camp == 0 ){
				list[list_num] = i;
				list_num++;
			}
		}
		list_num--;
		loaded = 1;	
	}

	//���X�g�\��
	Draw_window( 20, 200, 120, 240 );
	for( int i = 0; i < 6; i++ ){
		DrawFormatString( 30, 130 + ( i * 20 ), Color[0], Dungeon_data[list[i]].name );
	}
	Draw_select( 22, 198,128, 152 );

	//�����\���Ƃ�
	Message_draw( 5, 35, Dungeon_data[select].info, 440, GCounter - draw_time );

	//�����t
	if( Keystate[KEY_INPUT_Z] == 1 ){
		loaded = 0;
		return select;
	}else if( Keystate[KEY_INPUT_X] == 1 ){
		return -2;
	}else if( Keystate[KEY_INPUT_UP] == 1 ){
		if( select > 0 ){
			select--;
		}
	}else if( Keystate[KEY_INPUT_DOWN] == 1 ){
		if( select < list_num - 1 ){
			select++;
		}
	}

	//���s���Ԓl
	return -1;

}

//���ݒ�
int Setconfig(){

	//�ϐ���`
	static int select;
	static int fanc[6];
	static int init_ok = 0;

	//��������
	if( init_ok == 0 ){
		for( int i = 0; i < 6; i++ ){
			//fanc[i] = config[i];
		}
	}

	//���s���A�l
	return 0;
}

//�����o�[�ύX
int Member_change(){

	//�ϐ���`
	static int change[3] = { 0, 0, 0 };
	static int select = 0;
	static int pos = 0;
	static int list[5] = { -1, -1, -1, -1, -1 };
	static int list_num;
	static int list_ok = 0;
	static int list_hantei = 0;
	
	//�萔��`
	const char category_name[][20] = {"���O","Lv","HP","SP"};
	const int  category_position[][4] = {{ 210, 310, 360, 400 },{ 170, 310, 340, 390 }};

	//����
	
	//���X�g����
	if( list_ok == 0 ){
		//10�l��
		list_num = 0;
		for( int i = 0; i < 10; i++ ){
			if( System_save_data.menber_ok[i] == 1 ){
				for( int j = 0; j < 5; j++ ){
					if( System_save_data.party_no[j] == i ){
						list_hantei = 1;
						break;
					}else{
						list_hantei = 0;
					}
				}
				if( list_hantei == 0 ){
					list[list_num] = i;
					list_num++;
				}
			}
		}
		list_ok = 1;
	}

	//�`��
	Draw_window( 160, 450, 140, 340 );
	for( int j = 0; j < 4; j++ ){
		DrawFormatString( category_position[0][j], 150, Color[8], category_name[j] );
	}
	for( int i = 0; i < list_num; i++ ){
		for( int j = 0; j < 4; j++ ){
			switch( j ){
				case 0: //name
					DrawFormatString( category_position[1][j], 170 + ( 20 * i ), Color[0], Charaname[list[i]] );
					break;

				case 1: //lv
					DrawFormatString( category_position[1][j], 170 + ( 20 * i ), Color[0], "%d" ,Chara_save_data[list[i]].level );
					break;

				case 2: //hp
					DrawFormatString( category_position[1][j], 170 + ( 20 * i ), Color[0], "%d" ,Chara_save_data[list[i]].hp );
					break;

				case 3: //sp
					DrawFormatString( category_position[1][j], 170 + ( 20 * i ), Color[0], "%d" ,Chara_save_data[list[i]].sp );
			}
		}
	}
	//�Z���N�g�g
	Draw_select( 162, 448, 168 + ( 20 * pos ), 192 + ( 20 * pos ) );
	//���p�[�e�B�[�����o�[�\��
	if( select > 0 ){
		Sinfo_status = 1;
	}else{
		Sinfo_status = 0;
	}


	//�����t
	if( select == 2 ){
		change[2] = yes_no_message( "�w�肵�����Ԃ����ւ��܂��B", "��㎞�Z�[�u����܂��B" );
		switch( change[2] ){
			case 1:
				System_save_data.party_no[change[1]] = change[0];
				Chara_status_calculate( change[1] );
				Data_save();
				list_ok = 0;
				select = 0;
				break;
			case 2:
				select = 0;
				break;
		}
	}else if( select == 1 ){
		change[1] = B_target_select( 0, -1 );
		switch( change[1] ){
			case -1:
				break;

			case -2:
				select--;
				break;

			default:
				select++;
		}
	}else{
		if( Keystate[KEY_INPUT_Z] == 1 ){
			change[0] = list[pos];
			select++;
		}else if( Keystate[KEY_INPUT_X] == 1 ){
			list_ok = 0;
			return -1;
		}else if( Keystate[KEY_INPUT_UP] == 1 && pos > 0 ){
			pos--;
		}else if( Keystate[KEY_INPUT_DOWN] == 1 && pos < list_num - 1){
			pos++;
		}
	}

	//���s���Ԓl
	return 0;
}