//�퓬�֌W

#include <Dxlib.h>
#include <malloc.h>
#include "System_draw.h"
#include "Initalize.h"
#include "Datasave.h"
#include "Mathoperation.h"
#include "Effect_draw.h"
#include "Dungeon_draw.h"

//��������ƃ_���[�W�v�Z
//�g�p�ҁA�W�I�A�X�L���ԍ�
void Hit_damage_calc( int *space, int acter, int target, int skill ){

	//�ϐ���`
	int side[2] = { 1, 1 };

	int attack;
	int hit[2];
	int defence;

	if( acter < 5 ) side[0] = 0;
	if( target < 5 ) side[1] = 0;

	//�l�̗p��
	if( side[0] == 0 ){
		if( Skill_data[skill].cls == 0 ){
			attack = ( Chara_save_data[System_save_data.party_no[acter]].fix_status[11] / 100.0 ) * float( Chara_save_data[System_save_data.party_no[acter]].fix_status[9] + GetRand( Chara_save_data[System_save_data.party_no[acter]].fix_status[10] - Chara_save_data[System_save_data.party_no[acter]].fix_status[9] ) ) + Battle_pt[acter].st_effect[0];
			hit[0] = Chara_save_data[System_save_data.party_no[acter]].fix_status[13] + Battle_pt[acter].st_effect[4];
		}else if( Skill_data[skill].cls == 2 ){
			attack = ( Chara_save_data[System_save_data.party_no[acter]].fix_status[16] + Battle_pt[acter].st_effect[1] ) * ( Skill_data[skill].power[1] / 100.0 ) + GetRand( Skill_data[skill].power[1] );
			hit[0] = 100;
		}
	}else{
		if( Skill_data[skill].cls == 0 ){
			attack = Battle_mob[acter % 5].status[0][0] + Battle_mob[acter % 5].status[0][1];
			hit[0] = Battle_mob[acter % 5].status[4][0] + Battle_mob[acter % 5].status[4][1];
		}else if( Skill_data[skill].cls == 2 ){
			attack = ( Battle_mob[acter % 5].status[1][0] + Battle_mob[acter % 5].status[1][0] ) * ( Skill_data[skill].power[1] / 100.0 ) + GetRand( Skill_data[skill].power[1] );
			hit[0] = 100;
		}
	}

	if( side[1] == 0 ){
		if( Skill_data[skill].cls == 0 ){
			defence = Chara_save_data[System_save_data.party_no[target]].fix_status[12] + Battle_pt[target].st_effect[2];
			hit[1]  = Chara_save_data[System_save_data.party_no[target]].fix_status[14] + Battle_pt[target].st_effect[5];
		}else if( Skill_data[skill].cls == 2 ){
			defence = Chara_save_data[System_save_data.party_no[target]].fix_status[17] + Battle_pt[target].st_effect[3];
			hit[1]  = 0;
		}
	}else{
		if( Skill_data[skill].cls == 0 ){
			defence	= Battle_mob[target % 5].status[1][0] + Battle_mob[target % 5].status[1][1];
			hit[1]  = Battle_mob[target % 5].status[5][0] + Battle_mob[target % 5].status[5][1];
		}else if( Skill_data[skill].cls == 2 ){
			defence = Battle_mob[target % 5].status[3][0] + Battle_mob[target % 5].status[3][1];
			hit[1]  = 0;
		}
	}

	//����
	//��������
	if( hit[0] - hit[1] > GetRand( 100 ) ) space[0] = 1;
	else space[0] = 0;

	if( space[0] == 1 ){
		//�_���[�W�̔���
		space[1] = (( 95 + GetRand( 10 ) ) / 100.0 ) * float( attack - defence );
		if( space[1] < 1 ) space[1] = 1;
		if( side[0] == 0 ){
			space[2] = Chara_save_data[System_save_data.party_no[acter]].fix_status[20];
		}else{
			space[2] = 2;
		}
		//�N���e�B�J������ƃ_���[�W�C��
		if( GetRand( 100 ) < space[2] && Skill_data[skill].cls == 0 ){
			space[1] *= 2.5;
			space[2] = 1;
		}else{
			space[2] = 0;
		}
	}

}

//�񕜔���ƌv�Z
//�l�i�[����int�z��̃A�h���X�A�g�p�ҁA�W�I�A�X�L���ԍ�
void Hit_recover_calc( int *space, int acter, int target, int skill ){

	//�ϐ���`
	int side[2] = { 1, 1 };

	int attack;
	int rate;

	if( acter < 5 ) side[0] = 0;
	if( target < 5 ) side[1] = 0;

	//�l�̗p��
	if( side[0] == 0 ){
		attack = ( Chara_save_data[System_save_data.party_no[acter]].fix_status[16] + Battle_pt[acter].st_effect[1] ) * ( Skill_data[skill].power[1] / 100.0 ) + GetRand( Skill_data[skill].power[1] );
	}else{
		attack = ( Battle_mob[acter % 5].status[1][0] + Battle_mob[acter % 5].status[1][0] ) * ( Skill_data[skill].power[1] / 100.0 ) + GetRand( Skill_data[skill].power[1] );
	}

	if( side[1] == 0 ){
		rate = Chara_save_data[System_save_data.party_no[target]].fix_status[19];
	}else{
		rate = Battle_mob[target % 5].status[8][0] + Battle_mob[target % 5].status[8][1];
	}

	//����ƒl�̌���
	space[0] = 1;

	space[1] = attack * ( rate / 100.0 );

	space[2] = 0;
}

//�s�����s���[�`��
//���s����L�����N�^�A�R�}���h�ԍ�
void Battle_routine( int player ){

	//�ϐ���`
	int chara;
	int side;
	int ko;
	int command;
	int commandtype;
	int target;
	int decision[3]; //HIT�A�_���[�W�A�N���e�B�J������
	char message[200] = "";
	char vol[10];
	char name[10][50];

	//�T�C�h�̔���
	if( player < 5 ){
		chara = player;
		command = Battle_pt[chara].action[0];
		target = Battle_pt[chara].action[1];
	}else{
		chara = player - 5;
		command = Battle_mob[chara].action[0];
		target = Battle_mob[chara].action[1];
	}

	//�R�}���h��ʓo�^
	commandtype = Skill_data[command].cls;
	if( command == -1 ) commandtype = -1;

RETRY:
	//������^�[�Q�b�g�����Ȃ��ꍇ
	if( target < 5 && Battle_pt[target].effect_state[999][0] == 1 ){
		target = GetRand( 4 );
		goto RETRY;
	}else if( target > 4 && Battle_mob[target % 5].effect_state[999][0] == 1 ){
		//if( Battle_mob[target % 5].number == -1 
		target = GetRand( 4 ) + 5;
		goto RETRY;
	}


	//���O�̐���
	for( int i = 0; i < 10; i++ ){
		if( i < 5 ){
			strcpy( name[i], Charaname[System_save_data.party_no[i]] );
		}else{
			strcpy( name[i], Monster_data[Battle_mob[i - 5].number].name );
		}
	}
	if( player < 5 ){
		side = 0;
	}else{
		side = 1;
	}

	switch( commandtype ){
		case -1://�h��
			strcat( message, name[player] );
			strcat( message, "�͖h��̐���������I" );
			switch( side ){
				case 0:
					Battle_pt[chara].effect_state[103][0] = 1;
					Battle_pt[chara].effect_state[103][1] = Battle_pt[chara].time[1][1];
					break;
				case 1:
					Battle_mob[chara].effect_state[103][0] = 1;
					Battle_mob[chara].effect_state[103][1] = Battle_mob[chara].time[1][1];
					break;
			}
			Add_event_message( 1, 20, 0, message );
			break;
		case 0://�ʏ�U��
			strcat( message, name[player] );
			strcat( message, Skill_data[command].message );
			Add_event_message( 1, 40, 0, message );
			Hit_damage_calc( decision, player, target, command );

			if( decision[2] == 1 ) Add_event_message( 0, 0, 0, "�N���e�B�J���I" );
			strcpy( message, name[target] );

			if( decision[0] == 1 ){
				if( target < 5 ){
					ko = 0;
					strcat( message, "�� " );
					itoa( decision[1], vol, 10 );
					strcat( message, vol );
					strcat( message, "�̃_���[�W���󂯂��I" );
				}else{
					ko = 1;
					strcat( message, "�� " );
					itoa( decision[1], vol, 10 );
					strcat( message, vol );
					strcat( message, "�̃_���[�W��^�����I" );
				}
				Add_event_damage( 0, 0, 0, target, decision[1] ); 
				Add_event_message( 1, 0, 0, message ); 
				Knock_out( ko, target % 5, decision[1] );
			}else{
				strcat( message, "�͍U�������킵���I" );
				Add_event_message( 1, 0, 0, message );
			}
			break;

		case 1://�񕜖��@�֌W
			strcpy( message, name[player] );
			strcat( message, " ��" );
			strcat( message, Skill_data[command].name );
			strcat( message, "���������I" );		
			break;

		case 2://�U�����@�֌W
			strcpy( message, name[player] );
			strcat( message, " ��" );
			strcat( message, Skill_data[command].name );
			strcat( message, "���������I" );
			Add_event_message( 1, 40, 0, message );
			Hit_damage_calc( decision, player, target, command );
			strcpy( message, name[target] );
			if( decision[0] == 1 ){
				if( target < 5 ){
					ko = 0;
					strcat( message, "�̗̑͂� " );
					itoa( decision[1], vol, 10 );
					strcat( message, vol );
					strcat( message, " �|�C���g���X�ɉ񕜁I" );
				}else{
					ko = 1;
					strcat( message, "�̗̑͂� " );
					itoa( decision[1], vol, 10 );
					strcat( message, vol );
					strcat( message, " �|�C���g���X�ɉ񕜁I" );
				}
				Add_event_repair( 0, 0, 0, target, 3, decision[1] ); 
				Add_event_message( 1, 0, 0, message ); 
				Knock_out( ko, target % 5, decision[1] );
			}else{
				strcat( message, "�͖��@�𖳌��������I" );
				Add_event_message( 1, 0, 0, message );				
			}
			break;

	}
	
	//�㏈��
	if( side == 0 ){
		Battle_pt[chara].task = 1;
	}else{
		Battle_mob[chara].task = 1;
	}
}

//�h��R�}���h

//�퓬���A�C�e���g�p
int B_item(){

	//�ϐ���`
	static int list_ok = 0;
	static int list_num = 0;
	static int select = 0;
	static int use_member = 0;
	static int list[100];
	static int draw_time = GCounter;
	static int category;


	//�萔��`
	const char effect_info[][100] ={"�yHp�񕜁z�񕜗�:",
									"�ySp�񕜁z�񕜗�:",
									"�y��ԉ񕜁z",
									"�y�C�╜�A�z�񕜗�:",
									"�yHp�����񕜁z�񕜌���:1/",
									"�ySp�����񕜁z�񕜌���:1/",
									"",
									"",
									"",
									"�y����z����̗p�r�Ŏg�p"};

	const char state_name[][15] =  {"��","���","�È�","�ݑ�","",
									"","","","","",
									""};

	//���X�g����
	if( list_ok == 0 ){
		for( int i = 0; i < 100; i++ ){
			if( Item_save_data.use[i] > 0 ){
				list[list_num] = i;
				list_num++;
			}
		}
		//�����Ă��Ȃ��ꍇ
		if( list_num == 0 ) return -1;

		list_ok = 1;
	}
	//���X�g�\��
	Draw_window( 100, 540, 120, 370 );
	for( int i = 0; i < 24; i++ ){
		if(category == 0 ){
			DrawFormatString( 105 + ( ( i % 2 ) * 215 ), 125 + ( ( i / 2 ) * 20 ), Color[1 - Item_use_data[list[i]].out_use_ok], "%s", Item_use_data[list[i]].name );
			DrawFormatString( 300 + ( ( i % 2 ) * 215 ), 125 + ( ( i / 2 ) * 20 ), Color[1 - Item_use_data[list[i]].out_use_ok], "%d", Item_save_data.use[list[i]] );
		}else{
			DrawFormatString( 105 + ( ( i % 2 ) * 215 ), 125 + ( ( i / 2 ) * 20 ), Color[1], "%s", Item_matel_data[list[i]].name );
			DrawFormatString( 300 + ( ( i % 2 ) * 215 ), 125 + ( ( i / 2 ) * 20 ), Color[1], "%d", Item_save_data.matel[list[i]] );
		}
		if( i ==list_num - 1 ) break;
	}
	//�I��g
	Draw_select( 101, 319, 123, 147 );


	//�����t
	if( Keystate[KEY_INPUT_Z] == 1 ){
		if( Item_use_data[list[select]].out_use_ok == 1 ) return 2;
	}else if( Keystate[KEY_INPUT_X] == 1 ){
			Battle_use_item = select;
			select = 0;
			list_ok = 0;
			return 1;
	}else if( Keystate[KEY_INPUT_UP] == 1 ){
		if( select > 1 ){
			select -= 2;
			draw_time = GCounter;
		}
	}else if( Keystate[KEY_INPUT_DOWN] == 1 ){
		if( select < list_num - 2 ){
			select += 2;
			draw_time = GCounter;
		}
	}else if( Keystate[KEY_INPUT_LEFT] == 1 ){
		if( select > 0 ){
			select--;
			draw_time = GCounter;
		}
	}else if( Keystate[KEY_INPUT_RIGHT] == 1 ){
		if( select < list_num ){
			select++;
			draw_time = GCounter;
		}
	}

	//�I�������O
	return 0;
}

//�ΏۑI��
//����:�o�^����L�����N�^�[�A�����w�c(-1�̏ꍇ�͑I���������̂�)
int B_target_select( int character, int fanc ){
	
	//�ϐ���`
	static int initfanc = fanc;
	if( initfanc == -1 ) initfanc = 0;
	static int target[2] = { 0, initfanc };
	int mortion = ( 1 + ( GCounter % 60 ) ) / 3;
	char message[100] = "";

	//�`�揈��
	//�E�C���h�E,�Z���N�g�J�[�\��
	Draw_window( 0, 500, 0, 30 );
	if( target[1] == 0 ){
		strcpy( message, Charaname[System_save_data.party_no[target[0]]] );
		DrawRotaGraph( 63 + ( 125 * target[0] ), 400 + mortion, 1, 0, S_Corsor, TRUE );
	}else{
		strcpy( message, Monster_data[Battle_mob[target[0]].number].name );
		DrawRotaGraph( Battle_mob[target[0]].pos[0], Battle_mob[target[0]].pos[1] + mortion, 1, 0, S_Corsor, TRUE );
		
		//�Ȉ�HP�Q�[�W
		SetDrawArea( Battle_mob[target[0]].pos[0] - 50, Battle_mob[target[0]].pos[1] + 50, Battle_mob[target[0]].pos[0] - 50 + ( 100 * ( Battle_mob[target[0]].hp[0] / float( Battle_mob[target[0]].hp[1] ))), Battle_mob[target[0]].pos[1] + 60 );
		DrawModiGraph( Battle_mob[target[0]].pos[0] - 50, Battle_mob[target[0]].pos[1] + 50, Battle_mob[target[0]].pos[0] + 50, Battle_mob[target[0]].pos[1] + 50,Battle_mob[target[0]].pos[0] + 50, Battle_mob[target[0]].pos[1] + 60, Battle_mob[target[0]].pos[0] - 50, Battle_mob[target[0]].pos[1] + 60, MiniGuage[0], TRUE );
		SetDrawArea( 0, 0, 640, 480 );
		DrawBox( Battle_mob[target[0]].pos[0] - 50, Battle_mob[target[0]].pos[1] + 50, Battle_mob[target[0]].pos[0] + 50, Battle_mob[target[0]].pos[1] + 60, Color[5], FALSE );

		//�^�C���Q�[�W
		DrawBox( Battle_mob[target[0]].pos[0] - 50, Battle_mob[target[0]].pos[1] + 60, Battle_mob[target[0]].pos[0] - 50 + ( ( Battle_mob[target[0]].time[1][0] / float( Battle_mob[target[0]].time[1][1] ) ) * 100 ), Battle_mob[target[0]].pos[1] + 70, Color[6], TRUE );
		if( Battle_mob[target[0]].task == 0 ){
			DrawBox( Battle_mob[target[0]].pos[0] - 50 + ( 100 - (( Battle_mob[target[0]].time[0][0] / float( Battle_mob[target[0]].time[0][1] )) * 100)), Battle_mob[target[0]].pos[1] + 60, Battle_mob[target[0]].pos[0] + 50, Battle_mob[target[0]].pos[1] + 70, Color[5], TRUE );
		}
		DrawBox( Battle_mob[target[0]].pos[0] - 50, Battle_mob[target[0]].pos[1] + 60, Battle_mob[target[0]].pos[0] + 50, Battle_mob[target[0]].pos[1] + 70, Color[5], FALSE );
	}
	DrawFormatString( 100, 5, Color[0], "%s", message );

	//�����t
	if( Keystate[KEY_INPUT_LEFT] == 1 ){
		target[0]--;
		if( target[0] == -1 ){
			target[0] = 4;
		}
		while( 1 ){
			if( target[1] == 0 ){
				if( System_save_data.party_no[target[0]] == -1 || Battle_pt[target[0]].effect_state[999][0] == 1 ){
					target[0]--;
					if( target[0] < 0 ) target[0] = 4;
				}else break;
			}else if( target[1] == 1 ){
				if(  Battle_mob[target[0]].number == -1 || Battle_mob[target[0]].effect_state[999][0] == 1 ){
					target[0]--;
					if( target[0] < 0 ) target[0] = 4;
				}else break;
			}
		}
	}else if( Keystate[KEY_INPUT_RIGHT] == 1 ){
		target[0]++;
		if( target[1] == 0 ){
			if( target[0] > 4 || System_save_data.party_no[target[0]] == -1 ) target[0] = 0;
		}else{
			while( 1 ){
				if( target[0] > 4 ){
					target[0] = 0;
				}
				if( Battle_mob[target[0]].number <= -1 || Battle_mob[target[0]].effect_state[999][0] == 1 ){
					if( Battle_mob[target[0]].number != -1 && Battle_mob[target[0]].effect_state[999][0] == 0 ) break;
					target[0]++;
				}else break;
			}
		}
	}else if( Keystate[KEY_INPUT_UP] == 1 && fanc != -1 ){
		if( target[1] == 0 ){
			target[1] = 1;
			target[0] = 0;
			while( 1 ){
				if( Battle_mob[target[0]].number != -1 ) break;
				else target[0]++;
			}
		}
	}else if( Keystate[KEY_INPUT_DOWN] == 1 && fanc != -1 ){
		if( target[1] == 1 ){
			target[1] = 0;
			target[0] = 0;
		}
	}else if( Keystate[KEY_INPUT_Z] == 1 ){
		initfanc = -1;
		return target[0] + ( target[1] * 5 );
	}else if( Keystate[KEY_INPUT_X] == 1 ){
		return -2;
	}

	//���s��
	return -1;
}

//�퓬�R�}���h�̑I��
int B_command( int Character ){

	//�ϐ���`
	static int main_select[3] = { 0, 0, 0 };
	char message[100] = "";

	//���C���I��\��
	if( Character < 5 ){
		switch( main_select[0] ){
			case 0: //�I��
				main_select[0] = manu_draw_y( 20 + ( 120 * Character ), 230, 120, 5, "�ʏ�U��", "�X�L��", "�A�C�e��", "�h��", "������" );
				break;

			case 1://�ʏ�U���ΏۑI��
				main_select[1] = B_target_select( Character, 1 ); 
				if( main_select[1] > -1 ){
					Battle_pt[Character].task = 0;
					Battle_pt[Character].time[0][0] = Chara_save_data[System_save_data.party_no[Character]].fix_status[15] / 2;
					Battle_pt[Character].time[0][1] = Chara_save_data[System_save_data.party_no[Character]].fix_status[15] / 2;
					Battle_pt[Character].time[1][0] = Chara_save_data[System_save_data.party_no[Character]].fix_status[15] / 2;
					Battle_pt[Character].time[1][1] = Chara_save_data[System_save_data.party_no[Character]].fix_status[15] / 2;
					Battle_pt[Character].action[0] = 0;
					Battle_pt[Character].action[1] = main_select[1];
					for( int i = 0; i < 3; i++ ){ 
						main_select[i] = 0;
					}
					return 1;
				}else if( main_select[1] == -2 ){
					for( int i = 0; i < 3; i++ ){ 
						main_select[i] = 0;
					}
				}
				break;

			case 2://�X�L���I��
				main_select[1] = Skill_manu( Character );
				if( main_select[1] == -1 ) main_select[0] = 0;
				else if( main_select[1] > 0 ){
					if( Skill_data[main_select[1]].cls == 1 ){
						main_select[2] = B_target_select( Character, 0 );
					}else{
						main_select[2] = B_target_select( Character, 1 );
					}

					//���͊m��f�[�^�̊i�[
					if( main_select[2] > -1 ){
						Battle_pt[Character].task = 0;
						Battle_pt[Character].time[0][0] = Skill_data[main_select[1]].speed[0] + (( Chara_save_data[System_save_data.party_no[Character]].fix_status[15] ) * (( 100 + Skill_data[main_select[1]].speed[2] ) / 100.0 )) * ( Skill_data[main_select[1]].act_time / 100.0 );
						Battle_pt[Character].time[0][1] = Skill_data[main_select[1]].speed[0] + (( Chara_save_data[System_save_data.party_no[Character]].fix_status[15] ) * (( 100 + Skill_data[main_select[1]].speed[2] ) / 100.0 )) * ( Skill_data[main_select[1]].act_time / 100.0 );
						Battle_pt[Character].time[1][0] = (Skill_data[main_select[1]].speed[0] + (( Chara_save_data[System_save_data.party_no[Character]].fix_status[15] ) * (( 100 + Skill_data[main_select[1]].speed[2] ) / 100.0 ))) - Battle_pt[Character].time[0][1];
						Battle_pt[Character].time[1][1] = (Skill_data[main_select[1]].speed[0] + (( Chara_save_data[System_save_data.party_no[Character]].fix_status[15] ) * (( 100 + Skill_data[main_select[1]].speed[2] ) / 100.0 ))) - Battle_pt[Character].time[0][1];
						Battle_pt[Character].action[0] = main_select[1];
						Battle_pt[Character].action[1] = main_select[2];
						for( int i = 0; i < 3; i++ ){ 
							main_select[i] = 0;
						}
						return 1;
					}else if( main_select[2] == -2 ){
						main_select[1] = 0;
					}
				}
				break;

			case 3://�A�C�e���I��
				if( main_select[1] == 0 ){
					switch( B_item() ){
						case -1://�������Ă��Ȃ�
							Add_event_message( 0, 0, 0, "�p�[�e�B�̓A�C�e�����������Ă��Ȃ��I" );
							main_select[0] = 0;
							break;
	
						case 0://�I��
							main_select[1] = 0;
							break;

						case 1://�L�����Z��
							main_select[0] = 0;
							break;

						case 2://�g�p����
							main_select[1] = 1;

						default:
							break;
					}
				}else if( main_select[1] == 1 ){
					main_select[2] = B_target_select( Character, 1 ); 
					if( main_select[2] != -1 ){
						Battle_pt[Character].task = 1;
						Battle_pt[Character].time[1][0] = Chara_save_data[System_save_data.party_no[Character]].fix_status[15];
						Battle_pt[Character].time[1][1] = Chara_save_data[System_save_data.party_no[Character]].fix_status[15];
						item_use( Battle_use_item, main_select[2], Character, 2 );
						for( int i = 0; i < 3; i++ ){ 
							main_select[i] = 0;
						}
						return 1;
					}
				}
				break;

			case 4://�h��
				Battle_pt[Character].task = 0;
				Battle_pt[Character].time[0][0] = 1;
				Battle_pt[Character].time[0][1] = 1;
				Battle_pt[Character].time[1][0] = Chara_save_data[System_save_data.party_no[Character]].fix_status[15];
				Battle_pt[Character].time[1][1] = Chara_save_data[System_save_data.party_no[Character]].fix_status[15];
				Battle_pt[Character].action[0] = -1;
				for( int i = 0; i < 3; i++ ){ 
					main_select[i] = 0;
				}
				return 1;
				break;

			case 5://������
				Add_event_message( 1, 0, 0, "�p�[�e�B�͓��������݂��I" );
				if( GetRand( 100 ) % 4 == 0 ){
					Add_event_message( 1, 0, 0, "���܂������؂ꂽ�I" );
				//�I������
				}else{
					Add_event_message( 1, 0, 0, "�����������Ɏ��s�����c�I" );
					Battle_pt[Character].task = 1;
					Battle_pt[Character].time[1][0] = Chara_save_data[System_save_data.party_no[Character]].fix_status[15];
					Battle_pt[Character].time[1][1] = Chara_save_data[System_save_data.party_no[Character]].fix_status[15];
					return 1;
				}
				break;
		}

	}



	//���s���Ԓl
	return 0;
}

//�퓬�s���̎��s


//�퓬�J�n����
void B_initalize( int paturn ){
	
	//�ϐ���`
	int mob_num;
	int mob_all = 1 + GetRand( 4 );
	char message[100];

	//�o�^�O�̏�����
	for( int i = 0; i < 5; i++ ){
		Battle_mob[i].number = -1;
		Getitem[i] = -1;
	}

	Add_event_effect( 0, 20, 0, 2, 0, 0 );
	//�G,�����o�^
	for( int i = 0; i < mob_all; i++ ){
		while( 1 ){
			mob_num = Dungeon_data[D_Number].Monster[GetRand( 5 )];
			if( mob_num != -1 ) break;
		}
		Battle_mob[i].number = mob_num;		
		Battle_mob[i].hp[1] = Monster_data[Battle_mob[i].number].hp;
		Battle_mob[i].hp[0] = Battle_mob[i].hp[1];
		Battle_mob[i].sp	= Monster_data[Battle_mob[i].number].sp;
		Battle_mob[i].task	= 1;
		for( int j = 0; j < 9; j++ ){
			for( int k = 0; k < 2; k++ ){
				if( k == 0 ){
					Battle_mob[i].status[j][k] = Monster_data[Battle_mob[i].number].status[j];
				}else{
					Battle_mob[i].status[j][k] = 0;
				}
			}
		}
		Battle_mob[i].grf = mob_num;
		Battle_mob[i].action[0] = 0;
		Battle_mob[i].pos[0] = 60 + ( 580 / mob_all ) * i;
		Battle_mob[i].pos[1] = 240;
		for( int j = 0; j < 1000; j++ ){
			Battle_mob[i].effect_state[j][0] = 0;
			Battle_mob[i].effect_state[j][1] = 0;
		}	
		
		//���b�Z�[�W�֌W
		strcpy( message, Monster_data[Battle_mob[i].number].name );
		strcat( message, " �����ꂽ�I" );
		Add_event_message( 0, 15, 0, message );

	}

	Getpoint[0] = 0;
	Getpoint[1] = 0;
	for( int i = 0; i < 5; i++ ){
		if( System_save_data.party_no[i] != -1 ){
			Battle_pt[i].task = 1;
			for( int j = 0; j < 15; j++ ){
				Battle_pt[i].st_effect[j] = 0;
			}
			Battle_pt[i].repair = 0;
		}
	}

	//����ׁB5�l����O��B
	//�ǉ����o�^
	for( int i = 0; i < 5; i++ ){
		switch( paturn ){
			case -1: //�A�h�o���e�[�W�퓬
				if( System_save_data.party_no[i] != -1 ){
					Battle_pt[i].time[1][0] = 10;
					Battle_pt[i].time[1][1] = 10;
					Battle_pt[i].task = 1;
				}
				if( i < mob_all ){
					Battle_mob[i].time[1][0] = Battle_mob[i].status[6][0];
					Battle_mob[i].time[1][1] = Battle_mob[i].status[6][0];
				}
				break;

			case 0: //�ʏ�퓬
				if( System_save_data.party_no[i] != -1 ){
					Battle_pt[i].time[1][0] = 10;
					Battle_pt[i].time[1][1] = 10;
					Battle_pt[i].task = 1;
				}
				if( i < mob_all ){
					Battle_mob[i].time[1][0] = 10;
					Battle_mob[i].time[1][1] = 10;
				}
				break;

			case 1: //�s���퓬�̏ꍇ
				if( System_save_data.party_no[i] != -1 ){
					Battle_pt[i].time[1][0] = Chara_save_data[System_save_data.party_no[i]].fix_status[15];
					Battle_pt[i].time[1][1] = Chara_save_data[System_save_data.party_no[i]].fix_status[15];
					Battle_pt[i].task = 1;
				}
				if( i < mob_all ){
					Battle_mob[i].time[1][0] = 10;
					Battle_mob[i].time[1][1] = 10;
				}
				break;
		}
	}

	//�t���O����
	Battle_flag = 1;
	Battle_end = 0;
	Sinfo_status = 1;
}

//�퓬�I��
void Battle_end_event(){

	//�ϐ���`
	char message[200] = "";
	char change[10] = "";

	//����
	Add_event_message( 1, 0, 0, "�p�[�e�B�͐퓬�ɏ��������I" );
	itoa( Getpoint[0], change, 10 );
	strcpy( message, change );
	strcat( message, "�|�C���g�̌o���l�𓾂��I" );
	Add_event_message( 1, 0, 0, message );
	itoa( Getpoint[1], change, 10 );
	strcpy( message, change );
	strcat( message, "�e�B������I" );
	Add_event_message( 1, 0, 0, message );
	//�A�C�e������
	for( int i = 0; i < 5; i++ ){
		if( Getitem[i] != -1 ){
			Item_save_data.matel[Getitem[i]]++;
			strcpy( message, Item_matel_data[Getitem[i]].name );
			strcat( message, " ��1����I" );
			Add_event_message( 0, 0, 0, message );
		}
	}

	//�퓬�t���O�͂���
	Battle_flag = 0;

	//�G���J�E���g�����Z�b�g
	D_Encount = GetRand( 7 );

}

//�S��
void Game_over(){

	//�ϐ���`
	int  droping;
	char message[200] = "";
	char change[10] = "";
	int  category = 0;
	int  item_num = 0;

	//����
	Add_event_message( 1, 0, 0, "�S�ł����c�B" );
	droping = System_save_data.money * ( (40 + GetRand( 60 )) / 100.0 );
	itoa( droping, change, 10 );
	strcpy( message, change );
	strcat( message, "�e�B���̂������������c�B" );
	//�f�ރA�C�e���������_���ɑ�ʂɗ��Ƃ�����
RETRY:
	while( 1 ){
		item_num = GetRand( ITEM_MATEL_NUM );
		if( Item_save_data.matel[item_num] != 0 ){
			droping = GetRand( Item_save_data.matel[item_num] );
			break;
		}
	}
	strcpy( message, Item_matel_data[Item_save_data.matel[item_num]].name );
	strcat( message, " ��" );
	itoa( droping, change, 10 );
	strcat( message, change );
	strcat( message, "�����Ă��܂����c�B");
	Add_event_message( 1, 0, 0, message );
	if( GetRand( 100 ) < 70 ) goto RETRY;

	//�����I�ɏ����X�֔�΂���鏈��
	D_dead_escape();
}

//�퓬���C��
void B_main(){

	//�ϐ���`
	int movetime = 30;	//�i�s���x�l
	int action_num = -1;//�s�����s���L�����N�^�[
	int action_pt = -1; //�s�����s���w�c
	int repair = 0;		//���@�񕜒l
	static int mob_alpha[5] = { 0, 0, 0, 0, 0 };
	static int select_num;

	//�퓬�J�n�O�̃X�L������

	//�퓬��
	if( Battle_select == 1 ){
		//�s���I��
		if( B_command( select_num ) == 1 ){
			Battle_select = 0;
		}
	}else if( Event_switch == 1 ){
		//�s�����C�x���g�Ƃ��ď�����
		New_Event();
	}else{
		for( int i = 0; i < 10; i++ ){
			//�i�s���x�ݒ�l�ȉ��̑ҋ@�܂��͔������Ԃ̃L�����N�^�[�����邩
			if( i < 5 ){
				if( Battle_pt[i].time[Battle_pt[i].task][0] < movetime && System_save_data.party_no[i] != -1 && Battle_pt[i].effect_state[999][0] == 0){
					action_num = i;
					action_pt = 0;
					movetime = Battle_pt[i].time[Battle_pt[i].task][0];
				}
			}else{
				if( Battle_mob[i - 5].time[Battle_mob[i - 5].task][0] < movetime && Battle_mob[i - 5].number != -1 && Battle_mob[i - 5].effect_state[999][0] == 0 ){
					action_num = i;
					action_pt = 1;
					movetime = Battle_mob[i - 5].time[Battle_mob[i - 5].task][0];
				}
			}
		}

		//���Ԍo��
		for( int i = 0; i < 5; i++ ){
			Battle_pt[i].time[Battle_pt[i].task][0] -= movetime;
			//���@�񕜌��ʂ̔��f
			if( Battle_pt[i].repair > 0 ){
				repair = movetime / 2;
				if( Battle_pt[i].repair < repair ) repair = Battle_pt[i].repair;
				Chara_save_data[System_save_data.party_no[i]].hp += repair;
				if ( Chara_save_data[System_save_data.party_no[i]].hp > Chara_save_data[System_save_data.party_no[i]].fix_status[0] ) Chara_save_data[System_save_data.party_no[i]].hp = Chara_save_data[System_save_data.party_no[i]].fix_status[0];
				Battle_pt[i].repair -= repair;
			}
			if( Battle_mob[i].number != -1 ){
				Battle_mob[i].time[Battle_mob[i].task][0] -= movetime;
			}
		}

		//�s�����s���L�����N�^�[������ꍇ
		if( action_num != -1 ){
			switch( action_pt ){
				case 0: //����
					//����or�ҋ@�I��
					if( Battle_pt[action_num].task == 0 ){
						Battle_routine( action_num );
					}else{
						//�s����I��
						select_num = action_num;
						Battle_select = 1;
					}
					break;	
	
				case 1: //�G
					//����or�ҋ@�I��
					if( Battle_mob[action_num - 5].task == 0 ){
						Battle_routine( action_num );	
	
					}else{
						//�s����I��
						Battle_mob[action_num - 5].action[0] = 0;
RETRY:
						Battle_mob[action_num - 5].action[1] = GetRand( 4 );
						if( System_save_data.party_no[Battle_mob[action_num - 5].action[1]] == -1 ) goto RETRY;
						Battle_mob[action_num - 5].time[0][0] = Battle_mob[action_num - 5].status[6][0] / 2;
						Battle_mob[action_num - 5].time[0][1] = Battle_mob[action_num - 5].status[6][0] / 2;
						Battle_mob[action_num - 5].time[1][0] = Battle_mob[action_num - 5].status[6][0] / 2;
						Battle_mob[action_num - 5].time[1][1] = Battle_mob[action_num - 5].status[6][0] / 2;
						Battle_mob[action_num - 5].task = 0;
						//100�̗�������ēK���Ƀ����_���I���B
					}
					break;
			}
		}
	}

	//��Ԉُ��Ԃ̍X�V
	for( int i = 0; i < 5; i++ ){
		for( int j = 0; j < 999; j++ ){
			if( System_save_data.party_no[i] != 0 && Battle_pt[i].effect_state[j][0] == 1 ){
				Battle_pt[i].effect_state[j][1] -= movetime;
				if( Battle_pt[i].effect_state[j][1] <= 0 ) Battle_pt[i].effect_state[j][0] = 0;
				//Add_event_message( 0, 20, 0, 
			}
			if( Battle_mob[i].number != -1 && Battle_mob[i].effect_state[j][0] == 1 ){
				Battle_mob[i].effect_state[j][1] -= movetime;
				if( Battle_mob[i].effect_state[j][1] <= 0 ) Battle_mob[i].effect_state[j][0] = 0;
			}
		}
	}


	//�����X�^�[�̕`��
	for( int i = 0; i < 5; i++ ){
		if( Battle_mob[i].hp[0] <= 0 && mob_alpha[i] > 0 ){
			mob_alpha[i] -= 8;
			if( mob_alpha[i] < 0 ) mob_alpha[i] = 0;
		}else if( Battle_mob[i].hp > 0 && mob_alpha[i] < 255 ){
			mob_alpha[i] += 8;
			if( mob_alpha[i] > 255 ) mob_alpha[i] = 255;
		}
	}


	//�퓬�I��
	if( Battle_end == 1 ){
		Battle_end_event();
	}else if( Battle_end == 2 ){
	//�S�ł���
		Game_over();
	}
}