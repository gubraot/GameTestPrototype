

//Dataload.cpp
void Typedata_load();
void Typeinfo_load();
void Elementdata_load();
void Elementinfo_load();
void data_load();
void Weapon_data_load();
void Armor_data_load();
void Juel_data_load();
void Skill_data_load();
void Spilit_data_load();
void Item_use_load();
void Dungeon_data_load();
void Matel_data_load();
void Mob_load();
void C_juel_load();
void C_weapon_load();
void C_armor_load();
