/*----------
�v�Z�֐��֌W���C�u����
----------*/

int		natural_num( int number );
float	rand( float rand );
float	absrand( float rand );
void Chara_status_calculate( int member_num );
void Chara_status_calculate_int( int menber_num, int *buf, int *equip );
void Chara_skill_calculate( int member_num );