//�_���W�����p�[�g�֌W�֐��w�b�_

void D_escape();
void D_dead_escape();
void Get_damage( int vol, int target, int targetnum, int type );
void Get_repair( int vol, int target, int targetnum, int type );
void mes_send( char *sendmes );
void Add_event_message( int waitkey, int waittimer, int intersept, char *sendmes );
void Add_event_damage( int waitkey, int waittimer, int intersept, int target, int vol );
void Add_event_repair( int waitkey, int waittimer, int intersept, int target, int type, int vol );
void Add_event_effect( int waitkey, int waittimer, int intersept, int eff_no, int x, int y );
void Knock_out( int target, int targetnum, int damage );
void New_Event();