/*--------------------------------------------/
/5�ʗp�{�X                                    /
/�g�p�ԍ���50-5x                              /
/                                             /
/--------------------------------------------*/

#include "dxlib.h"
#include "Extern.h"
#include "mathoperation.h"
#include <math.h>

//�e��o�^����ׂ̃v���g�^�C�v�錾
void addebullet( float x, float y, int pow, int ptn, float rad, float spd, int img, int size, int id );
void addebullet2( float x, float y, int pow, int ptn, float rad, float spd, int img, float width, float length, int id );
void add_b_enemy( float x, float y, int hp, int ptn, int spd, float rad, int size, int img );

void bossbulletcalc50(){
	static int shotcnt;
	if( boss.cnt <= 1 ){
		shotcnt = 0;
	}

	if( boss.cnt % ( 4 - info.dificality ) == 0 ){
		if( shotcnt % 120 < 60 ){
			addebullet2( boss.x, boss.y, 10, 23, rand( 1.0 ), 5, 42 + GetRand( 7 ), 1, 2, 400 );
		}else{
			addebullet2( boss.x, boss.y, 10, 7, 1 - rand( 0.15 ), 2.4, 66 + GetRand( 9 ), 1, 1.5, 400 );
		}
		shotcnt++;
	}
}

void bossbulletcalc51(){
	static float shotrad[3];
	if(boss.cnt <= 1 ){
		for( int i = 0; i < 3; i++ ){
			shotrad[i] = rand( 1.0 );
		}
	}

	if( boss.cnt % 12 - ( info.dificality * 2 ) == 0 ){
		for( int i = 0; i < 3; i++ ){
			for( int j = 0; j < 6; j++ ){
				if( i == 0 ){
					addebullet( boss.x, boss.y, 10, 1, shotrad[0] + j / 3.0, 3 * ( 1 + info.dificality * 0.1 ), 37, 2, 400);
					addebullet( boss.x, boss.y, 10, 1, shotrad[0] + j / 3.0, 3 * ( 1 + info.dificality * 0.1 ) + 0.4, 37, 2, 400);
					addebullet( boss.x, boss.y, 10, 1, shotrad[0] + j / 3.0, 3 * ( 1 + info.dificality * 0.1 ) + 0.8, 37, 2, 400);
				}else if( i == 1 ){
					addebullet( boss.x, boss.y, 10, 1, shotrad[1] + j / 3.0, 2.4 * ( 1 + info.dificality * 0.1 ), 50, 4, 400);
					addebullet( boss.x, boss.y, 10, 1, shotrad[1] + j / 3.0, 2.4 * ( 1 + info.dificality * 0.1 ) + 0.4, 50, 4, 400);
					addebullet( boss.x, boss.y, 10, 1, shotrad[1] + j / 3.0, 2.4 * ( 1 + info.dificality * 0.1 ) + 0.8, 50, 4, 400);
				}else if( i == 2 ){
					addebullet( boss.x, boss.y, 10, 1, shotrad[2] + j / 3.0, 1.9 * ( 1 + info.dificality * 0.1 ), 1, 5, 400);
					addebullet( boss.x, boss.y, 10, 1, shotrad[2] + j / 3.0, 1.9 * ( 1 + info.dificality * 0.1 ) + 0.4, 1, 5, 400);
					addebullet( boss.x, boss.y, 10, 1, shotrad[2] + j / 3.0, 1.9 * ( 1 + info.dificality * 0.1 ) + 0.8, 1, 5, 400);
				}
			}
			
		}
		shotrad[0] += 1 / 33.0;
		shotrad[1] += 1 / 42.0;
		shotrad[2] += 1 / 51.0;
	}
}

void bossbulletcalc52(){
	static int shotposx, shotposy, color;
	if( boss.cnt <= 1 ){
		shotposx = boss.x;
		shotposy = boss.y;
		color = 0;
	}

	if( boss.cnt % 10 == 0 && GetRand( 10 ) < 3 + info.dificality ){
		shotposx = 20 + GetRand( 400 );
		shotposy = 20 + GetRand( 150 );
		color = GetRand( 9 );

		for( int i = 0; i < 80; i++ ){
			addebullet( shotposx, shotposy, 10, 1, i / 40.0, 1.6, 66 + color, 1, 400 );
		}
	}
}

void bossbulletcalc53(){
	static float shotrad1, shotrad2, space;
	static int waitcnt1, waitcnt2, waitcnt3, shotnum;
	if( boss.cnt <= 1 ){
		shotrad1 = 0;
		shotrad2 = 0;
		waitcnt1 = 0;
		waitcnt2 = 0;
		waitcnt3 = 180;
		shotnum = 0;
		space = 0.04 - info.dificality * 0.008;
	}

	if( boss.cnt % 6 == 3 && waitcnt1 == 0 ){
		addebullet2( 20, 20, 10, 1, shotrad1, 2 * ( 0.8 + info.dificality * 0.2 ), 107, 1, 13, 400 );
		shotrad1 += 0.02 * ( 1.2 - info.dificality * 0.2 );
		if( shotrad1 > 0.5 ){
			waitcnt1 = 300 - info.dificality * 30;
			shotrad1 = 0;
		}
	}else if( boss.cnt % 6 == 0 && waitcnt2 == 0 ){
		addebullet2( 420, 20, 10, 1, shotrad2, 2 * ( 0.8 + info.dificality * 0.2 ), 107, 1, 13, 400 );
		shotrad2 -= 0.02 * ( 1.2 - info.dificality * 0.2 );
		if( shotrad2 < -0.5 ){
			waitcnt2 = 300 - info.dificality * 30;
			shotrad2 = 0;
		}
	}

	if( boss.cnt % (15 - info.dificality * 2 ) == 0 && waitcnt3 == 0 ){
		shotnum++;
		for( int i = 0; i < shotnum; i++ ){
			addebullet( boss.x, boss.y, 10, 1, - space * ( shotnum / 2.0 ) + space * i, 1 + info.dificality * 0.2, 50, 4, 400 );
		}

		if( shotnum == ( 5 + info.dificality * 3 ) ){
			shotnum = 0;
			waitcnt3 = 300;
		}
	}

	if( waitcnt1 > 0 ){
		waitcnt1--;
	}
	if( waitcnt2 > 0 ){
		waitcnt2--;
	}
	if( waitcnt3 > 0 ){
		waitcnt3--;
	}
}

void bossbulletcalc54(){
	if( boss.cnt % 15 == 0 ){
		addebullet( MAX_X, MAX_Y, 20, 1001, -0.5, 3, 41, 2, 400 );
		addebullet( 10, 10, 20, 1002, 0.5, 3, 41, 2, 400 );
	}
	if( boss.cnt % 27 == 0 ){
		addebullet( MAX_X, MAX_Y, 20, 1003, 1, 3, 41, 2, 400 );
		addebullet( 10, 10, 20, 1003, 0, 3, 41, 2, 400 );
	}
}

void bossbulletcalc55(){
	if( boss.cnt % 1000 < 500 ){
		if(boss.cnt % 12 == 0 && boss.cnt < 300){
			addebullet( boss.x, boss.y, 20, 1005, -0.4 +(float)((boss.cnt % 500) / 12.0 * 0.032), 2, 50, 2, 400 );
		}
	}else{
		if(boss.cnt % 12 == 0 && boss.cnt < 800){
			add_b_enemy( boss.x, boss.y, 1, 0, 2, 0.4 -(float)((boss.cnt % 500) / 12.0 * 0.032), 7, 51 );
		}
	}
}

void bossbulletcalc56(){
	static int randx, randy;

	if( info.dificality < 3 ){
		if( boss.cnt % ( 3 - info.dificality ) == 0 ){
			randx = GetRand( BULLET_MAX_X );
			randy = GetRand( BULLET_MAX_Y );
			
			if( distance( randx, randy ) > 600 ){
				addebullet( randx, randy, 10, 36, dis_rad( randx, randy ), 0, 94, 2, 400 );
			}
		}
	}else{
		for( int i = 0; i < 2; i++ ){
			randx = GetRand( BULLET_MAX_X );
			randy = GetRand( BULLET_MAX_Y );
			
			if( distance( randx, randy ) > 600 ){
				addebullet( randx, randy, 10, 36, dis_rad( randx, randy ), 0, 94 + i, 2, 400 );
			}
		}
	}
}
