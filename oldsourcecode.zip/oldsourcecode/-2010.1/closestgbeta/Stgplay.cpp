/*--------------------------------------------/
/�Q�[�����{��                                 /
/                                             /
/                                             /
/--------------------------------------------*/

#include "Extern.h"
#include "dxlib.h"
#include "Debug.h"
#include "imagedraw.h"

//�K�v�Ȋ֐��̃v���g�^�C�v�錾
void ebullet_mein();
void PlayerShot();
void EnemyCharacter();
void player_main();
void drawbackboard();
void boss_main();
void hitmodule();
void item_main();
void game_over();
void pause();
void control_speed();
void b_enemy_main();
void stage_effectcheck( int stagenum );
void stage_end();
void p_hominglazer();
void recovery_motion();

void stagework(){
	static int bossflg = 0;
}

//�{��
void stg_main(){
	if(player.g_over_flag == 1 ){
		recovery_motion();
	}else if( player.g_over_flag == 2 ){
		game_over();
	}else if(player.pause == 1 ){
		pause();
	}else{
		stage_effectcheck( info.stage );
		backdraw();
		manage_measure( 0, 1 );
		PlayerShot();
		p_hominglazer();
		player_main();
		manage_measure( 1, 1 );
		if(boss.flg == 1){
			b_enemy_main();
		}
		EnemyCharacter();
		ebullet_mein();
		boss_main();
		hitmodule();
		item_main();
		effect_main();
		manage_measure( 0, 2 );
		drawbackboard();
		manage_measure( 1, 2 );
		if(debug.swich == 1) debugmain( 1 );
		if(player.g_over_flag >= 1 || player.pause == 1){
			img_screen = MakeGraph( 640 , 480 ) ;
			GetDrawScreenGraph( 0 , 0 , 640 , 480 , img_screen ) ;
		}
		if(player.clearflg == 1){
			stage_end();
		}

		control_speed();
		//�����ɓ˂�����
	}
}