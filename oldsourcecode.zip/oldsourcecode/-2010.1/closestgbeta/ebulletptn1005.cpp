/*--------------------------------------------/
/�G�e��1005                                   /
/                                             /
/                                             /
/--------------------------------------------*/

#include "dxlib.h"
#include "Extern.h"
#include "mathoperation.h"

void addebullet2( float x, float y, int pow, int ptn, float rad, float spd, int img, float width, float length, int id );

void ebulletptn1005( int i, int type ){
	switch(type){
		case 0:
			ebullet[i].x	+= rad_x( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
			ebullet[i].y	+= rad_y( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
			if( ebullet[i].x <= BULLET_MIN_XY || ebullet[i].x >= BULLET_MAX_X || ebullet[i].y <= BULLET_MIN_XY || ebullet[i].y >= BULLET_MAX_Y ){
				float baserad = dis_rad( ebullet[i].x, ebullet[i].y ); 
				for(int j = 0; j < 32; j++ ){
					addebullet2( ebullet[i].x, ebullet[i].y, 10, 1, baserad +float(j/16.0), 1.2, 31, 1, 3, 400 );
				}
				ebullet[i].flg = 0;
			}
			break;

		case 1:
			erecbullet[i].x	+= rad_x( erecbullet[i].rad, erecbullet[i].spd * spd.objspeed );
			erecbullet[i].y	+= rad_y( erecbullet[i].rad, erecbullet[i].spd * spd.objspeed );
			if( erecbullet[i].x <= BULLET_MIN_XY || erecbullet[i].x >= BULLET_MAX_X || erecbullet[i].y <= BULLET_MIN_XY || erecbullet[i].y >= BULLET_MAX_Y ){
				float baserad = dis_rad( erecbullet[i].x, erecbullet[i].y ); 
				for(int j = 0; j < 32; j++ ){
					addebullet2( erecbullet[i].x, erecbullet[i].y, 10, 1, baserad +float(j/16.0), 1.2, 31, 1, 3, 400 );
				}
				erecbullet[i].flg = 0;
			}
			break;
	}
}