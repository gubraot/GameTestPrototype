/*--------------------------------------------/
/�e�L�X�g����f�[�^�̓ǂݍ���                 /
/		�@�@�@                                /
/                                             /
/--------------------------------------------*/

void loadstagedata( int filepass );
//void loadbosscalc( int filepass, int stagenum );
void loadstageinfo( int filepass, int bossnum );
void loadstageconf( int filepass, int stagenum );
void loadtotalrecord();
void loadstagerecord();
void loadconfig();
