/*--------------------------------------------/
/�G�e��1001                                   /
/                                             /
/                                             /
/--------------------------------------------*/

#include "dxlib.h"
#include "Extern.h"
#include "mathoperation.h"

void addebullet2( float x, float y, int pow, int ptn, float rad, float spd, int img, float width, float length, int id );

void ebulletptn1001( int i ){
	if( ebullet[i].flg == 1 ){
		float shotrad = free_rad( ebullet[i].x, ebullet[i].y, player.x -20.0, player.y ); 
		ebullet[i].x	+= rad_x( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
		if(ebullet[i].time  % 6 == 0){
			addebullet2( ebullet[i].x, ebullet[i].y, 8, 1, shotrad, 3, 33, 0.8, 4.0, 400 );
		}
	}
}

void ebulletptn1002( int i ){
	if( ebullet[i].flg == 1 ){
		float shotrad = free_rad( ebullet[i].x, ebullet[i].y, player.x +20.0, player.y ); 
		ebullet[i].x	+= rad_x( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
		if(ebullet[i].time  % 6 == 0){
			addebullet2( ebullet[i].x, ebullet[i].y, 8, 1, shotrad, 3.5, 33, 0.8, 4.0, 400 );
		}
	}
}


void ebulletptn1003( int i ){
	if( ebullet[i].flg == 1 ){
		ebullet[i].x	+= rad_x( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
		ebullet[i].y	+= rad_y( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
		if(ebullet[i].time  % 45 == 0){
			for(int j = 0; j < 2; j++ ){
				addebullet2( ebullet[i].x, ebullet[i].y, 8, 1, (float)(ebullet[i].rad + 0.5 + rand(0.3)), 1.3, 32, 0.8, 4.0, 400 );
			}
		}
	}
}
