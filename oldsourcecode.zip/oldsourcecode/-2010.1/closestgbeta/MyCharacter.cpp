/*--------------------------------------------/
/���@�̒�`                                   /
/���@�̓����A�e�Ȃǂ̂܂Ƃ�                   /
/                                             /
/--------------------------------------------*/

#include "dxlib.h"
#include "Extern.h"
#include "score.h"
#include "imagedraw.h"
#include "mathoperation.h"

//�V���b�g�p�^�[���֐��̃v���g�^�C�v�錾
void mybullet01( int num, int lv );
void mybullet02( int num, int lv );
void mybullet03( int num, int lv );
void mybullet04( int num, int lv );
void mybullet05( int num, int lv );

void p_lazer( int x, int starty, int pow, int img, int size );
void add_hominglazer( int atk );

//�����`��v���g�^�C�v�錾
void GnumDraw( int Num, int type, int x, int y, int keta );

//���@�V���b�g�̓o�^
void addpshot( int lv, float x, float y, float pow, int ptn, float angle, int img ){ //����ǉ��������:�摜�̔ԍ�
	for( int i = 0; i < P_SHOT_MAX1; i++ ){
		if( pbullet[i][lv].flg == 0 ){
			pbullet[i][lv].flg	= 1;
			pbullet[i][lv].x	= x;
			pbullet[i][lv].y	= y;
			pbullet[i][lv].size = 8;
			pbullet[i][lv].atk  = pow;
			pbullet[i][lv].ptn	= ptn;
			pbullet[i][lv].angle= angle;
			pbullet[i][lv].spd	= 0;
			pbullet[i][lv].gen	= 0;
			pbullet[i][lv].time = 0;
			pbullet[i][lv].graph= img;
			break;	
		}
	}
}

//���@�V���b�g����
void pshot1(){
	switch( player.shot_lv ){
		case 1:
			if( player.chara_type == 1 ){
				if( player.shotcount %3 == 1 ){
					addpshot( 0, player.x+4, player.y+20, 1, 2, 1, 200 );
					addpshot( 0, player.x-4, player.y+20, 1, 3, 1, 200 );
					if( CheckSoundMem( effectsound[1] ) == 1 ){
						StopSoundMem( effectsound[1] );
					}
					PlaySoundMem( effectsound[1], DX_PLAYTYPE_BACK ) ;
				}	
			}else{
				if( player.shotcount %3 == 1 ){
					addpshot( 0, player.x+4, player.y, 1, 1, 1, 203 );
					addpshot( 0, player.x-4, player.y, 1, 1, 1, 203 );
					if( CheckSoundMem( effectsound[1] ) == 1 ){
						StopSoundMem( effectsound[1] );
					}
					PlaySoundMem( effectsound[1], DX_PLAYTYPE_BACK ) ;
				}
				if( player.magicflg == 1 && player.shotcount %4 == 0){
					addpshot( 7, player.x+4, player.y+20, 1, 4, 1, 211 );
					addpshot( 7, player.x-4, player.y+20, 1, 5, 1, 211 );
				}
			}
			break;

		case 2:
			if( player.chara_type == 1 ){
				if( player.shotcount %3 == 1 ){
					addpshot( 0, player.x+8, player.y+20, 1, 2, 0.98, 200 );
					addpshot( 0, player.x-8, player.y+20, 1, 3, 1.02, 200 );
					addpshot( 1, player.x, player.y+20, 1, 1, 1, 200 );
					if( CheckSoundMem( effectsound[1] ) == 1 ){
						StopSoundMem( effectsound[1] );
					}
					PlaySoundMem( effectsound[1], DX_PLAYTYPE_BACK ) ;
				}	
			}else{
				if( player.shotcount %3 == 1 ){
					addpshot( 0, player.x+6, player.y, 1, 1, 0.94, 203 );
					addpshot( 0, player.x-6, player.y, 1, 1, 1.06, 203 );
					addpshot( 1, player.x, player.y, 1, 1, 1, 203 );
					if( CheckSoundMem( effectsound[1] ) == 1 ){
						StopSoundMem( effectsound[1] );
					}
					PlaySoundMem( effectsound[1], DX_PLAYTYPE_BACK ) ;
				}
				if( player.magicflg == 1 && player.shotcount %4 == 0){
					addpshot( 7, player.x+4, player.y+20, 1, 4, 1, 211 );
					addpshot( 7, player.x-4, player.y+20, 1, 5, 1, 211 );
				}
			}
			break;

		case 3:
			if( player.chara_type == 1 ){
				if( player.shotcount %3 == 1 ){
					addpshot( 0, player.x+6, player.y+20, 1, 2, 1.01, 200 );
					addpshot( 1, player.x+12, player.y+20, 1, 2, 0.99, 200 );
					addpshot( 0, player.x-6, player.y+20, 1, 3, 0.99, 200 );
					addpshot( 1, player.x-12, player.y+20, 1, 3, 1.01, 200 );
					if( CheckSoundMem( effectsound[1] ) == 1 ){
						StopSoundMem( effectsound[1] );
					}
					PlaySoundMem( effectsound[1], DX_PLAYTYPE_BACK ) ;
				}	
			}else{
				if( player.shotcount %4 == 1 ){
					addpshot( 0, player.x+4, player.y, 1.5, 1, 0.98, 204 );
					addpshot( 0, player.x-4, player.y, 1.5, 1, 1.02, 204 );
					addpshot( 1, player.x, player.y, 1.5, 1, 0.92, 204 );
					addpshot( 1, player.x, player.y, 1.5, 1, 1.08, 204 );
					if( CheckSoundMem( effectsound[1] ) == 1 ){
						StopSoundMem( effectsound[1] );
					}
					PlaySoundMem( effectsound[1], DX_PLAYTYPE_BACK ) ;
				}
				if( player.magicflg == 1 && player.shotcount %4 == 0){
					addpshot( 7, player.x+4, player.y+20, 1.8, 4, 1, 212 );
					addpshot( 7, player.x-4, player.y+20, 1.8, 5, 1, 212 );
				}
			}
			break;

		case 4:
			if( player.chara_type == 1 ){
				if( player.shotcount %3 == 1 ){
					addpshot( 0, player.x+6, player.y+20, 1.4, 2, 1.01, 201 );
					addpshot( 1, player.x+12, player.y+20, 1.4, 2, 0.99, 201 );
					addpshot( 0, player.x-6, player.y+20, 1.4, 3, 0.99, 201 );
					addpshot( 1, player.x-12, player.y+20, 1.4, 3, 1.01, 201 );
					if( CheckSoundMem( effectsound[1] ) == 1 ){
						StopSoundMem( effectsound[1] );
					}
					PlaySoundMem( effectsound[1], DX_PLAYTYPE_BACK ) ;
				}	
			}else{
				if( player.shotcount %4 == 1 ){
					addpshot( 0, player.x+4, player.y, 1.4, 1, 0.99, 204 );
					addpshot( 0, player.x-4, player.y, 1.4, 1, 1.01, 204 );
					addpshot( 1, player.x+7, player.y, 1.4, 1, 0.94, 204 );
					addpshot( 1, player.x-7, player.y, 1.4, 1, 1.06, 204 );
					addpshot( 2, player.x+10, player.y, 1.4, 1, 0.89, 204 );
					addpshot( 2, player.x-10, player.y, 1.4, 1, 1.11, 204 );
					if( CheckSoundMem( effectsound[1] ) == 1 ){
						StopSoundMem( effectsound[1] );
					}
					PlaySoundMem( effectsound[1], DX_PLAYTYPE_BACK ) ;
				}
				if( player.magicflg == 1 && player.shotcount %3 == 0){
					addpshot( 7, player.x+4, player.y+20, 1.8, 4, 1, 212 );
					addpshot( 7, player.x-4, player.y+20, 1.8, 5, 1, 212 );
				}
			}
			break;

		case 5:
			if( player.chara_type == 1 ){
				if( player.shotcount %3 == 1 ){
					addpshot( 0, player.x+6, player.y+20, 1.5, 2, 1.02, 201 );
					addpshot( 1, player.x+12, player.y+20, 1.5, 2, 0.985, 201 );
					addpshot( 2, player.x, player.y+20, 1.5, 1, 1, 201 );
					addpshot( 0, player.x-6, player.y+20, 1.5, 3, 0.98, 201 );
					addpshot( 1, player.x-12, player.y+20, 1.5, 3, 1.015, 201 );
					if( CheckSoundMem( effectsound[1] ) == 1 ){
						StopSoundMem( effectsound[1] );
					}
					PlaySoundMem( effectsound[1], DX_PLAYTYPE_BACK ) ;
				}	
			}else{
				if( player.shotcount %4 == 1 ){
					addpshot( 0, player.x+4, player.y, 1.4, 1, 0.99, 204 );
					addpshot( 0, player.x-4, player.y, 1.4, 1, 1.01, 204 );
					addpshot( 1, player.x+7, player.y, 1.4, 1, 0.94, 204 );
					addpshot( 1, player.x-7, player.y, 1.4, 1, 1.06, 204 );
					addpshot( 2, player.x+10, player.y, 1.4, 1, 0.89, 204 );
					addpshot( 2, player.x-10, player.y, 1.4, 1, 1.11, 204 );
					addpshot( 3, player.x+13, player.y, 1.4, 1, 0.85, 204 );
					addpshot( 3, player.x-13, player.y, 1.4, 1, 1.15, 204 );
					if( CheckSoundMem( effectsound[1] ) == 1 ){
						StopSoundMem( effectsound[1] );
					}
					PlaySoundMem( effectsound[1], DX_PLAYTYPE_BACK ) ;
				}
				if( player.magicflg == 1 && player.shotcount %4 == 0){
					addpshot( 7, player.x+4, player.y+20, 3, 4, 1, 213 );
					addpshot( 7, player.x-4, player.y+20, 3, 5, 1, 213 );
				}
			}
			break;

		case 6:
			if( player.chara_type == 1 ){
				if( player.shotcount %3 == 1 ){
					addpshot( 0, player.x+6, player.y+20, 2, 2, 1.02, 202 );
					addpshot( 1, player.x+12, player.y+20, 2, 2, 0.985, 202 );
					addpshot( 2, player.x, player.y+20, 2, 1, 1, 202 );
					addpshot( 0, player.x-6, player.y+20, 2, 3, 0.98, 202 );
					addpshot( 1, player.x-12, player.y+20, 2, 3, 1.015, 202 );
					if( CheckSoundMem( effectsound[1] ) == 1 ){
						StopSoundMem( effectsound[1] );
					}
					PlaySoundMem( effectsound[1], DX_PLAYTYPE_BACK ) ;
				}	
			}else{
				if( player.shotcount %4 == 1 ){
					addpshot( 0, player.x+4, player.y, 1.8, 1, 0.99, 205 );
					addpshot( 0, player.x-4, player.y, 1.8, 1, 1.01, 205 );
					addpshot( 1, player.x+7, player.y, 1.8, 1, 0.94, 205 );
					addpshot( 1, player.x-7, player.y, 1.8, 1, 1.06, 205 );
					addpshot( 2, player.x+10, player.y, 1.8, 1, 0.89, 205 );
					addpshot( 2, player.x-10, player.y, 1.8, 1, 1.11, 205 );
					addpshot( 3, player.x+13, player.y, 1.8, 1, 0.85, 205 );
					addpshot( 3, player.x-13, player.y, 1.8, 1, 1.15, 205 );
					if( CheckSoundMem( effectsound[1] ) == 1 ){
						StopSoundMem( effectsound[1] );
					}
					PlaySoundMem( effectsound[1], DX_PLAYTYPE_BACK ) ;
				}
				if( player.magicflg == 1 && player.shotcount %4 == 0){
					addpshot( 7, player.x+4, player.y+20, 3.6, 4, 1, 213 );
					addpshot( 7, player.x-4, player.y+20, 3.6, 5, 1, 213 );
				}
			}
			break;
		case 7:
			if( player.chara_type == 1 ){
				if( player.shotcount %3 == 1 ){
					addpshot( 0, player.x+6, player.y+20, 2.1, 2, 1.01, 202 );
					addpshot( 1, player.x+12, player.y+20, 2.1, 2, 1.03, 202 );
					addpshot( 2, player.x+3, player.y+20, 2.1, 2, 0.98, 202 );
					addpshot( 2, player.x-3, player.y+20, 2.1, 3, 1.02, 202 );
					addpshot( 0, player.x-6, player.y+20, 2.1, 3, 0.99, 202 );
					addpshot( 1, player.x-12, player.y+20, 2.1, 3, 0.97, 202 );
					if( CheckSoundMem( effectsound[1] ) == 1 ){
						StopSoundMem( effectsound[1] );
					}
					PlaySoundMem( effectsound[1], DX_PLAYTYPE_BACK ) ;
				}	
			}else{
				if( player.shotcount %4 == 1 ){
					addpshot( 0, player.x+4, player.y, 1.8, 1, 0.99, 205 );
					addpshot( 0, player.x-4, player.y, 1.8, 1, 1.01, 205 );
					addpshot( 1, player.x+7, player.y, 1.8, 1, 0.95, 205 );
					addpshot( 1, player.x-7, player.y, 1.8, 1, 1.05, 205 );
					addpshot( 2, player.x+10, player.y, 1.8, 1, 0.91, 205 );
					addpshot( 2, player.x-10, player.y, 1.8, 1, 1.09, 205 );
					addpshot( 3, player.x+13, player.y, 1.8, 1, 0.87, 205 );
					addpshot( 3, player.x-13, player.y, 1.8, 1, 1.13, 205 );
					addpshot( 4, player.x+17, player.y, 1.8, 1, 0.83, 205 );
					addpshot( 4, player.x-17, player.y, 1.8, 1, 1.17, 205 );
					if( CheckSoundMem( effectsound[1] ) == 1 ){
						StopSoundMem( effectsound[1] );
					}
					PlaySoundMem( effectsound[1], DX_PLAYTYPE_BACK ) ;
				}
				if( player.magicflg == 1 && player.shotcount %3 == 0){
					addpshot( 7, player.x+4, player.y+20, 3.6, 4, 1, 213 );
					addpshot( 7, player.x-4, player.y+20, 3.6, 5, 1, 213 );
				}
			}
			break;	
	}
}	

//���@�V���b�g�ᑬ
void pshot1s(){
	switch( player.shot_lv ){
		case 1:
			if( player.chara_type == 1 ){
				if( player.shotcount %3 == 1 ){
					addpshot( 0, player.x+4, player.y+20, 1, 1, 1, 200 );
					addpshot( 0, player.x-4, player.y+20, 1, 1, 1, 200 );
					if( CheckSoundMem( effectsound[1] ) == 1 ){
						StopSoundMem( effectsound[1] );
					}
					PlaySoundMem( effectsound[1], DX_PLAYTYPE_BACK ) ;
				}	
			}else{
				if( player.shotcount %3 == 1 ){
					addpshot( 0, player.x+4, player.y, 1, 1, 1, 203 );
					addpshot( 0, player.x-4, player.y, 1, 1, 1, 203 );
					if( CheckSoundMem( effectsound[1] ) == 1 ){
						StopSoundMem( effectsound[1] );
					}
					PlaySoundMem( effectsound[1], DX_PLAYTYPE_BACK ) ;
				}
				if( player.magicflg == 1 && player.shotcount %4 == 0){
					addpshot( 7, player.x+4, player.y+20, 1, 4, 1, 211 );
					addpshot( 7, player.x-4, player.y+20, 1, 5, 1, 211 );
				}
			}
			break;

		case 2:
			if( player.chara_type == 1 ){
				if( player.shotcount %3 == 1 ){
					addpshot( 0, player.x+8, player.y+20, 1, 1, 0.98, 200 );
					addpshot( 0, player.x-8, player.y+20, 1, 1, 1.02, 200 );
					addpshot( 1, player.x, player.y+20, 1, 1, 1, 200 );
					if( CheckSoundMem( effectsound[1] ) == 1 ){
						StopSoundMem( effectsound[1] );
					}
					PlaySoundMem( effectsound[1], DX_PLAYTYPE_BACK ) ;
				}	
			}else{
				if( player.shotcount %3 == 1 ){
					addpshot( 0, player.x+6, player.y, 1, 1, 0.96, 203 );
					addpshot( 0, player.x-6, player.y, 1, 1, 1.04, 203 );
					addpshot( 1, player.x, player.y, 1, 1, 1, 203 );
					if( CheckSoundMem( effectsound[1] ) == 1 ){
						StopSoundMem( effectsound[1] );
					}
					PlaySoundMem( effectsound[1], DX_PLAYTYPE_BACK ) ;
				}
				if( player.magicflg == 1 && player.shotcount %3 == 0){
					addpshot( 7, player.x+4, player.y+20, 1, 4, 1, 211 );
					addpshot( 7, player.x-4, player.y+20, 1, 5, 1, 211 );
				}
			}
			break;

		case 3:
			if( player.chara_type == 1 ){
				if( player.shotcount %3 == 1 ){
					addpshot( 0, player.x+6, player.y+20, 1, 1, 1.01, 200 );
					addpshot( 1, player.x+12, player.y+20, 1, 1, 0.99, 200 );
					addpshot( 0, player.x-6, player.y+20, 1, 1, 0.99, 200 );
					addpshot( 1, player.x-12, player.y+20, 1, 1, 1.01, 200 );
					if( CheckSoundMem( effectsound[1] ) == 1 ){
						StopSoundMem( effectsound[1] );
					}
					PlaySoundMem( effectsound[1], DX_PLAYTYPE_BACK ) ;
				}	
			}else{
				if( player.shotcount %4 == 1 ){
					addpshot( 0, player.x+4, player.y, 1.5, 1, 0.98, 204 );
					addpshot( 0, player.x-4, player.y, 1.5, 1, 1.02, 204 );
					if( CheckSoundMem( effectsound[1] ) == 1 ){
						StopSoundMem( effectsound[1] );
					}
					PlaySoundMem( effectsound[1], DX_PLAYTYPE_BACK ) ;
				}
				p_lazer(player.x, player.y-16, 1, 300, 2 );
				if( player.magicflg == 1 && player.shotcount %4 == 0){
					addpshot( 7, player.x+4, player.y+20, 1.8, 4, 1, 212 );
					addpshot( 7, player.x-4, player.y+20, 1.8, 5, 1, 212 );
				}
			}
			break;

		case 4:
			if( player.chara_type == 1 ){
				if( player.shotcount %3 == 1 ){
					addpshot( 0, player.x+6, player.y+20, 1.4, 1, 1.01, 201 );
					addpshot( 1, player.x+12, player.y+20, 1.4, 1, 0.99, 201 );
					addpshot( 0, player.x-6, player.y+20, 1.4, 1, 0.99, 201 );
					addpshot( 1, player.x-12, player.y+20, 1.4, 1, 1.01, 201 );
					if( CheckSoundMem( effectsound[1] ) == 1 ){
						StopSoundMem( effectsound[1] );
					}
					PlaySoundMem( effectsound[1], DX_PLAYTYPE_BACK ) ;
				}	
			}else{
				if( player.shotcount %4 == 1 ){
					addpshot( 0, player.x+2, player.y, 1.5, 1, 0.98, 204 );
					addpshot( 0, player.x-2, player.y, 1.5, 1, 1.02, 204 );
					addpshot( 1, player.x+6, player.y, 1.5, 1, 0.92, 204 );
					addpshot( 1, player.x-6, player.y, 1.5, 1, 1.08, 204 );
					if( CheckSoundMem( effectsound[1] ) == 1 ){
						StopSoundMem( effectsound[1] );
					}
					PlaySoundMem( effectsound[1], DX_PLAYTYPE_BACK ) ;
				}
				p_lazer(player.x, player.y-16, 1, 300, 2 );
				if( player.magicflg == 1 && player.shotcount %3 == 0){
					addpshot( 7, player.x+4, player.y+20, 1.8, 4, 1, 212 );
					addpshot( 7, player.x-4, player.y+20, 1.8, 5, 1, 212 );
				}
			}
			break;
		case 5:
			if( player.chara_type == 1 ){
				if( player.shotcount %3 == 1 ){
					addpshot( 0, player.x+6, player.y+20, 1.5, 1, 1.02, 201 );
					addpshot( 1, player.x+12, player.y+20, 1.5, 1, 0.985, 201 );
					addpshot( 2, player.x, player.y+20, 1.5, 1, 1, 201 );
					addpshot( 0, player.x-6, player.y+20, 1.5, 1, 0.98, 201 );
					addpshot( 1, player.x-12, player.y+20, 1.5, 1, 1.015, 201 );
					if( CheckSoundMem( effectsound[1] ) == 1 ){
						StopSoundMem( effectsound[1] );
					}
					PlaySoundMem( effectsound[1], DX_PLAYTYPE_BACK ) ;
				}	
			}else{
				if( player.shotcount %4 == 1 ){
					addpshot( 0, player.x+4, player.y, 1.4, 1, 0.99, 204 );
					addpshot( 0, player.x-4, player.y, 1.4, 1, 1.01, 204 );
					addpshot( 1, player.x+7, player.y, 1.4, 1, 0.94, 204 );
					addpshot( 1, player.x-7, player.y, 1.4, 1, 1.06, 204 );
					if( CheckSoundMem( effectsound[1] ) == 1 ){
						StopSoundMem( effectsound[1] );
					}
					PlaySoundMem( effectsound[1], DX_PLAYTYPE_BACK ) ;
				}
				p_lazer(player.x, player.y-16, 1.6, 301, 4 );
				if( player.magicflg == 1 && player.shotcount %4 == 0){
					addpshot( 7, player.x+4, player.y+20, 3, 4, 1, 213 );
					addpshot( 7, player.x-4, player.y+20, 3, 5, 1, 213 );
				}
			}
			break;
		case 6:
			if( player.chara_type == 1 ){
				if( player.shotcount %3 == 1 ){
					addpshot( 0, player.x+6, player.y+20, 2.0, 1, 1.02, 202 );
					addpshot( 1, player.x+12, player.y+20, 2.0, 1, 0.985, 202 );
					addpshot( 2, player.x, player.y+20, 2.0, 1, 1, 202 );
					addpshot( 0, player.x-6, player.y+20, 2.0, 1, 0.98, 202 );
					addpshot( 1, player.x-12, player.y+20, 2.0, 1, 1.015, 202 );
					if( CheckSoundMem( effectsound[1] ) == 1 ){
						StopSoundMem( effectsound[1] );
					}
					PlaySoundMem( effectsound[1], DX_PLAYTYPE_BACK ) ;
				}	
			}else{
				if( player.shotcount %4 == 1 ){
					addpshot( 0, player.x+4, player.y, 1.8, 1, 0.99, 205 );
					addpshot( 0, player.x-4, player.y, 1.8, 1, 1.01, 205 );
					addpshot( 1, player.x+7, player.y, 1.8, 1, 0.94, 205 );
					addpshot( 1, player.x-7, player.y, 1.8, 1, 1.06, 205 );
					addpshot( 2, player.x+10, player.y, 1.8, 1, 0.89, 205 );
					addpshot( 2, player.x-10, player.y, 1.8, 1, 1.11, 205 );
					if( CheckSoundMem( effectsound[1] ) == 1 ){
						StopSoundMem( effectsound[1] );
					}
					PlaySoundMem( effectsound[1], DX_PLAYTYPE_BACK ) ;
				}
				p_lazer(player.x, player.y-16, 1.6, 301, 4 );
				if( player.magicflg == 1 && player.shotcount %4 == 0){
					addpshot( 7, player.x+4, player.y+20, 3.6, 4, 1, 213 );
					addpshot( 7, player.x-4, player.y+20, 3.6, 5, 1, 213 );
				}
			}
			break;
		case 7:
			if( player.chara_type == 1 ){
				if( player.shotcount %3 == 1 ){
					addpshot( 0, player.x+6, player.y+20, 2.1, 1, 1.01, 202 );
					addpshot( 1, player.x+12, player.y+20, 2.1, 1, 1.03, 202 );
					addpshot( 2, player.x+3, player.y+20, 2.1, 1, 0.98, 202 );
					addpshot( 2, player.x-3, player.y+20, 2.1, 1, 1.02, 202 );
					addpshot( 0, player.x-6, player.y+20, 2.1, 1, 0.99, 202 );
					addpshot( 1, player.x-12, player.y+20, 2.1, 1, 0.97, 202 );
					if( CheckSoundMem( effectsound[1] ) == 1 ){
						StopSoundMem( effectsound[1] );
					}
					PlaySoundMem( effectsound[1], DX_PLAYTYPE_BACK ) ;
				}	
			}else{
				if( player.shotcount %4 == 1 ){
					addpshot( 0, player.x+4, player.y, 1.9, 1, 0.99, 205 );
					addpshot( 0, player.x-4, player.y, 1.9, 1, 1.01, 205 );
					addpshot( 1, player.x+7, player.y, 1.9, 1, 0.94, 205 );
					addpshot( 1, player.x-7, player.y, 1.9, 1, 1.06, 205 );
					addpshot( 2, player.x+10, player.y, 1.9, 1, 0.89, 205 );
					addpshot( 2, player.x-10, player.y, 1.9, 1, 1.11, 205 );
					if( CheckSoundMem( effectsound[1] ) == 1 ){
						StopSoundMem( effectsound[1] );
					}
					PlaySoundMem( effectsound[1], DX_PLAYTYPE_BACK ) ;
				}
				p_lazer(player.x, player.y-16, 2, 302, 7 );
				if( player.magicflg == 1 && player.shotcount %3 == 0){
					addpshot( 7, player.x+4, player.y+20, 3.6, 4, 1, 213 );
					addpshot( 7, player.x-4, player.y+20, 3.6, 5, 1, 213 );
				}
			}
			break;			
	}
}


//�G�̈ړ��ƕ\���̔��f
void Movepshot( int i, int j ){
	if( pbullet[i][j].flg == 1){
		switch( pbullet[i][j].ptn ){
			case 1:
				mybullet01( i, j );
				break;

			case 2:
				mybullet02( i, j );
				break;

			case 3:
				mybullet03( i, j );
				break;

			case 4:
				mybullet04( i, j );
				break;

			case 5:
				mybullet05( i, j );
				break;

		}
	}
}

//���@�V���b�g�̏���
void Deletepshot( int i, int j ){
	if( pbullet[i][j].x <= BULLET_MIN_XY-50 || 
		pbullet[i][j].x >= BULLET_MAX_X+50 || 
		pbullet[i][j].y <= BULLET_MIN_XY-50 || 
		pbullet[i][j].y >= BULLET_MAX_Y+50){

		pbullet[i][j].flg = 0;
	}
}

//���@����e���΂����C���֐�
void PlayerShot(){
	if ( key_shot != 0 && player.no_control == 0 && player.specialflg == 0){
		player.shotcount++;

		//�ᑬ���ǂ���
		if( key_slow != 0 ){
			pshot1s();
		}
		else{
			pshot1();
		}
	}else{
		player.shotcount = 0;
	}
	for( int i = 0; i < P_SHOT_MAX1; i++ ){
		for( int j = 0; j < P_SHOT_MAX2; j++ ){
			Movepshot( i, j );
			pbullet[i][j].time++;
			Deletepshot( i, j );
		}
	}
}

//�~�`���[�^�[�\��

/*memo----------------/
�o���������ɃT�C�Y56���炢�̖����w����]����B
�����w�̊O���Ƀ��[�^�[���񂷁B
�v�Z�ʌy���̂���25%���Ƃ�25%�p�摜���g�p����B
��{�I�ȕ`����@��%�ɉ����ď������摜���d�˂ĕ`�悷�銴���B
-----------endmemo---*/

void circlemater( int type, int maternum, int matermax ){
	int mater_par = 0;
	int typeimg = 0;
	static float	circlerad = 0.0,
					radstart = 0.0;

	mater_par =maternum * 100 / matermax;
	switch( type ){
		case 0:
			DrawRotaGraph( player.x, player.y, 0.25, circlerad, magical[0], TRUE , FALSE ) ;
			circlerad += 0.02;
			break;
		case 1:
			DrawRotaGraph( player.x, player.y, 0.25, circlerad, magical[3], TRUE , FALSE ) ;
			circlerad += 0.02;
			break;
		case 2:
			DrawRotaGraph( player.x, player.y, 0.25, circlerad, magical[1], TRUE , FALSE ) ;
			circlerad += 0.02;
			typeimg = 2;
	}
	for(int i = 0; i < mater_par / 25; i++ ){
		DrawRotaGraph( player.x, player.y, 1.0, radstart * 3.14159, circleguage[typeimg+1], TRUE , FALSE ) ;
		radstart += 0.5;
	}
	for(int j = 0; j < mater_par % 25; j++ ){
		DrawRotaGraph( player.x, player.y, 1.0, radstart * 3.14159, circleguage[typeimg], TRUE , FALSE ) ;
		radstart += 0.02;
	}
	radstart = 0.0;
}


//���@����֐�
void PlayerControl(){

	//�ړ��{���ƃt���O�̏�����
	static float	player_move_magnification = 1.0;
	static int		player_move_x	= 0;
	static int		player_move_y	= 0;
	static int		sp_lv = 0;
	static int		slashcount = 0;

	player_move_magnification = 1.0;
	player_move_x	= 0;
	player_move_y	= 0;
	if( player.no_control == 0 ){
		if( key_up != 0 ){
			player_move_y = -1;
		}
		if( key_down != 0 ){
			player_move_y = 1;
		}
		if( key_left != 0 ){
			player_move_x = -1;
		}
		if( key_right != 0 ){
			player_move_x = 1;
		}

		//�ᑬ�ړ��ɂ�鑬�x����
		if( key_slow != 0 ){
			player_move_magnification *= 0.5;
		}

		//�΂߈ړ��ɂ�鑬�x����
		if(player_move_x != 0  && player_move_y != 0 ){
			player_move_magnification *= 0.7;
		}
	}
	//�L�����N�^�[�ɂ�鑬�x����
	if(player.chara_type == 1){
		player_move_magnification *= 1.1;
	}else{
		player_move_magnification *= 0.8;
	}
		

	//���@�̈ړ����f
	player.x += 4.5 * player_move_x * player_move_magnification;
	player.y += 4.5 * player_move_y * player_move_magnification;

	//���@���s���߂����ꍇ�߂�
	if( player.x > MAX_X ){
		player.x = MAX_X;
	}
	if( player.y > MAX_Y ){
		player.y = MAX_Y;
	}
	if( player.x < MIN_XY ){
		player.x = MIN_XY;
	}
	if( player.y < MIN_XY ){
		player.y = MIN_XY;
	}
	//�|�[�Y
	if( key_pause == 1 ){
		player.pause = 1;
	}
	//���@�@�\����܂Ƃ�
	if( player.nodmg_cnt > 0 ){ //���G���Ԃ��c���Ă���
		circlemater( 1, player.nodmg_cnt, player.nodmg_max );
		player.nodmg_cnt--;
		if( player.clearflg == 1 && player.magicflg == 1 ){
			player.magicflg = 0;
			goto END_M;
		}
		//key_magic = 0;
		if( player.nodmg_cnt == 0 ){
			player.nodmg_max = 0;
		}
	}else if(player.specialflg == 2){ //����Z������

		//���J�o���[�̏ꍇ�̃��x������
		if( sp_lv == 0 ){
			sp_lv = 1;
		}
		player.charge_cnt++;
		player.no_control = 3;
		if(player.chara_type == 1){
			if( player.charge_cnt == 40 ){
				add_effect( player.x, player.y - 310, 12, 0 );
			}
			if( player.charge_cnt < 75){
			}else if( player.charge_cnt % 3 == 0){//�a��t���G�t�F�N�gON
				if( slashcount < 1 + sp_lv * 2 ){
					add_effect( player.x, player.y - 120, 10, 0);
					slashcount++;
				}
			}else if( player.charge_cnt == 120 + (player.shot_lv * 4) ){
					player.charge_cnt = 0;
					player.nodmg_cnt = player.nodmg_max;
					player.specialflg = 0;
					sp_lv = 0;
					player.no_control = 0;
					slashcount = 0;
			}
		}else{
			if( player.charge_cnt == 20 ){//�w��W�J����
				add_effect( player.x, player.y, 14, 0 );
			}else if( player.charge_cnt == 60 ){//�|�����
				add_effect( player.x, player.y, 11, sp_lv * 350 );
			}else if( player.charge_cnt == 140 ){//�c������
				for( int i = 0; i < 3+(2 * sp_lv); i++ ){
					add_hominglazer( 30 * sp_lv );
				}
			}else if( player.charge_cnt == 170 ){//�I���A���G���Ԃɓ���
				player.charge_cnt = 0;
				player.nodmg_cnt = player.nodmg_max;
				player.specialflg = 0;
				sp_lv = 0;
				player.no_control = 0;
			}
		}
	}else{	//�c���Ă��Ȃ�
		if( key_special != 0 && player.specialflg == 0 && player.magic > 150 ){//�Z�\�L�[��������Ă����׸ނ������ĂȂ�
			player.specialflg = 1;
			if(player.chara_type == 1){
				player.magic -= 120;
			}else{
				player.magic -= 150;
			}
			sp_lv = 1;
			player.charge_cnt++;
		}else if( key_special != 0 && player.specialflg == 1 ){//�Z�\�L�[����������׸ނ������Ă���
			if(key_special %2 == 0){
				player.magic--;
				if( player.magic == 0 ){
					player.nodmg_max += 60;
					goto END_S;
				}

				player.nodmg_max++;
				
				if( player.charge_cnt == 50 && player.shot_lv > sp_lv){//�Q�[�W�����܂��Ēi�K������]�T������
					sp_lv++;
					player.charge_cnt = 0;
				}else if( player.charge_cnt == 50 && player.shot_lv == sp_lv ){//���܂��Ă��邪����ȏ゠�����Ȃ�
					player.charge_cnt = 50;
				}else{//�����������܂��ĂȂ�
					player.charge_cnt++;
				}
			}
			circlemater( 2, player.charge_cnt, 50 );
			GnumDraw( sp_lv, 1, player.x + 32, player.y+32, 0 );
			if( record.config[4] == 1 ){
				GnumDraw( player.magic, 1, player.x - 32, player.y- 32, 0 );
			}

		}else if( key_special == 0 && player.specialflg == 1 ){//�Z�\�L�[��������Ė������׸ނ͗����Ă���
END_S:
			player.specialflg = 2;
			player.charge_cnt = 0;
		}else if( key_magic != 0 && player.magicflg == 0 && player.magic > 0 && player.clearflg == 0 ){//����L�[��������Ă����׸ނ������ĂȂ�
			player.magicflg = 1;
			for(int i = 0; i < 10; i++ ){
				add_effect( player.x, player.y, 13, rand(1.0));
			}
			if( CheckSoundMem( effectsound[3] ) == 1 ){
				StopSoundMem( effectsound[3] );
			}
			PlaySoundMem( effectsound[3], DX_PLAYTYPE_BACK ) ;
		}else if( key_magic != 0 && player.magicflg == 1 && player.clearflg == 0 ){//����L�[��������Ă����׸ނ������Ă���
			add_runscore();
			if(player.chara_type == 1){
				if( key_magic %5 == 0 ){
					player.magic--;
					if( player.magic == 0 || player.clearflg == 1 ){
						goto END_M;
					}
				}
			}else{
				if( key_magic %4 == 0 ){
					player.magic--;
					if( player.magic == 0 || player.clearflg == 1 ){
						goto END_M;
					}
				}
			}
			circlemater( 0, player.magic, player.magicmax );
			if( record.config[4] == 1 ){
				GnumDraw( player.magic, 1, player.x - 32, player.y- 32, 0 );
			}


		}else if( key_magic == 0 && player.magicflg == 1 || player.clearflg == 1 ){//����L�[��������Ė������t���O�͗����Ă���
END_M:
			player.magicflg = 0;
			if(player.chara_type == 1){
				player.magic -= 20;
			}else{
				player.magic -= 30;
			}
			if( player.magic < 0 ){
				player.magic = 0;
			}
			if( CheckSoundMem( effectsound[4] ) == 1 ){
				StopSoundMem( effectsound[4] );
			}
			PlaySoundMem( effectsound[4], DX_PLAYTYPE_BACK ) ;

			//�X�e�[�W���A�v���C���ő�{����K�v�ɉ����čX�V
			if(info.sp_rate[0] > info.sp_rate[1] ){
				info.sp_rate[1] = info.sp_rate[0];
				if(info.sp_rate[1] > info.sp_rate[2] ){
					info.sp_rate[2] = info.sp_rate[1];
				}
			}
			if( info.clearnum[0] > info.clearnum[1] ){
				info.clearnum[1] = info.clearnum[0];
			}
			
			//���̓L�[�������ꂽ�u�Ԉꎞ�I�ɒ��߂��X�R�A��{�X�R�A�ɉ��Z�����Ƃɖ߂��B
			if( info.sp_score[0] > info.sp_score[1] ) info.sp_score[1] = info.sp_score[0];
			info.score[0] += info.sp_score[0];
			info.sp_score[0] = 0;
			info.sp_rate[0] = 0;
			add_clearbullet();
		}
	}
	return;
}

//���@���C���֐�
void player_main(){
	static int edmgnum = 0;
	static int type = 0;
	if( player.damage_flg == 1 && player.no_control == 0 && player.nodmg_cnt == 0 ){//���������u��
		if( player.hitbullet[0] != -1 ){		//���e�̏ꍇ
			type = 0;
		}else{
			type = 1;							//���e�̏ꍇ
		}
		if( type == 0 ){
			player.hp -= ebullet[player.hitbullet[0]].atk;
		}else{
			player.hp -= erecbullet[player.hitbullet[1]].atk;
		}
		info.hitnum[0]++;
		info.hitnum[1]++;

		if( CheckSoundMem( effectsound[2] ) == 1 ){
			StopSoundMem( effectsound[2] );
		}
		PlaySoundMem( effectsound[2], DX_PLAYTYPE_BACK ) ;

		//�v���_���[�W����
		if( player.hp <= 0 ){

			//���J�o���[����
			//1�L����
			if( player.magic >= 120 && player.chara_type == 1 ){
				player.magic -= 120;
				player.magicmax -= 120;
				player.g_over_flag = 1;

			//2�L����
			}else if( player.magic >= 150 && player.chara_type == 2 ){
				player.magic -= 150;
				player.magicmax -= 150;
				player.g_over_flag = 1;

			//���J�o���[�ł��Ȃ�
			}else{
				player.g_over_flag = 2;
			}
		
		//�܂����C�t���c���Ă�
		}else{
		player.no_control = 60;
		player.damage_flg = 2;
		player.magicflg = 0;
		key_magic = 0;
		}
	}else if(player.no_control > 0 && player.damage_flg == 2){//����������̃��[�V������
		if(player.no_control > 0){
			player.y ++;
			if(player.y > MAX_Y ){
				player.y = MAX_Y;
			}
			player.no_control--;
			for(int i = 0; i < E_SHOT_MAX; i++){
				if(ebullet[i].flg == 1){
					ebullet[i].flg = 2;
					ebullet[i].delef = 20;
				}
				if(erecbullet[i].flg == 1){
					erecbullet[i].flg = 2;
					erecbullet[i].delef = 20;
				}
			}
		}
		if(player.no_control == 1){
			player.damage_flg = 0;
			player.nodmg_cnt = 180;
			player.nodmg_max = 180;
			if( player.chara_type == 1 ){
				player.magic = 200;
			}else{
				player.magic = 250;
			}
			player.no_control = 0;
		}
	}else{//�ʏ펞
		PlayerControl();
	}

	//�ȉ��L�����h�b�g�`��
	if( player.specialflg == 2 && player.chara_type == 2 ){//2�L�����Z����
		if(player.charge_cnt < 60 ){
			DrawRotaGraph( player.x, player.y, 1, 0, Playersp[1][player.charge_cnt % 60 / 10], TRUE , FALSE ) ;
		}else if( player.charge_cnt < 100 ){
			DrawRotaGraph( player.x, player.y, 1, 0, Playersp[1][6], TRUE , FALSE ) ;
		}else if( player.charge_cnt < 130 ){
			DrawRotaGraph( player.x, player.y, 1, 0, Playersp[1][7 + ((player.charge_cnt - 100) % 30 / 10)], TRUE , FALSE ) ;
		}else if( player.charge_cnt < 150 ){
			DrawRotaGraph( player.x, player.y, 1, 0, Playeranime[3][(player.charge_cnt-120)% 30 / 10], TRUE , FALSE ) ;
		}else{
			DrawRotaGraph( player.x, player.y, 1, 0, Playeranime[3][2], TRUE , FALSE ) ;
		}
	}else if( player.specialflg == 2 && player.chara_type == 1 ){//1�L�����Z����
		if( player.charge_cnt < 30 ){
			DrawRotaGraph( player.x, player.y - player.charge_cnt * 8, 1, 0, Playersp[0][0], TRUE , FALSE ) ;
		}else if( player.charge_cnt < 60 ){
			DrawRotaGraph( player.x, player.y - player.charge_cnt - 240, 1, 0, Playersp[0][(player.charge_cnt % 30 / 6) + 1], TRUE , FALSE ) ;
		}else if( player.charge_cnt < 75 +(player.shot_lv * 4)){
			DrawRotaGraph( player.x, player.y - 300, 1, 0, Playersp[0][5], TRUE , FALSE ) ;
		}else if( player.charge_cnt < 100 +(player.shot_lv * 4)){
			DrawRotaGraph( player.x, player.y - 300, 1, 0, Playersp[0][player.charge_cnt % 50 / 5], TRUE , FALSE ) ;
		}else if( player.charge_cnt < 120 +(player.shot_lv * 4)){
			DrawRotaGraph( player.x, player.y - 300 +((player.charge_cnt -(player.shot_lv * 4)) % 20 * 15) , 1, 0, Playersp[0][11], TRUE , FALSE ) ;
		}
	}else if(player.specialflg == 1 && player.nodmg_max < 10){ // �L����O1 
		DrawRotaGraph( player.x, player.y, 1, 0, Playeranime[player.chara_type + 1][0], TRUE , FALSE ) ;
	}else if(player.specialflg == 1 && player.nodmg_max < 20){ // �L����O2
		DrawRotaGraph( player.x, player.y, 1, 0, Playeranime[player.chara_type + 1][1], TRUE , FALSE ) ;
	}else if(player.specialflg == 1){ //�L�����A�j��
		DrawRotaGraph( player.x, player.y, 1, 0, Playeranime[player.chara_type + 1][(pcounter % 24 / 6) + 2], TRUE , FALSE ) ;
	}else{ //�ʏ�
		if(key_right != 0 && key_left != 0 ){
			DrawRotaGraph( player.x, player.y, 1, 0, Playeranime[player.chara_type - 1][pcounter % 24 / 6], TRUE , FALSE ) ;
		}else if(key_right != 0 ){
			DrawRotaGraph( player.x, player.y, 1, 0, Playeranime[player.chara_type - 1][4], TRUE , FALSE ) ;
		}else if(key_left != 0 ){
			DrawRotaGraph( player.x, player.y, 1, 0, Playeranime[player.chara_type - 1][5], TRUE , FALSE ) ;
		}else{
			DrawRotaGraph( player.x, player.y, 1, 0, Playeranime[player.chara_type - 1][pcounter % 24 / 6], TRUE , FALSE ) ;
		}
	}
	if( player.specialflg < 2 ){
		DrawCircle( player.x , player.y , player.size, color[0] , TRUE);
	}
}