/*--------------------------------------------/
/�L�[�R���g���[��                             /
/                                             /
/                                             /
/--------------------------------------------*/

#include "dxlib.h"
#include "Extern.h"

void HitKey(){

	GetHitKeyStateAll( Key );

	//��
	if(Key[ KEY_INPUT_UP ] != 0){
		key_up++;
	}
	else{
		key_up = 0;
	}

	//��
	if(Key[ KEY_INPUT_DOWN ] != 0){
		key_down++;
	}
	else{
		key_down = 0;
	}

	//��
	if(Key[ KEY_INPUT_LEFT ] != 0){
		key_left++;
	}
	else{
		key_left = 0;
	}

	//�E
	if(Key[ KEY_INPUT_RIGHT ] != 0){
		key_right++;
	}
	else{
		key_right = 0;
	}

	//�ᑬ
	if(Key[ KEY_INPUT_LSHIFT ] != 0){
		key_slow++;
	}
	else{
		key_slow = 0;
	}

	//�V���b�g
	if(Key[ KEY_INPUT_Z ] != 0){
		key_shot++;
	}
	else{
		key_shot = 0;
	}

	//�J��
	if(Key[ KEY_INPUT_X ] != 0){
		key_magic++;
	}
	else{
		key_magic = 0;
	}

	//�o���A�����
	if(Key[ KEY_INPUT_C ] != 0){
		key_special++;
	}
	else{
		key_special = 0;
	}

	//�|�[�Y
	if(Key[ KEY_INPUT_ESCAPE ] != 0){
		key_pause++;
	}
	else{
		key_pause = 0;
	}
}