/*--------------------------------------------/
/�G�@�V���b�g�p�^�[��3�ʂ܂Ƃ�                /
/�g�p�ԍ�40-**                                /
/                                             /
/--------------------------------------------*/

#include "dxlib.h"
#include "Extern.h"
#include "mathoperation.h"

//�e��o�^����ׂ̃v���g�^�C�v�錾
void addebullet( float x, float y, int pow, int ptn, float rad, float spd, int img, int size, int id );
void addebullet2( float x, float y, int pow, int ptn, float rad, float spd, int img, float width, float length, int id );

void ebulletcalc40( int i ){
	float fix_rad;
	fix_rad = dis_rad( enemy[i].x, enemy[i].y );
	int ren = info.dificality * 6 + 24;

	if( enemy[i].time % 180 == 40 ){
		for( int j = 0; j < ren; j++ ){
			addebullet( enemy[i].x, enemy[i].y, 8, 1, fix_rad + (2 * j / (float)ren), 1.2 + ( info.dificality * 0.3 ) , 66, 2, i );
		}
	}else if( enemy[i].time % 180 == 80 ){
		for( int j = 0; j < ren; j++ ){
			addebullet( enemy[i].x, enemy[i].y, 8, 1, fix_rad + (2 * j / (float)ren), 1.2 + ( info.dificality * 0.3 ) , 66, 2, i );
		}
	}
}

void ebulletcalc41( int i ){
	if( enemy[i].time % ( 4 - info.dificality ) == 0 ){
		for( int k = 0; k < 6; k++ ){
			addebullet( enemy[i].x, enemy[i].y, 8, 1, enemy[i].shotrad + ( k / 3.0 ), 1 + info.dificality * 0.2, 40, 2, i );
		}
		if( enemy[i].shotcnt % 2 == 1 ){
			enemy[i].shotrad += 0.006;
		}else{
			enemy[i].shotrad -= 0.006;
		}
		if( enemy[i].time % (( 4 - info.dificality ) * 7 ) == 0 ){
			enemy[i].shotcnt++;
			enemy[i].shotrad += 0.15;
		}
	}
}

void ebulletcalc42( int i ){	
	if( enemy[i].time % ( 8 - info.dificality ) == 0 && enemy[i].shotcnt < 5 + info.dificality ){
		enemy[i].shotrad = dis_rad( enemy[i].x, enemy[i].y );
		for( int i = 0; i < 10; i++ ){
			addebullet( enemy[i].x, enemy[i].y, 8, 1, enemy[i].shotrad + i / 5.0, ( 1 + enemy[i].shotcnt * 0.1 ) * ( 1 + info.dificality * 0.15 ), 51, 4, 400 );
		}
		enemy[i].shotcnt++;
	}
}

void ebulletcalc43( int i ){
	if( enemy[i].time % ( 12 - info.dificality * 2 ) == 0 ){
		enemy[i].shotrad = dis_rad( enemy[i].x, enemy[i].y );
		addebullet( enemy[i].x, enemy[i].y, 8, 1, enemy[i].shotrad, 2 + info.dificality * 0.5, 56, 4, i );
		addebullet( enemy[i].x, enemy[i].y, 8, 1, 0, 2 + info.dificality * 0.5, 56, 4, i );
	}
}

void ebulletcalc44( int i ){
	if( enemy[i].time % 180 == 40 && enemy[i].shotcnt == 0 ){
		for( int i = 0; i < 24; i++ ){
			addebullet2( enemy[i].x, enemy[i].y, 7, 33, i / 12.0, 1.5 + info.dificality * 0.3, 72, 1, 2, i );
		}
		enemy[i].shotcnt++;
	}
}

void ebulletcalc45( int i ){
	static float fixrad = 0.0;
	if( enemy[i].time == 1 ){
		fixrad = dis_rad( enemy[i].x, enemy[i].y );
	}
	if( enemy[i].time > 1 && enemy[i].shotcnt <= 11){
		if( enemy[i].time %4 == 0 ){
			addebullet( enemy[i].x +3, enemy[i].y +3, 10, 1, fixrad + (float)( -5 + enemy[i].shotcnt) / 150.0, 3, 24, 3, i );
			enemy[i].shotcnt++;
		}
	}
}

void ebulletcalc46( int i ){
	float fix_rad;
	fix_rad = dis_rad( enemy[i].x, enemy[i].y );
	if(enemy[i].time > 20 && enemy[i].shotcnt < 5 && enemy[i].time % 10 == 0){
		addebullet( enemy[i].x, enemy[i].y, 10, 1, fix_rad, 3, 41, 2, i );
		enemy[i].shotcnt++;
	}else if( enemy[i].shotcnt == 5 && enemy[i].time > 120 ){
		for(int j = 0; j < 11; j++){
			addebullet2( enemy[i].x, enemy[i].y, 7, 1, fix_rad + (float)(-5 + j)* 0.01, 2.7, 33, 0.8, 4, i );
		}
		enemy[i].shotcnt++;
	}
}

void ebulletcalc47( int i ){
	static int shotall;

	if( enemy[i].time <= 1 ){
		shotall = 80 + 16 * info.dificality;
	}

	if( enemy[i].time % ( 6 - info.dificality ) == 0 ){
		for( int j = 0; j < 8; j++ ){
			addebullet( enemy[i].x, enemy[i].y, 8, 1, ( j + ( shotall / 4.0 )) / (float) shotall, 1.5 + ( 1.5 * ( j / ( shotall / 8.0 ))), 54, 4, i );
		}
	}
}