/*--------------------------------------------/
/�G�@�V���b�g�p�^�[��05                       /
/���@�_����5�A�ˁ�                            /
/11way���@������                          /
/--------------------------------------------*/

#include "dxlib.h"
#include "Extern.h"
#include "mathoperation.h"

//�e��o�^����ׂ̃v���g�^�C�v�錾
void addebullet( float x, float y, int pow, int ptn, float rad, float spd, int img, int size, int id );
void addebullet2( float x, float y, int pow, int ptn, float rad, float spd, int img, float width, float length, int id );

void enemybulletcalc05 ( int i ){
	float fix_rad;
	fix_rad = dis_rad( enemy[i].x, enemy[i].y );
	if(enemy[i].time > 20 && enemy[i].shotcnt < 5 && enemy[i].time % 10 == 0){
		addebullet( enemy[i].x, enemy[i].y, 10, 1, fix_rad, 3, 41, 2, i );
		enemy[i].shotcnt++;
	}else if( enemy[i].shotcnt == 5 && enemy[i].time > 120 ){
		for(int j = 0; j < 11; j++){
			addebullet2( enemy[i].x, enemy[i].y, 7, 1, fix_rad + (float)(-5 + j)* 0.01, 2.7, 33, 0.8, 4, i );
		}
		enemy[i].shotcnt++;
	}
}