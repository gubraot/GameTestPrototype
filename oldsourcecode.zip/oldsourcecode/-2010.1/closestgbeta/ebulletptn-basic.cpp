/*--------------------------------------------/
/��{�e                                       /
/�@�@�@�@�@�@�@�@�@�@�@�@�@                   /
/�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@           /
/--------------------------------------------*/

#include "dxlib.h"
#include "Extern.h"
#include "mathoperation.h"
#include <math.h>

//���i�e
void ebulletptn01( int i, int type ){
	switch(type){
		case 0:
			ebullet[i].x	+= rad_x( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
			ebullet[i].y	+= rad_y( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
			break;

		case 1:
			erecbullet[i].x	+= rad_x( erecbullet[i].rad, erecbullet[i].spd * spd.objspeed );
			erecbullet[i].y	+= rad_y( erecbullet[i].rad, erecbullet[i].spd * spd.objspeed );
			break;
	}
}

//�ˏo���������i�e
void ebulletptn02( int i, int type ){
	float fix_spd;
	switch(type){
		case 0:
			if( ebullet[i].time < 6 ){
				fix_spd = 10;
			}else{
				fix_spd = ebullet[i].spd;
			}
			ebullet[i].x	+= rad_x( ebullet[i].rad, fix_spd * spd.objspeed );
			ebullet[i].y	+= rad_y( ebullet[i].rad, fix_spd * spd.objspeed );
			break;

		case 1:
			if( erecbullet[i].time < 6 ){
				fix_spd = 10;
			}else{
				fix_spd = erecbullet[i].spd;
			}
			erecbullet[i].x	+= rad_x( erecbullet[i].rad, erecbullet[i].spd * spd.objspeed );
			erecbullet[i].y	+= rad_y( erecbullet[i].rad, erecbullet[i].spd * spd.objspeed );
			break;
	}
}


//���炵���i�e
void ebulletptn03( int i, int type ){
	switch(type){
		case 0:
			if( ebullet[i].time == 0){
				ebullet[i].rad = ebullet[i].rad + dis_rad( ebullet[i].x, ebullet[i].y );
			}
			ebullet[i].x	+= rad_x( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
			ebullet[i].y	+= rad_y( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
			break;

		case 1:
			if( erecbullet[i].time == 0){
				erecbullet[i].rad = erecbullet[i].rad + dis_rad( erecbullet[i].x, erecbullet[i].y );
			}
			erecbullet[i].x	+= rad_x( erecbullet[i].rad, erecbullet[i].spd * spd.objspeed );
			erecbullet[i].y	+= rad_y( erecbullet[i].rad, erecbullet[i].spd * spd.objspeed );
			break;
	}
}


//���]�e(��)
void ebulletptn04( int i, int type ){
	if( ebullet[i].time < 90 ){
	ebullet[i].rad	+= (float) (2 * spd.objspeed)  / 360.0;
	}
	ebullet[i].x	+= rad_x( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
	ebullet[i].y	+= rad_y( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
}


//���]�e(�E)
void ebulletptn05( int i, int type ){
	if( ebullet[i].time < 90 ){
	ebullet[i].rad	-= (float) (2 * spd.objspeed)  / 360.0;
	}
	ebullet[i].x	+= rad_x( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
	ebullet[i].y	+= rad_y( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
}

//�t���e
void ebulletptn06( int i, int type ){
	switch(type){
		case 0:
			if( ebullet[i].spd < ( -1.0 - info.dificality * 1.0 ) ) ebullet[i].spd -= 1.0/20.0;
			if( ebullet[i].spd == -3.0 ) ebullet[i].rad += rand(0.1);
			ebullet[i].x	+= rad_x( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
			ebullet[i].y	+= rad_y( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
			break;

		case 1:
			if( erecbullet[i].spd <  ( -1.0 - info.dificality * 1.0 ) ) erecbullet[i].spd -= 1.0/20.0;
			if( erecbullet[i].spd == -3.0 ) erecbullet[i].rad += rand(0.1);
			erecbullet[i].x	+= rad_x( erecbullet[i].rad, erecbullet[i].spd * spd.objspeed );
			erecbullet[i].y	+= rad_y( erecbullet[i].rad, erecbullet[i].spd * spd.objspeed );
			break;
	}
}


//�����e
void ebulletptn07( int i, int type ){
	float memx,memy,memspd;
	switch(type){
		case 0:
			memx = rad_x( ebullet[i].rad, ebullet[i].spd );
			memy = rad_y( ebullet[i].rad, ebullet[i].spd ) + 0.025;
			memspd = ebullet[i].spd;
			ebullet[i].rad = free_rad( 0, 0, memx, memy );
			ebullet[i].spd = sqrt( distancefree( 0, 0, memx, memy ));
			

			ebullet[i].x	+= rad_x( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
			ebullet[i].y	+= rad_y( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
			break;

		case 1:
			memx = rad_x( erecbullet[i].rad, erecbullet[i].spd );
			memy = rad_y( erecbullet[i].rad, erecbullet[i].spd ) + 0.025;
			memspd = ebullet[i].spd;
			erecbullet[i].rad = free_rad( 0, 0, memx, memy );
			erecbullet[i].spd = sqrt( distancefree( 0, 0, memx, memy ));

			erecbullet[i].x	+= rad_x( erecbullet[i].rad, erecbullet[i].spd * spd.objspeed );
			erecbullet[i].y	+= rad_y( erecbullet[i].rad, erecbullet[i].spd * spd.objspeed );
			break;
	}
}

//���˕Ԃ�e
void ebulletptn08( int i, int type ){
	switch(type){
		case 0:	
			if( ebullet[i].x < ebullet[i].size ){
				ebullet[i].rad = fabs( ebullet[i].rad );
			}
			if( ebullet[i].x > (float)BULLET_MAX_X - ebullet[i].size ){
				ebullet[i].rad = - fabs( ebullet[i].rad );
			}
			if( ebullet[i].y < ebullet[i].size ){
				ebullet[i].rad = 1.0 - ebullet[i].rad;
			}
			ebullet[i].x	+= rad_x( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
			ebullet[i].y	+= rad_y( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
			break;

		case 1:
			if( erecbullet[i].x < erecbullet[i].length ){
				erecbullet[i].rad = fabs( erecbullet[i].rad );
			}
			if( erecbullet[i].x > (float)BULLET_MAX_X - erecbullet[i].length ){
				erecbullet[i].rad = - fabs( erecbullet[i].rad );
			}
			if( erecbullet[i].y < erecbullet[i].length ){
				erecbullet[i].rad = 1.0 - erecbullet[i].rad;
			}
			erecbullet[i].x	+= rad_x( erecbullet[i].rad, erecbullet[i].spd * spd.objspeed );
			erecbullet[i].y	+= rad_y( erecbullet[i].rad, erecbullet[i].spd * spd.objspeed );
			break;
	}
}