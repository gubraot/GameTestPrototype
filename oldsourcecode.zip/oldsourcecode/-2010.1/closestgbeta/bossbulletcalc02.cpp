/*--------------------------------------------/
/1�{�X�p�^�[��2                               /
/���@��̒e�΂�T��                         /
/                                             /
/--------------------------------------------*/

#include "dxlib.h"
#include "Extern.h"
#include "mathoperation.h"

//�e��o�^����ׂ̃v���g�^�C�v�錾
void addebullet( float x, float y, int pow, int ptn, float rad, float spd, int img, int size, int id );
void addebullet2( float x, float y, int pow, int ptn, float rad, float spd, int img, float width, float length, int id );

void bossbulletcalc02(){
	static float lockrad;
	if( boss.cnt %180 == 0 ){
		lockrad = dis_rad( boss.x, boss.y );
	}
	if( boss.cnt %180 <= 140 ){
		addebullet2( boss.x, boss.y, 10, 1, lockrad + (rand05() / 2), 2, 30, 0.8, 4, 400);
		addebullet( boss.x, boss.y, 10, 1, lockrad + (rand05() / 2), 2.5, 40, 2, 400);
	}

}