/*--------------------------------------------/
/���w���Z�֐����C�u����                       /
/�Q�[���ɕK�v�Ȍv�Z�Ɋւ���֐��܂Ƃ�         /
/                                             /
/--------------------------------------------*/

float rad_x( float rad, float spd );
float rad_y( float rad, float spd );
float ang_x( float ang, float spd );
float ang_y( float ang, float spd );
float x_dis( float x );
float y_dis( float y );
float dis_rad( float x, float y );
float free_rad( float x, float y, float tarx, float tary );
float rand10();
float rand05();
float rand( float rand );
float absrand( float rand );
float distance( float x,float y );
float distancefree( float x,float y, float x2, float y2 );
int searchdisobject( int parmission );