/*--------------------------------------------/
/�摜�\��������ׂ̉���                       /
/                                             /
/                                             /
/--------------------------------------------*/

#include "dxlib.h"
#include "Extern.h"
#include "mathoperation.h"

//�~����pi
#define PI 3.1415926535897932384626433832795f

void cleate_recarea2( float x1, float y1, float x2, float y2, float x3, float y3, float x4, float y4, int atk, int hitnum, int time, int target, float spd, float rad, int graph );
void GnumDraw( int Num, int type, int x, int y, int keta );

//���j���[�摜�`��
void drawmenuimg( int x, int y, int num ){
	switch( num ){
		case 0:
			DrawGraph( x, y, menuimg[0], TRUE ) ;
			break;
		case 1:
			DrawGraph( x, y, menuimg[1], TRUE ) ;
			break;
		case 2:
			DrawGraph( x, y, menuimg[2], TRUE ) ;
			break;
		case 3:
			DrawGraph( x, y, menuimg[3], TRUE ) ;
			break;
		case 4:
			DrawGraph( x, y, menuimg[4], TRUE ) ;
			break;
	}
}

//�e�̕`��
//�Ԓl:�Ȃ��@����:x���W�Ay���W�A�p�x�A�p�x�^�C�v(�x��or���W�A��)�A�e�摜�ԍ�
void drawbullet( float x, float y, float rad, int radtype, int num ){
	if( radtype == 1 ){
		rad = rad / 180.0;
	}
		rad = - ( (rad - 1.0 ) * PI);
	switch( num ){
		//����̂�
		case -1:
			break;
			
		//���~�e
		case 0:
			DrawRotaGraph( x, y, 1.0, rad, rsbullet[0], TRUE , FALSE ) ;
			break;
		case 1:
			DrawRotaGraph( x, y, 1.0, rad, rsbullet[1], TRUE , FALSE ) ;
			break;
		case 2:
			DrawRotaGraph( x, y, 1.0, rad, rsbullet[2], TRUE , FALSE ) ;
			break;
		case 3:
			DrawRotaGraph( x, y, 1.0, rad, rsbullet[3], TRUE , FALSE ) ;
			break;
		case 4:
			DrawRotaGraph( x, y, 1.0, rad, rsbullet[4], TRUE , FALSE ) ;
			break;
		case 5:
			DrawRotaGraph( x, y, 1.0, rad, rsbullet[5], TRUE , FALSE ) ;
			break;
		case 6:
			DrawRotaGraph( x, y, 1.0, rad, rsbullet[6], TRUE , FALSE ) ;
			break;
		case 7:
			DrawRotaGraph( x, y, 1.0, rad, rsbullet[7], TRUE , FALSE ) ;
			break;
		//�ʏ�
		case 8:
			DrawRotaGraph( x, y, 1.0, rad, nbullet[19], TRUE , FALSE ) ;
			break;
		case 9:
			DrawRotaGraph( x, y, 1.0, rad, nbullet[20], TRUE , FALSE ) ;
			break;
		case 10:
			DrawRotaGraph( x, y, 1.0, rad, nbullet[21], TRUE , FALSE ) ;
			break;
		case 11:
			DrawRotaGraph( x, y, 1.0, rad, nbullet[22], TRUE , FALSE ) ;
			break;
		case 12:
			DrawRotaGraph( x, y, 1.0, rad, nbullet[23], TRUE , FALSE ) ;
			break;
		case 13:
			DrawRotaGraph( x, y, 1.0, rad, nbullet[24], TRUE , FALSE ) ;
			break;
		case 14:
			DrawRotaGraph( x, y, 1.0, rad, nbullet[25], TRUE , FALSE ) ;
			break;
		case 15:
			DrawRotaGraph( x, y, 1.0, rad, nbullet[26], TRUE , FALSE ) ;
			break;
		case 16:
			DrawRotaGraph( x, y, 1.0, rad, nbullet[27], TRUE , FALSE ) ;
			break;
		case 17:
			DrawRotaGraph( x, y, 1.0, rad, nbullet[28], TRUE , FALSE ) ;
			break;
		case 18:
			DrawRotaGraph( x, y, 1.0, rad, nbullet[29], TRUE , FALSE ) ;
			break;
		case 19:
			DrawRotaGraph( x, y, 1.0, rad, nbullet[30], TRUE , FALSE ) ;
			break;
		case 20:
			DrawRotaGraph( x, y, 1.0, rad, nbullet[31], TRUE , FALSE ) ;
			break;
		case 21:
			DrawRotaGraph( x, y, 1.0, rad, nbullet[32], TRUE , FALSE ) ;
			break;
		case 22:
			DrawRotaGraph( x, y, 1.0, rad, nbullet[33], TRUE , FALSE ) ;
			break;
		case 23:
			DrawRotaGraph( x, y, 1.0, rad, nbullet[34], TRUE , FALSE ) ;
			break;
		case 24:
			DrawRotaGraph( x, y, 1.0, rad, nbullet[35], TRUE , FALSE ) ;
			break;
		case 25:
			DrawRotaGraph( x, y, 1.0, rad, nbullet[36], TRUE , FALSE ) ;
			break;
		case 26:
			DrawRotaGraph( x, y, 1.0, rad, nbullet[37], TRUE , FALSE ) ;
			break;
		case 27:
			DrawRotaGraph( x, y, 1.0, rad, nbullet[38], TRUE , FALSE ) ;
			break;
		case 28:
			DrawRotaGraph( x, y, 1.0, rad, nbullet[39], TRUE , FALSE ) ;
			break;
		//�Z�j
		case 29:
			DrawRotaGraph( x, y, 1.0, rad, n2bullet[0], TRUE , FALSE ) ;
			break;
		case 30:
			DrawRotaGraph( x, y, 1.0, rad, n2bullet[1], TRUE , FALSE ) ;
			break;
		case 31:
			DrawRotaGraph( x, y, 1.0, rad, n2bullet[2], TRUE , FALSE ) ;
			break;
		case 32:
			DrawRotaGraph( x, y, 1.0, rad, n2bullet[3], TRUE , FALSE ) ;
			break;
		case 33:
			DrawRotaGraph( x, y, 1.0, rad, n2bullet[4], TRUE , FALSE ) ;
			break;
		case 34:
			DrawRotaGraph( x, y, 1.0, rad, n2bullet[5], TRUE , FALSE ) ;
			break;
		case 35:
			DrawRotaGraph( x, y, 1.0, rad, n2bullet[6], TRUE , FALSE ) ;
			break;
		case 36:
			DrawRotaGraph( x, y, 1.0, rad, n2bullet[7], TRUE , FALSE ) ;
			break;
		//���e
		case 37:
			DrawRotaGraph( x, y, 1.0, rad, smbullet[0], TRUE , FALSE ) ;
			break;
		case 38:
			DrawRotaGraph( x, y, 1.0, rad, smbullet[1], TRUE , FALSE ) ;
			break;
		case 39:
			DrawRotaGraph( x, y, 1.0, rad, smbullet[2], TRUE , FALSE ) ;
			break;
		case 40:
			DrawRotaGraph( x, y, 1.0, rad, smbullet[3], TRUE , FALSE ) ;
			break;
		case 41:
			DrawRotaGraph( x, y, 1.0, rad, smbullet[4], TRUE , FALSE ) ;
			break;
		//�N���X�^���e
		case 42:
			DrawRotaGraph( x, y, 1.0, rad, crisbullet[0], TRUE , FALSE ) ;
			break;
		case 43:
			DrawRotaGraph( x, y, 1.0, rad, crisbullet[1], TRUE , FALSE ) ;
			break;
		case 44:
			DrawRotaGraph( x, y, 1.0, rad, crisbullet[2], TRUE , FALSE ) ;
			break;
		case 45:
			DrawRotaGraph( x, y, 1.0, rad, crisbullet[3], TRUE , FALSE ) ;
			break;
		case 46:
			DrawRotaGraph( x, y, 1.0, rad, crisbullet[4], TRUE , FALSE ) ;
			break;
		case 47:
			DrawRotaGraph( x, y, 1.0, rad, crisbullet[5], TRUE , FALSE ) ;
			break;
		case 48:
			DrawRotaGraph( x, y, 1.0, rad, crisbullet[6], TRUE , FALSE ) ;
			break;
		case 49:
			DrawRotaGraph( x, y, 1.0, rad, crisbullet[7], TRUE , FALSE ) ;
			break;
		//�����e
		case 50:
			DrawRotaGraph( x, y, 1.0, rad, mcirclebullet[0], TRUE , FALSE ) ;
			break;
		case 51:
			DrawRotaGraph( x, y, 1.0, rad, mcirclebullet[1], TRUE , FALSE ) ;
			break;
		case 52:
			DrawRotaGraph( x, y, 1.0, rad, mcirclebullet[2], TRUE , FALSE ) ;
			break;
		case 53:
			DrawRotaGraph( x, y, 1.0, rad, mcirclebullet[3], TRUE , FALSE ) ;
			break;
		case 54:
			DrawRotaGraph( x, y, 1.0, rad, mcirclebullet[4], TRUE , FALSE ) ;
			break;
		case 55:
			DrawRotaGraph( x, y, 1.0, rad, mcirclebullet[5], TRUE , FALSE ) ;
			break;
		case 56:
			DrawRotaGraph( x, y, 1.0, rad, mcirclebullet[6], TRUE , FALSE ) ;
			break;
		case 57:
			DrawRotaGraph( x, y, 1.0, rad, mcirclebullet[7], TRUE , FALSE ) ;
			break;
		//�偛�e
		case 58:
			DrawRotaGraph( x, y, 1.0, rad, lcirclebullet[0], TRUE , FALSE ) ;
			break;
		case 59:
			DrawRotaGraph( x, y, 1.0, rad, lcirclebullet[1], TRUE , FALSE ) ;
			break;
		case 60:
			DrawRotaGraph( x, y, 1.0, rad, lcirclebullet[2], TRUE , FALSE ) ;
			break;
		case 61:
			DrawRotaGraph( x, y, 1.0, rad, lcirclebullet[3], TRUE , FALSE ) ;
			break;
		case 62:
			DrawRotaGraph( x, y, 1.0, rad, lcirclebullet[4], TRUE , FALSE ) ;
			break;
		case 63:
			DrawRotaGraph( x, y, 1.0, rad, lcirclebullet[5], TRUE , FALSE ) ;
			break;
		case 64:
			DrawRotaGraph( x, y, 1.0, rad, lcirclebullet[6], TRUE , FALSE ) ;
			break;
		case 65:
			DrawRotaGraph( x, y, 1.0, rad, lcirclebullet[7], TRUE , FALSE ) ;
			break;

		//���e
		case 66:
			DrawRotaGraph( x, y, 0.2, rad, rbullet[0], TRUE , FALSE ) ;
			break;
		case 67:
			DrawRotaGraph( x, y, 0.2, rad, rbullet[1], TRUE , FALSE ) ;
			break;
		case 68:
			DrawRotaGraph( x, y, 0.2, rad, rbullet[2], TRUE , FALSE ) ;
			break;
		case 69:
			DrawRotaGraph( x, y, 0.2, rad, rbullet[3], TRUE , FALSE ) ;
			break;
		case 70:
			DrawRotaGraph( x, y, 0.2, rad, rbullet[4], TRUE , FALSE ) ;
			break;
		case 71:
			DrawRotaGraph( x, y, 0.2, rad, rbullet[5], TRUE , FALSE ) ;
			break;
		case 72:
			DrawRotaGraph( x, y, 0.2, rad, rbullet[6], TRUE , FALSE ) ;
			break;
		case 73:
			DrawRotaGraph( x, y, 0.2, rad, rbullet[7], TRUE , FALSE ) ;
			break;
		case 74:
			DrawRotaGraph( x, y, 0.2, rad, rbullet[8], TRUE , FALSE ) ;
			break;
		case 75:
			DrawRotaGraph( x, y, 0.2, rad, rbullet[9], TRUE , FALSE ) ;
			break;

		//��N���X�^���e
		case 76:
			DrawRotaGraph( x, y, 1, rad, lcrisbullet[0], TRUE , FALSE ) ;
			break;
		case 77:
			DrawRotaGraph( x, y, 1, rad, lcrisbullet[1], TRUE , FALSE ) ;
			break;
		case 78:
			DrawRotaGraph( x, y, 1, rad, lcrisbullet[2], TRUE , FALSE ) ;
			break;
		case 79:
			DrawRotaGraph( x, y, 1, rad, lcrisbullet[3], TRUE , FALSE ) ;
			break;
		case 80:
			DrawRotaGraph( x, y, 1, rad, lcrisbullet[4], TRUE , FALSE ) ;
			break;
		case 81:
			DrawRotaGraph( x, y, 1, rad, lcrisbullet[5], TRUE , FALSE ) ;
			break;
		case 82:
			DrawRotaGraph( x, y, 1, rad, lcrisbullet[6], TRUE , FALSE ) ;
			break;
		case 83:
			DrawRotaGraph( x, y, 1, rad, lcrisbullet[7], TRUE , FALSE ) ;
			break;

		//���ȉ~�e
		case 84:
			DrawRotaGraph( x, y, 1, rad, mscirclebullet[0], TRUE , FALSE ) ;
			break;
		case 85:
			DrawRotaGraph( x, y, 1, rad, mscirclebullet[1], TRUE , FALSE ) ;
			break;
		case 86:
			DrawRotaGraph( x, y, 1, rad, mscirclebullet[2], TRUE , FALSE ) ;
			break;
		case 87:
			DrawRotaGraph( x, y, 1, rad, mscirclebullet[3], TRUE , FALSE ) ;
			break;
		case 88:
			DrawRotaGraph( x, y, 1, rad, mscirclebullet[4], TRUE , FALSE ) ;
			break;
		case 89:
			DrawRotaGraph( x, y, 1, rad, mscirclebullet[5], TRUE , FALSE ) ;
			break;
		case 90:
			DrawRotaGraph( x, y, 1, rad, mscirclebullet[6], TRUE , FALSE ) ;
			break;
		case 91:
			DrawRotaGraph( x, y, 1, rad, mscirclebullet[7], TRUE , FALSE ) ;
			break;

		//�j�e
		case 92:
			DrawRotaGraph( x, y, 1, rad, stickbullet1[0], TRUE , FALSE ) ;
			break;
		case 93:
			DrawRotaGraph( x, y, 1, rad, stickbullet1[1], TRUE , FALSE ) ;
			break;
		case 94:
			DrawRotaGraph( x, y, 1, rad, stickbullet1[2], TRUE , FALSE ) ;
			break;
		case 95:
			DrawRotaGraph( x, y, 1, rad, stickbullet1[3], TRUE , FALSE ) ;
			break;
		case 96:
			DrawRotaGraph( x, y, 1, rad, stickbullet1[4], TRUE , FALSE ) ;
			break;
		case 97:
			DrawRotaGraph( x, y, 1, rad, stickbullet1[5], TRUE , FALSE ) ;
			break;
		case 98:
			DrawRotaGraph( x, y, 1, rad, stickbullet1[6], TRUE , FALSE ) ;
			break;
		case 99:
			DrawRotaGraph( x, y, 1, rad, stickbullet1[7], TRUE , FALSE ) ;
			break;

		//�_�e
		case 100:
			DrawRotaGraph( x, y, 1, rad, stickbullet2[0], TRUE , FALSE ) ;
			break;
		case 101:
			DrawRotaGraph( x, y, 1, rad, stickbullet2[1], TRUE , FALSE ) ;
			break;
		case 102:
			DrawRotaGraph( x, y, 1, rad, stickbullet2[2], TRUE , FALSE ) ;
			break;
		case 103:
			DrawRotaGraph( x, y, 1, rad, stickbullet2[3], TRUE , FALSE ) ;
			break;
		case 104:
			DrawRotaGraph( x, y, 1, rad, stickbullet2[4], TRUE , FALSE ) ;
			break;
		case 105:
			DrawRotaGraph( x, y, 1, rad, stickbullet2[5], TRUE , FALSE ) ;
			break;
		case 106:
			DrawRotaGraph( x, y, 1, rad, stickbullet2[6], TRUE , FALSE ) ;
			break;
		case 107:
			DrawRotaGraph( x, y, 1, rad, stickbullet2[7], TRUE , FALSE ) ;
			break;

		//���@�e
		case 200:
			DrawRotaGraph( x, y, 0.4, rad, pbulletimg[0], TRUE , FALSE ) ;
			break;

		case 201:
			DrawRotaGraph( x, y, 0.7, rad, pbulletimg[0], TRUE , FALSE ) ;
			break;

		case 202:
			DrawRotaGraph( x, y, 1.0, rad, pbulletimg[0], TRUE , FALSE ) ;
			break;

		case 203:
			DrawRotaGraph( x, y, 0.4, rad, pbulletimg[1], TRUE , FALSE ) ;
			break;

		case 204:
			DrawRotaGraph( x, y, 0.7, rad, pbulletimg[1], TRUE , FALSE ) ;
			break;

		case 205:
			DrawRotaGraph( x, y, 1.0, rad, pbulletimg[1], TRUE , FALSE ) ;
			break;

		case 211:
			DrawRotaGraph( x, y, 0.4, rad, pbulletimg[2], TRUE , FALSE ) ;
			break;

		case 212:
			DrawRotaGraph( x, y, 0.6, rad, pbulletimg[2], TRUE , FALSE ) ;
			break;

		case 213:
			DrawRotaGraph( x, y, 0.9, rad, pbulletimg[2], TRUE , FALSE ) ;
			break;

		case 214:
			DrawRotaGraph( x, y, 1.0, rad, pbulletimg[2], TRUE , FALSE ) ;
			break;

		//���@���[�U�[�e
		case 300:
			DrawRotaGraph( x, y, 0.2, rad, rbullet[8], TRUE , FALSE ) ;
			break;

		case 301:
			DrawRotaGraph( x, y, 0.35, rad, rbullet[7], TRUE , FALSE ) ;
			break;

		case 302:
			DrawRotaGraph( x, y, 0.5, rad, rbullet[6], TRUE , FALSE ) ;
			break;

		case 303:
			DrawRotaGraph( x, y, 0.7, rad, rbullet[6], TRUE , FALSE ) ;
			break;




	}
	SetDrawBlendMode( DX_BLENDMODE_NOBLEND , 0 );
}

//�G�t�F�N�g�`��p

//�G�t�F�N�g�̓o�^
//�Ԓl:�Ȃ��@����:x���W�Ay���W�A�G�t�F�N�g�̎�ށA���W�A������
void add_effect( float x, float y, int type, float rad ){
	for( int i = 0; i < EFFECTMAX; i++ ){
		if( effect[i].flg == 0 ){
			effect[i].flg	= 1;
			effect[i].x		= x;
			effect[i].y		= y;
			effect[i].type	= type;
			effect[i].count	= 0;
			effect[i].rad	= rad;
			switch( type ){//�e�G�t�F�N�g�̕`�掞�Ԃ̓o�^
				case 0:
					effect[i].lifecount = 32;
					break;

				case 1:
					effect[i].lifecount = 20;
					break;

				case 2:
					effect[i].lifecount = 25;
					effect[i].rad = rand(1.0);
					break;

				case 3:
					effect[i].lifecount = 48;
					break;

				case 4:
					effect[i].lifecount = 60;
					break;

				case 5:
					effect[i].lifecount = 75;
					break;

				case 6:
					effect[i].lifecount = 30;
					break;

				case 7:
					effect[i].lifecount = rad;
					effect[i].rad = rand(1.0);
					break;

				case 8:
					effect[i].lifecount = 48;
					break;

				case 9:
					effect[i].lifecount = 14;
					break;

				case 10:
					effect[i].lifecount = 16;
					effect[i].x			= x + rand( 80.0 );
					effect[i].y			= y + rand( 80.0 );
					effect[i].rad		= rand( 1.0 );
					break;

				case 11:
					effect[i].lifecount = 25;
					break;

				case 12:
					effect[i].lifecount = 15;
					break;

				case 13:
					effect[i].lifecount = 15;
					break;

				case 14:
					effect[i].lifecount = 60;
					break;

				case 15:
					effect[i].lifecount = 15;
					break;

				case 16:
					effect[i].lifecount = 20 + ( (rad + 3) / 3 );
					break;

				//�o�b�N�{�[�h��ɕ`�悷�����
				case 101:
					effect[i].rad = rand( 0.1 ) - 0.2;
					effect[i].x = 420 + GetRand( 300 );
					effect[i].y = 180;
					effect[i].flg = 2;
					effect[i].fanc = 1.9 + rand( 1.0 );
			}
			break;
		}
	}
}

//�G�t�F�N�g�̕\��
void draw_effect( int i, int type ){
	float rad;
	int fix_x,fix_y,num;
	rad = (effect[i].rad + 1) * PI;
	switch( type ){
		case 0://�����ۂ�hiteff
			SetDrawBlendMode( DX_BLENDMODE_ALPHA , 100 );
			DrawRotaGraph2( effect[i].x, effect[i].y, 16, 64, 0.6, rad, hitsmoke[effect[i].count], TRUE ) ;
			break;
		case 1://�ւ��ۂ�hiteff
			SetDrawBlendMode( DX_BLENDMODE_ALPHA , 150 );
			fix_x	= effect[i].x + rad_x( effect[i].rad , effect[i].count* 2 );
			fix_y	= effect[i].y + rad_y( effect[i].rad , effect[i].count* 2 );
			DrawRotaGraph( fix_x, fix_y, (float)(effect[i].count / 60.0), -effect[i].rad * PI, hitring, TRUE ) ;
			break;
		case 2://�����_����1�����ۂ�����
			SetDrawBlendMode( DX_BLENDMODE_ALPHA , 250 - (effect[i].count * 10) );
			effect[i].x += rad_x( effect[i].rad , (25 - effect[i].count)/ 4 );
			effect[i].y += rad_y( effect[i].rad , (25 - effect[i].count)/ 4 );
			DrawRotaGraph( effect[i].x, effect[i].y, 0.3, 0,star[0], TRUE ) ;
			break;

		case 3://�G�̔���1
			SetDrawBlendMode( DX_BLENDMODE_ALPHA , 255);
			DrawRotaGraph( effect[i].x, effect[i].y, 1, 0,enemydeathimg[effect[i].count / 3], TRUE ) ;
			break;

		case 4://�i�X�㏸���鐔��(�X�R�A�Ƃ�)�@��rad�ɕ\�����鐔�l������B
			SetDrawBlendMode( DX_BLENDMODE_ALPHA , 300 - (effect[i].count * 5) );
			effect[i].y --;
			DrawFormatStringToHandle( effect[i].x, effect[i].y, color[4], font[3], "%d", (int)effect[i].rad) ;
			break;

		case 5://�����Ȃ���I
			SetDrawBlendMode( DX_BLENDMODE_ALPHA , 255 );
			DrawGraph( effect[i].x, effect[i].y, powerup, TRUE);
			effect[i].y --;
			break;

		case 6://�G�����j��̔j��
			SetDrawBlendMode( DX_BLENDMODE_ALPHA , 255 - (effect[i].count * 10) );
			effect[i].x += rad_x( effect[i].rad , (30 - effect[i].count)/ 5 );
			effect[i].y += rad_y( effect[i].rad , (30 - effect[i].count)/ 5 );
			DrawRotaGraph( effect[i].x, effect[i].y, 0.7, i * 0.1 + (effect[i].count * 0.2), edeathkake[i % 6], TRUE ) ;
			break;

		case 7://�{�X�N���A��̔j��
			if( effect[i].lifecount - effect[i].count <= 50 ){
				SetDrawBlendMode( DX_BLENDMODE_ALPHA , 200 - ((effect[i].lifecount - effect[i].count) * 4) );
				effect[i].x += rad_x( effect[i].rad , (effect[i].lifecount - effect[i].count)/ 5 );
				effect[i].y += rad_y( effect[i].rad , (effect[i].lifecount - effect[i].count)/ 5 );
				DrawRotaGraph( effect[i].x, effect[i].y, 1.5, i * 0.1 + (effect[i].count * 0.2), bdeathkake[i % 5], TRUE ) ;
			}
			break;

		case 8://�{�X�̔���
			SetDrawBlendMode( DX_BLENDMODE_ALPHA , 170);
			DrawRotaGraph( effect[i].x, effect[i].y, 1, 0,bossdeathimg[effect[i].count / 3], TRUE ) ;
			break;

		case 9://1�L�����q�b�g�G�t�F�N�g
			SetDrawBlendMode( DX_BLENDMODE_ALPHA , 170);
			if( effect[i].count >= 6 || effect[i].count <= 13 ){
				DrawRotaGraph( effect[i].x, effect[i].y, 1, 0, slasheff[(effect[i].count - 6) % 8 / 4], TRUE ) ;
			}
			if( effect[i].count <= 7 ){
				DrawRotaGraph( effect[i].x, effect[i].y, 1, -rad / 2, slasheff[effect[i].count % 8 / 4], TRUE ) ;
			}
			break;

		case 10://1�L�����Z�a����G�t�F�N�g
			SetDrawBlendMode( DX_BLENDMODE_ALPHA , 170 - (effect[i].count * 5));
			if( effect[i].count < 4 ){
				DrawRotaGraph( effect[i].x, effect[i].y, 0.6, rad, spslasheff[effect[i].count % 4 / 2], TRUE ) ;
			}else{
				if( effect[i].count == 5 ){//�G�t�F�N�g�֐�����͈͔�����Ăяo���B
					cleate_recarea2( effect[i].x -85, effect[i].y -85, effect[i].x + 85, effect[i].y - 85, effect[i].x +85, effect[i].y + 85, effect[i].x - 85, effect[i].y + 85, 80, 1, 1, 0, 0, 0, -1 );
				}
				DrawRotaGraph( effect[i].x, effect[i].y, 0.6, rad, spslasheff[2], TRUE ) ;
				if( CheckSoundMem( stgsound[0] ) == 1 ){
					StopSoundMem( stgsound[0] );
				}
				PlaySoundMem( stgsound[0], DX_PLAYTYPE_BACK ) ;
			}
			break;
		
		case 11://��؂̃A��
			DrawBox( effect[i].x, effect[i].y, player.x, (player.y-effect[i].y) / 3, color[0] , TRUE);
			effect[i].y -= 25;
			DrawRotaGraph( effect[i].x, effect[i].y, 0.4, 0, spallow[0], TRUE ) ;
			add_effect( effect[i].x, effect[i].y, 13, rand( 0.1 ) );
			if(effect[i].count == 1 ){
				cleate_recarea2( effect[i].x -20, effect[i].y -40, effect[i].x + 20, effect[i].y - 40, effect[i].x + 20, effect[i].y + 40, effect[i].x - 20, effect[i].y + 40, effect[i].rad, 1, 25, 0, 25, 1, -1 );
				DrawRotaGraph( effect[i].x, effect[i].y, 0.6, rad, spslasheff[2], TRUE ) ;
				PlaySoundMem( stgsound[3], DX_PLAYTYPE_BACK ) ;
			}else if( effect[i].count == 5 ){
				PlaySoundMem( stgsound[4], DX_PLAYTYPE_BACK ) ;
			}
			break;

		case 12://�U��G�t�F�N�g
			num = 5 - effect[i].count;
			if( effect[i].count > 4 ) num = 1;
			SetDrawBlendMode( DX_BLENDMODE_ALPHA , 120 - (effect[i].count * 9) );
			switch( num ){
				case 1:
					DrawRotaGraph( effect[i].x+46, effect[i].y, 1, 0, swing[4], TRUE );
				case 2:
					DrawRotaGraph( effect[i].x+23, effect[i].y, 1, 0, swing[3], TRUE );
				case 3:
					DrawRotaGraph( effect[i].x, effect[i].y, 1, 0, swing[2], TRUE );
				case 4:
					DrawRotaGraph( effect[i].x-23, effect[i].y, 1, 0, swing[1], TRUE );
				case 5:
					DrawRotaGraph( effect[i].x-46, effect[i].y, 1, 0, swing[0], TRUE );
			}
			break;

		case 13://���G�t�F�N�g
			SetDrawBlendMode( DX_BLENDMODE_ALPHA , 250 - (effect[i].count * 12) );
			effect[i].x += rad_x( effect[i].rad , 7 );
			effect[i].y += rad_y( effect[i].rad , 7 );
			DrawRotaGraph( effect[i].x, effect[i].y, 0.1, effect[i].count * 0.72, star[1], TRUE ) ;
			break;

		case 14://2�L�����Z�w��]
			if( effect[i].count < 40 ){
				SetDrawBlendMode( DX_BLENDMODE_ALPHA , 250 );
				DrawRotaGraph( effect[i].x, effect[i].y, 0.7, effect[i].count * 0.05, spallow[1], TRUE ) ;
			}else{
				SetDrawBlendMode( DX_BLENDMODE_ALPHA , 250 - 24 *( effect[i].count - 40 ) );
				DrawRotaGraph( effect[i].x, effect[i].y, 0.7, effect[i].count * 0.05, spallow[1], TRUE ) ;
				SetDrawBlendMode( DX_BLENDMODE_ALPHA , 250 - 12 *( effect[i].count - 40 ) );
				DrawRotaGraph( effect[i].x, effect[i].y, 0.07 * ( effect[i].count - 40 ), 0, spallow[1], TRUE ) ;
			}
			break;

		case 15:
			break;

		case 16:
			if( effect[i].lifecount - effect[i].count < 30 ){
				SetDrawBlendMode( DX_BLENDMODE_ALPHA , ( effect[i].lifecount - effect[i].count ) * 9 );
			}
			if( effect[i].rad == player.magicmax ){
				SetDrawBright( 150, 255, 150 );
			}
			rad = effect[i].count * 3;
			if( rad > effect[i].rad ){
				rad = effect[i].rad;
			}
			DrawFormatStringToHandle( effect[i].x -48, effect[i].y + 5, color[0], font[0], "x") ;
			GnumDraw( rad, 3, effect[i].x, effect[i].y, 0 );
			SetDrawBright( 255, 255, 255 );
			break;
	}
	SetDrawBlendMode( DX_BLENDMODE_NOBLEND , 0 );
	if(spd.count == 1 || effect[i].type == 16 ) effect[i].count++;
}

//�G�t�F�N�g�̍폜
void del_effect( int i ){
	if(effect[i].count >= effect[i].lifecount ) effect[i].flg = 0;
}
//�G�t�F�N�g���C��
void effect_main(){
	for( int i = 0; i < EFFECTMAX; i++ ){
		if(effect[i].flg == 1){
			draw_effect( i, effect[i].type );
			del_effect( i );
		}
	}
}

//�o�b�N�{�[�h�G�t�F�N�g�֌W
void backeffect(){

	SetDrawArea( 420, 200, 640, 480);

	for( int i = 0; i < EFFECTMAX; i++ ){
		if( effect[i].flg == 2 ){
			//�X�V�ƕ`��
			effect[i].x += rad_x( effect[i].rad, effect[i].fanc );
			effect[i].y += rad_y( effect[i].rad, effect[i].fanc );
			SetDrawBlendMode( DX_BLENDMODE_ALPHA , 250 );
			DrawRotaGraph( effect[i].x, effect[i].y, 0.2, effect[i].count * 0.13, star[1], TRUE ); 
			SetDrawBlendMode( DX_BLENDMODE_NOBLEND , 0 );
			effect[i].count++;
			//����
			if( effect[i].y > 480 || effect[i].x < 400 ){
				effect[i].flg = 0;
			}
		}
	}
	SetDrawArea( 0, 0, 640, 480);
}

//�w�i�`��X�C�b�`����
void backswitch( int imgnum, int rad, float spd ){
	bg.tspd			= bg.nowspd;
	bg.switchnum	= imgnum;
	bg.rad			= rad;
	bg.tspd			= spd;

	//�w�i���ω�����ꍇ2�b�A���x�̂ݕω�����ꍇ1�b�ŕω�������B
	if( bg.switchnum == bg.num ){
		bg.switchcount = 60;
	}else{
		bg.switchcount = 120;
	}

	//�t���[�����x�ω��ʌv�Z
	if( spd < bg.nowspd ){
		bg.spd = - (bg.nowspd - spd) / (float)bg.switchcount;
	}else if( spd > bg.nowspd ){
		bg.spd = (spd - bg.nowspd) / (float)bg.switchcount;
	}else{
		bg.spd = 0;
	}
}

//�w�i�`��{��
void backdraw(){
	static int alpha = 0;
	static int change = 0;
	static float scr = 0;

	//�ω�����
	if( bg.switchcount != 0 ){

		//�w�i�ω�����ꍇ�Ó]���Đ؂�ւ���
		if( bg.switchcount > 60 ){
			SetDrawBlendMode( DX_BLENDMODE_ALPHA ,  255 * ( alpha / 60.0 ));
			if( alpha > 0 ) alpha--;	
			change = 1;
		}else{
			if( change == 1 ){
				bg.num = bg.switchnum;
				SetDrawBlendMode( DX_BLENDMODE_ALPHA ,  255 * ( alpha / 60.0 ));
				alpha++;
				if( bg.switchcount == 1 ) change = 0;
			}else{
				SetDrawBlendMode( DX_BLENDMODE_ALPHA , 255);
			}
		}
		bg.nowspd += bg.spd;
		bg.switchcount--;
		if( bg.switchcount == 0 ) bg.nowspd = bg.tspd;
	}else{
		SetDrawBlendMode( DX_BLENDMODE_ALPHA , 255);
	}
	scr += bg.nowspd;

	//���[�v�X�N���[������
	if( scr > 800 ){
		scr -= 800;
	}else if( scr < 0 ){
		scr += 800;
	}
	

	//�`�敔
	SetDrawArea( BULLET_MIN_XY , BULLET_MIN_XY , BULLET_MAX_X , BULLET_MAX_Y );
	DrawGraph(BULLET_MIN_XY,scr + BULLET_MIN_XY-797,backimg[bg.num],FALSE);
	DrawGraph(BULLET_MIN_XY,scr + BULLET_MIN_XY    ,backimg[bg.num],FALSE);
	DrawGraph(BULLET_MIN_XY,scr + BULLET_MIN_XY+797,backimg[bg.num],FALSE);
	SetDrawArea( 0, 0, 640, 480);
	SetDrawBlendMode( DX_BLENDMODE_NOBLEND , 0 );
}