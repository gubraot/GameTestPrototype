/*--------------------------------------------/
/�G�e��06                                     /
/Rad�x��spd�e�������A�덷�t�Ŗ߂��Ă���B     /
/���x�ݒ��0.05���ɐݒ肵�Ȃ��ꍇ�s�����   /
/--------------------------------------------*/

#include "dxlib.h"
#include "Extern.h"
#include "mathoperation.h"

void ebulletptn06( int i, int type ){
	switch(type){
		case 0:
			if( ebullet[i].spd < -4.0 ) ebullet[i].spd -= 1.0/20.0;
			if( ebullet[i].spd == -3.0 ) ebullet[i].rad += rand(0.1);
			ebullet[i].x	+= rad_x( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
			ebullet[i].y	+= rad_y( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
			break;

		case 1:
			if( erecbullet[i].spd < -4.0 ) erecbullet[i].spd -= 1.0/20.0;
			if( erecbullet[i].spd == -3.0 ) erecbullet[i].rad += rand(0.1);
			erecbullet[i].x	+= rad_x( erecbullet[i].rad, erecbullet[i].spd * spd.objspeed );
			erecbullet[i].y	+= rad_y( erecbullet[i].rad, erecbullet[i].spd * spd.objspeed );
			break;
	}
}