/*--------------------------------------------/
/1�ʗp�{�X                                    /
/�g�p�ԍ���10-12                              /
/                                             /
/--------------------------------------------*/

#include "dxlib.h"
#include "Extern.h"
#include "mathoperation.h"

//�e��o�^����ׂ̃v���g�^�C�v�錾
void addebullet( float x, float y, int pow, int ptn, float rad, float spd, int img, int size, int id );
void addebullet2( float x, float y, int pow, int ptn, float rad, float spd, int img, float width, float length, int id );

void bossbulletcalc10(){
	static int shotcnt, paturncnt, shotnum;

	if( boss.cnt == 1 ){
		shotcnt = 0;
		paturncnt = 0;
	}

	if( boss.cnt %480 < 120 ){
		if( boss.cnt % 2 && shotcnt < 8 ){
			shotnum = 16 + ( info.dificality * 4 );
			for( int i = 0; i < shotnum; i++ ){
				addebullet2( boss.x, boss.y, 7, 1, i / (shotnum / 2.0) + shotcnt * 0.005 + paturncnt * 0.1, 2 * (info.dificality * 0.2 + 1.0), 42, 1, 3, 400 );
			}
			shotcnt++;
		}else if( boss.cnt % 60 == 59 ){
			shotcnt = 0;
			paturncnt++;
		}
	}else if( boss.cnt % 480 < 360){
		if( boss.cnt % ( 6 - info.dificality ) == 0 ){
			for( int i = 0; i < 4; i++ ){
				addebullet( boss.x, boss.y, 10, 1, (i / 2.0) + (boss.cnt / 120.0), 2.4, 37, 2, 400 );
			}
		}
	}
}

void bossbulletcalc11(){
	static int paturn, start;
	int fix_rad = dis_rad( boss.x, boss.y );
	static float stdshot, wind;
	if( boss.cnt <= 1 ){
		paturn = 0;
		start = 0;
	}

	switch( paturn ){
		case 0:
			if((boss.cnt - start) % (12 - info.dificality * 2) == 0 ){
				for( int j = 0; j < 2; j++){
					stdshot = rand( 0.9 );
					for( int i = 0; i < 7 + (info.dificality * 2); i++ ){ 
						addebullet( boss.x, boss.y, 10, 1, stdshot + i * 0.004, 2.4 * (1 + info.dificality * 0.1), 37, 2, 400 );
					}
				}
			}
			if( boss.cnt - start == 120 ){
				paturn = 3;
			}
			break;

		case 1:
			if((boss.cnt - start) % (90 - info.dificality * 15) == 0 ){
				for( int i = 0; i < 20 + (info.dificality * 10); i++ ){
					addebullet2( boss.x, boss.y, 10, 7, rand( 1.0 ), absrand( info.dificality + 0.7 ), 42 + GetRand( 7 ), 1, 3, 400 );
				}
			}
			if( boss.cnt - start == 240 ){
				paturn = 3;
			}
			break;
		case 2:
			if( (boss.cnt - start) % 120 == 1 ){
				stdshot = dis_rad( boss.x, boss.y );
				wind = 0;
			}
			if((boss.cnt - start) % (6 - info.dificality ) == 0 ){
				for( int i = 0; i < 3; i++ ){
					if( i == 0 ){
						addebullet( boss.x, boss.y, 10, 2, stdshot + rand( 0.015 * info.dificality ), 2.4 * (1 + info.dificality * 0.15), 53, 4, 400 );
					}else if( i % 2 == 1 ){
						addebullet( boss.x, boss.y, 10, 2, stdshot + 0.3 - wind * 0.004, 2.4 * (1 + info.dificality * 0.15), 53, 4, 400 );
					}else{
						addebullet( boss.x, boss.y, 10, 2, stdshot - 0.3 + wind * 0.004, 2.4 * (1 + info.dificality * 0.15), 53, 4, 400 );
					}
				}
				wind++;
			}
			if( boss.cnt - start == 240 ){
				paturn = 3;
			}
			break;

		default:
			if( paturn == 3 ){//�p�^�[���؂�ւ�����
				start = boss.cnt;
				paturn = GetRand( 2 );
			}
	}
}

void bossbulletcalc12(){
	static int shotcnt, shotcnt2;
	static float stdshot, stdshot2;
	if(boss.cnt == 1 ){
		shotcnt = 0;
		shotcnt2= 0;
		stdshot = 0;
		stdshot2= 0.0625;
	}

	if(boss.cnt % 200 < 100){
		if(boss.cnt % ( 6 - info.dificality ) == 0 ){
			for( int i = 0; i < 8; i++){
				addebullet( boss.x, boss.y, 10, 1, stdshot + i / 4.0 + shotcnt / 500.0, 2 + shotcnt / 50.0, 38, 2, 400);
			}
		}
		shotcnt++;
	}else{
		if(boss.cnt % ( 6 - info.dificality ) == 0 ){
			for( int i = 0; i < 8; i++){
				addebullet( boss.x, boss.y, 10, 1, stdshot + i / 4.0 - shotcnt / 500.0, 2 + shotcnt / 50.0, 38, 2, 400);
			}
		}
		shotcnt++;
	}
	if( info.dificality == 3 ){
		if(boss.cnt % 200 < 150 && boss.cnt % 200 >= 50 ){
			if(boss.cnt % ( 6 - info.dificality ) == 0 ){
				for( int i = 0; i < 8; i++){
					addebullet( boss.x, boss.y, 10, 1, stdshot2 + i / 4.0 - shotcnt2 / 500.0, 2 + shotcnt2 / 50.0, 38, 2, 400);
				}
			}
		shotcnt2++;
		}else{
			if(boss.cnt % ( 6 - info.dificality ) == 0 ){
				for( int i = 0; i < 8; i++){
					addebullet( boss.x, boss.y, 10, 1, stdshot2 + i / 4.0 + shotcnt2 / 500.0, 2 + shotcnt2 / 50.0, 38, 2, 400);
				}
			}
		shotcnt2++;
		}
	}
	if( boss.cnt % 100 == 99 ){
		shotcnt = 0;
		stdshot += 0.125;
	}
	if((boss.cnt + 50) % 100 == 99 ){
		shotcnt2 = 0;
		stdshot2 -= 0.125;
	}

}