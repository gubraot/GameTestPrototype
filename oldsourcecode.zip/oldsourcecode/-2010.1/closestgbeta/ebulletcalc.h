/*--------------------------------------------/
/�e���˃p�^�[���w�b�_                         /
/�e�𔭎˂����镨�̂̎������ɕK�v�Ȃ���       /
/                                             /
/--------------------------------------------*/

void enemybulletcalc01 ( int i );
void enemybulletcalc02 ( int i );
void enemybulletcalc03 ( int i );
void enemybulletcalc04 ( int i );
void enemybulletcalc05 ( int i );
void enemybulletcalc06 ( int i );
void enemybulletcalc07 ( int i );
void enemybulletcalc08 ( int i );
void enemybulletcalc10 ( int i );
void enemybulletcalc11 ( int i );
void enemybulletcalc12 ( int i );
void enemybulletcalc13 ( int i );
void enemybulletcalc14 ( int i );
void enemybulletcalc15 ( int i );
void enemybulletcalc16 ( int i );
void enemybulletcalc20 ( int i );
void enemybulletcalc21 ( int i );
void enemybulletcalc22 ( int i );
void enemybulletcalc23 ( int i );
void enemybulletcalc24 ( int i );
void enemybulletcalc25 ( int i );
void enemybulletcalc30 ( int i );
void enemybulletcalc31 ( int i );
void enemybulletcalc32 ( int i );
void enemybulletcalc33 ( int i );
void enemybulletcalc34 ( int i );
void enemybulletcalc35 ( int i );