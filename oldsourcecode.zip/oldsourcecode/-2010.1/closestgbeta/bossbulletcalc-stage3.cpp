/*--------------------------------------------/
/3�ʗp�{�X                                    /
/�g�p�ԍ���30-34                              /
/                                             /
/--------------------------------------------*/

#include "dxlib.h"
#include "Extern.h"
#include "mathoperation.h"
#include <math.h>

//�e��o�^����ׂ̃v���g�^�C�v�錾
void addebullet( float x, float y, int pow, int ptn, float rad, float spd, int img, int size, int id );
void addebullet2( float x, float y, int pow, int ptn, float rad, float spd, int img, float width, float length, int id );
void add_b_enemy( float x, float y, int hp, int ptn, int spd, float rad, int size, int img );

void bossbulletcalc30(){
	static int waitcnt, shotcnt;
	static float shotrad, startrad;

	if( boss.cnt <= 1 ){
		waitcnt = 0;
		startrad = rand(0.05 + info.dificality * 0.02 );
	}

	if( waitcnt == 0 ){
		addebullet( boss.x, boss.y, 10, 26, shotcnt / 60.0, 3 * ( 1 + info.dificality * 0.15 ), 57, 4, 400 );
		shotcnt++;
		addebullet( boss.x, boss.y, 10, 26, shotcnt / 60.0, 3 * ( 1 + info.dificality * 0.15 ), 57, 4, 400 );
		shotcnt++;
		if( shotcnt >= 120 ){
			waitcnt = 35 - info.dificality * 5;
			shotcnt = 0;
			startrad = rand( 0.05 + info.dificality * 0.02 );
		}
	}else{
		waitcnt--;
	}

	if( boss.cnt % ( 60 - info.dificality * 10 ) == 0 ){
		shotrad = dis_rad( boss.x, boss.y );
		addebullet2( boss.x, boss.y, 12, 1, shotrad, 2 + info.dificality * 0.5, 100, 1, 13, 400 );
	}
}

void bossbulletcalc31(){
	static int waitcnt, shotcnt;
	static float shotrad;
	if( boss.cnt <= 1 ){
		waitcnt = 0;
		shotcnt = 0;
		shotrad = dis_rad( boss.x, boss.y );
	}

	if( waitcnt == 0 ){
		addebullet( boss.x, boss.y, 10, 1, shotrad + ( shotcnt - 50 ) / 90.0, ( 1.0 + shotcnt * 0.07 ) * ( 1 + info.dificality * 0.15 ), 92, 2, 400 );
		addebullet( boss.x, boss.y, 10, 1, shotrad + ( shotcnt - 50 ) / 90.0, ( 1.2 + shotcnt * 0.07 ) * ( 1 + info.dificality * 0.15 ), 92, 2, 400 );
		addebullet( boss.x, boss.y, 10, 1, shotrad - ( shotcnt - 50 ) / 90.0, ( 1.0 + shotcnt * 0.07 ) * ( 1 + info.dificality * 0.15 ), 92, 2, 400 );
		addebullet( boss.x, boss.y, 10, 1, shotrad - ( shotcnt - 50 ) / 90.0, ( 1.2 + shotcnt * 0.07 ) * ( 1 + info.dificality * 0.15 ), 92, 2, 400 );
		shotcnt++;
		if( shotcnt >= 70 ){
			waitcnt = 25 - info.dificality * 5;
			shotcnt = 0;
			shotrad = dis_rad( boss.x, boss.y );
		}
	}else{
		waitcnt--;
	}

	if( boss.cnt % ( 40 - info.dificality * 10 ) == 0 ){
		shotrad = dis_rad( boss.x, boss.y );
	}
}

void bossbulletcalc32(){
	static float winder1, winder2, inner;
	static int winderflg1, winderflg2;
	if( boss.cnt <= 1 ){
		winder1 = 0.6;
		winder2 = -0.6;
		winderflg1 = 0;
		winderflg2 = 0;
	}
	
	if( boss.cnt % 2 == 0 ){
		addebullet2( boss.x, boss.y, 12, 1, winder1, 6, 100, 1, 13, 400 );
		addebullet2( boss.x, boss.y, 12, 1, winder2, 6, 100, 1, 13, 400 );

		if( boss.cnt < 210 ){
			winder1 -= 0.00222;
			winder2 += 0.00222;
		}else{
			if( winderflg1 == 0 ){
				winder1 -= 0.00666;
				if( winder1 < 0.05 || GetRand( 99 ) % 6 == 0 ){
					winderflg1 = 1;
				}
			}else{
				winder1 += 0.00666;
				if( winder1 > 0.3 || GetRand( 99 ) % 6 == 0 ){
					winderflg1 = 0;
				}
			}
			
			if( winderflg2 == 0 ){
				winder2 += 0.00666;
				if( winder2 > -0.05 || GetRand( 99 ) % 6 == 0 ){
					winderflg2 = 1;
				}
			}else{
				winder2 -= 0.00666;
				if( winder2 < -0.3 || GetRand( 99 ) % 6 == 0 ){
					winderflg2 = 0;
				}
			}
		}
	}

	if( boss.cnt % (30 - info.dificality * 4 ) == 0 ){
		inner = 0.6 + rand( 0.1 );
		while( 1 ){
			if( inner < winder1 ){
				addebullet( boss.x, boss.y, 10, 1, inner, 2 * ( 0.8 + info.dificality * 0.2 ), 37, 2, 400 );
			}
			inner -= 0.1 * ( 1 - info.dificality * 0.2 );
			if( inner < winder2 ){
				break;
			}
		}
	}
}

void bossbulletcalc33(){
	static int waitcnt, ptn, shotcnt, shotnum;
	static float shotrad;
	if( boss.cnt <= 1 ){
		waitcnt = 20;
		ptn = 0;
		shotcnt = 0;
		shotnum = 20 + info.dificality * 4;
	}
	if( waitcnt > 0 ){
		waitcnt--;
	}else if( ptn == 0 ){
		if( boss.cnt % ( 30 - info.dificality * 5 ) == 0 ){
			if( shotcnt % 2 == 0 ){
				for( int i = 0; i < shotnum; i++ ){
					addebullet( boss.x, boss.y, 10, 27, ( shotcnt / 20.0 ) + ( i / ( shotnum / 2.0 )), 2.2, 76, 2.3, 400 );
				}
				shotcnt++;
			}else{
				for( int i = 0; i < shotnum; i++ ){
					addebullet( boss.x, boss.y, 10, 28, ( shotcnt / 20.0 ) + ( i / ( shotnum / 2.0 )), 2.2, 76, 2.3, 400 );
				}
				shotcnt++;
			}
			if( shotcnt == 10 ){
				ptn++;
				shotcnt = 0;
				waitcnt = 30 - info.dificality * 5;
			}
		}
	}else if( ptn == 1 ){
		if( boss.cnt % ( 30 - info.dificality * 5 ) == 0 ){
			shotrad = dis_rad( boss.x, boss.y );
			addebullet( boss.x, boss.y, 10, 29, shotrad, 4 + info.dificality, 76, 2.3, 400 );
			shotcnt++;
			
			if( shotcnt == 6 + info.dificality ){
				ptn++;
				shotcnt = 0;
				waitcnt = 30 - info.dificality * 5;
			}
		}
	}else if( ptn == 2 ){
		if( boss.cnt % ( 10 - info.dificality ) == 0 ){
			shotrad = dis_rad( boss.x, boss.y );
			for( int i = 0; i < 6 + info.dificality * 2; i++ ){
				add_b_enemy( boss.x, boss.y, 1, 1, 1.5 * ( 1 + info.dificality * 1.15 ), ( i - ( 6 + info.dificality ) / 2.0 ) / 20.0, 6, 58 );
			}
			shotcnt++;

			if( shotcnt == 20 ){
				shotcnt = 0;
				waitcnt = 30 - info.dificality * 5;
				ptn = 0;
			}
		}
	}
}

void bossbulletcalc34(){
	static int shotcnt, shotnum, shotmax, laps;
	static float fix_x, fix_y, shotrad;
	if( boss.cnt <= 1 ){
		shotcnt = 0;
		shotnum = 1 + info.dificality;
		shotmax = 6 + info.dificality * 2;
		shotrad = 0;
		laps = 1;
	}
	
	for( int i = 0; i < shotnum; i++ ){
		fix_x = rad_x( shotrad, laps * 10 );
		fix_y = rad_y( shotrad, laps * 10 );

		addebullet2( BULLET_MAX_X / 2 + fix_x, BULLET_MAX_Y / 2 + fix_y, 10, 25, shotrad - 1.0, 0, 94, 2, 2, 400 );

		shotrad += 2 / (float) shotmax + rand( 0.002 );

		if( shotrad > 2 ){
			shotrad -= 2;
			laps++;
			if( laps == 25 ){
				laps = 1;
				shotmax = 7 + info.dificality * 2;
			}
			shotmax += 3;
		}
	}
}