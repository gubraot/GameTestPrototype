/*--------------------------------------------/
/1�{�X�p�^�[��1                               /
/���ˊp�񂵂Ȃ������]�e�����݂ɔ���         /
/                                             /
/--------------------------------------------*/

#include "dxlib.h"
#include "Extern.h"
#include "mathoperation.h"

#define BC03_NUM 16

//�e��o�^����ׂ̃v���g�^�C�v�錾
void addebullet( float x, float y, int pow, int ptn, float rad, float spd, int img, int size, int id );

void bossbulletcalc01(){
	static float fix_rad, addrad;
	if( boss.cnt > 30 ){
		if( boss.cnt %22 == 11 ){
			addrad = rand05();
			for( int k = 0; k < BC03_NUM; k++ ){
				fix_rad = (float) (k * 2) / BC03_NUM;
				addebullet( boss.x +3, boss.y +3, 10, 4, fix_rad+addrad, 2.4, 22, 2, 400 );
			}
		}
		if( boss.cnt %22 == 0 ){
			addrad = rand05();
			for( int k = 0; k < BC03_NUM; k++ ){
				fix_rad = (float) (k * 2) / BC03_NUM;
				addebullet( boss.x +3, boss.y +3, 10, 5, fix_rad+addrad, 2.4, 22, 2, 400 );
			}
		}
	}
}