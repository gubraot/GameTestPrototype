/*--------------------------------------------/
/��`�t�@�C���I�[�v��                         /
/�X�e�[�W�\������ʃt�@�C���ɒ�`�������̂�   /
/�ǂݍ��ވׂ̊֐��܂Ƃ�                       /
/--------------------------------------------*/

#include "dxlib.h"
#include "Extern.h"
#include <stdlib.h>
#include <stdio.h>

//�X�e�[�W�G���f�[�^�ǂݍ���
void loadstagedata( int filepass ){
	int		element = 0;
	int		enemynum= 0;
	char	loadenemy[100]; //���̕ϐ���1�������ǂݍ���
	while( 1 ){
		for( int i = 0; i < 100; i++){
			loadenemy[i] = FileRead_getc( filepass );
			if( loadenemy[i] == ',' ){
				loadenemy[i] = '\0';
				element++;
				break;
			}
			if( loadenemy[i] == '\n' ){
				loadenemy[i] = '\0';
				element++;
				break;
			}
			if( FileRead_eof( filepass ) != 0 ){
				goto EXIT;
			}
		}
		switch( element ){
			case 1:
				enemy[enemynum].addtime = atoi( loadenemy );
				break;
			case 2:
				enemy[enemynum].x = atof( loadenemy );
				break;
			case 3:
				enemy[enemynum].y = atof( loadenemy );
				break;
			case 4:
				enemy[enemynum].angle = atof( loadenemy );
				break;
			case 5:
				enemy[enemynum].hp = atoi( loadenemy );
				break;
			case 6:
				enemy[enemynum].spd = atof( loadenemy );
				break;
			case 7:
				enemy[enemynum].moveptn = atoi( loadenemy );
				break;
			case 8:
				enemy[enemynum].movecng = atoi( loadenemy );
				break;
			case 9:
				enemy[enemynum].movecng2 = atoi( loadenemy );
				break;
			case 10:
				enemy[enemynum].shotptn = atoi( loadenemy );
				break;
			case 11:
				enemy[enemynum].flg = atoi( loadenemy );
				break;
			case 12:
				enemy[enemynum].item[0] = atoi( loadenemy );
				break;
			case 13:
				enemy[enemynum].item[1] = atoi( loadenemy );
				break;
			case 14:
				enemy[enemynum].item[2] = atoi( loadenemy );
				break;
			case 15:
				enemy[enemynum].item[3] = atoi( loadenemy );
				element = 0;
				enemynum++;
				break;
		}
	}
EXIT:
	FileRead_close( filepass );
}

//�{�X�̃f�[�^�ǂݍ���
void loadstageinfo( int filepass, int bossnum ){
	int		element = 0;
	int		section = 0;
	char	loadcalc[100]; //���̕ϐ���1�������ǂݍ���
	while( 1 ){
		for( int i = 0; i < 100; i++){
			loadcalc[i] = FileRead_getc( filepass );
			if( loadcalc[i] == ',' ){
				loadcalc[i] = '\0';
				element++;
				break;
			}
			if( loadcalc[i] == '\n' ){
				loadcalc[i] = '\0';
				element++;
				break;
			}
			if( FileRead_eof( filepass ) != 0 ){
				goto EXIT;
			}
		}
		switch( element ){
			case 1:
				enemynum[bossnum][section].hp = atoi( loadcalc );
				break;
			case 2:
				enemynum[bossnum][section].ptn = atoi( loadcalc );
				break;
			case 3:
				enemynum[bossnum][section].endtime = atoi( loadcalc );
				break;
			case 4:
				enemynum[bossnum][section].clrefect = atoi( loadcalc );
				break;
			case 5:
				enemynum[bossnum][section].item[0] = atoi( loadcalc );
				break;
			case 6:
				enemynum[bossnum][section].item[1] = atoi( loadcalc );
				break;
			case 7:
				enemynum[bossnum][section].item[2] = atoi( loadcalc );
				break;
			case 8:
				enemynum[bossnum][section].item[3] = atoi( loadcalc );
				break;
			case 9:
				enemynum[bossnum][section].clearbonus = atoi( loadcalc );
				element = 0;
				section++;
				break;
		}
	}
EXIT:
	FileRead_close( filepass );
}

//�X�e�[�W�ŗL�f�[�^�ǂݍ���
void loadstageconf( int filepass, int stage ){
	int		element = 0;
	int		num = 0;
	char	loadconf[40]; //���̕ϐ���1�������ǂݍ���
	while( 1 ){
		for( int i = 0; i < 100; i++){
			loadconf[i] = FileRead_getc( filepass );
			if( loadconf[i] == ',' ){
				loadconf[i] = '\0';
				element++;
				break;
			}
			if( loadconf[i] == '\n' ){
				loadconf[i] = '\0';
				element++;
				break;
			}
			if( FileRead_eof( filepass ) != 0 ){
				goto EXIT;
			}
		}
		switch( element ){
			case 1:
				stage_data[num][stage].time = atoi( loadconf );
				break;
			case 2:
				stage_data[num][stage].effect = atoi( loadconf );
				break;
			case 3:
				stage_data[num][stage].conf1 = atof( loadconf );
				break;
			case 4:
				stage_data[num][stage].conf2 = atof( loadconf );
				break;
			case 5:
				stage_data[num][stage].conf3 = atof( loadconf );
				break;
			case 6:
				stage_data[num][stage].conf4 = atof( loadconf );

				element = 0;
				num++;
				break;
		}
	}
EXIT:
	FileRead_close( filepass );
}

//�S�̃n�C�X�R�A�Ǎ�
void loadtotalrecord(){
	int		element = 0;
	int		num = 0;
	char	load[100]; //���̕ϐ���1�������ǂݍ���
	
	int filepass = FileRead_open( "data/thiscore.csv" );

	//File�����݂��Ȃ��ꍇ
	if( filepass == 0 ){
		//thiscore.csv�̐V�K�쐬
		for(int i = 0; i < 10; i++ ){
			for(int j = 0; j < 9; j++ ){
				record.totalinfo[i][j] = 0;
			}
			record.totalhiscore[i] = 0;
		}
		
		FILE *createfile = fopen("data/thiscore.csv","w+");
		for(int i = 0; i < 10; i++ ){
			for(int j = 0; j < 10; j++ ){
				if( j == 0 ){
					fprintf( createfile, "%d", record.totalhiscore[i]);
				}else{
					fprintf( createfile, "%d", record.totalinfo[i][j - 1]);
				}
				if( j != 9 ){
					fprintf( createfile, ",");
				}else{
					fprintf( createfile, "\n");
					if( i == 9 ){
						fclose( createfile );
						goto EXIT;
					}
				}
			}
		}

	}

	while( 1 ){
		for( int i = 0; i < 100; i++){
			load[i] = FileRead_getc( filepass );
			if( load[i] == ',' ){
				load[i] = '\0';
				element++;
				break;
			}
			if( load[i] == '\n' ){
				load[i] = '\0';
				element++;
				break;
			}
			if( FileRead_eof( filepass ) != 0 ){
				goto EXIT;
			}
		}
		switch( element - 1){
			case 0:
				record.totalhiscore[num] = atoi( load );
				break;

			case 1:
				record.totalinfo[num][0] = atoi( load );
				break;

			case 2:
				record.totalinfo[num][1] = atoi( load );
				break;
				
			case 3:
				record.totalinfo[num][2] = atoi( load );
				break;

			case 4:
				record.totalinfo[num][3] = atoi( load );
				break;

			case 5:
				record.totalinfo[num][4] = atoi( load );
				break;

			case 6:
				record.totalinfo[num][5] = atoi( load );
				break;

			case 7:
				record.totalinfo[num][6] = atoi( load );
				break;

			case 8:
				record.totalinfo[num][7] = atoi( load );
				break;

			case 9:
				record.totalinfo[num][8] = atoi( load );
				num++;
				element = 0;
				break;
		}
	}
EXIT:
	if( filepass != 0 ){
		FileRead_close( filepass );
	}
}

//�X�e�[�W�n�C�X�R�A�Ǎ�
void loadstagerecord(){
	int		element = 0;
	int		stage = 0;
	char	load[100]; //���̕ϐ���1�������ǂݍ���
	
	int filepass = FileRead_open( "data/shiscore.csv" );

	//File�����݂��Ȃ��ꍇ
	if( filepass == 0 ){
		//shiscore.csv�̐V�K�쐬
		for(int i = 0; i < STAGE_NUM; i++){
			for(int j = 0; j < 10; j++){
				record.stagehiscore[i][j] = 0;
				record.stagesp_score[i][j] = 0;
			}
		}
		
		FILE *createfile = fopen("data/shiscore.csv","w+");

		for( int i = 0; i < STAGE_NUM; i++ ){
			for( int k = 0; k < 2; k++ ){
				for( int j = 0; j < 10; j++ ){
					if( k == 0 ){
						fprintf( createfile, "%d", record.stagehiscore[i][j] );
						if( j < 9 ){
							fprintf( createfile, ",");
						}else{
							fprintf( createfile, "\n");
						}
					}else{
						fprintf( createfile, "%d", record.stagesp_score[i][j] );
						if( j < 9 ){
							fprintf( createfile, ",");
						}else{
							if( i - 1 != STAGE_NUM ){
								fprintf( createfile, "\n");
							}else{
								fclose( createfile );
								goto EXIT;
							}
						}
					}
				}
			}
		}

	}


	while( 1 ){
		for( int i = 0; i < 100; i++){
			load[i] = FileRead_getc( filepass );
			if( load[i] == ',' ){
				load[i] = '\0';
				element++;
				break;
			}
			if( load[i] == '\n' ){
				load[i] = '\0';
				element++;
				break;
			}
			if( FileRead_eof( filepass ) != 0 ){
				goto EXIT;
			}
		}
		if((element - 1) < 10){
			record.stagehiscore[stage][element - 1] = atoi( load );
		}else if((element - 1) < 19){
			record.stagesp_score[stage][element - 11] = atoi( load );
		}else{
			element = 0;
			stage++;
			if (stage == STAGE_NUM ) goto EXIT;
		}
	}
EXIT:
	if( filepass != 0 ){
		FileRead_close( filepass );
	}
}

//�ݒ�f�[�^�ǂݍ���
void loadconfig(){
	int		element = 0;
	char	load[100]; //���̕ϐ���1�������ǂݍ���
	
	int filepass = FileRead_open( "data/config.csv" );

	//File�����݂��Ȃ��ꍇ
	if( filepass == 0 ){
		for( int i = 0; i < 6; i++ ){
			if( i < 2){
				record.config[i] = 20;
			}else{
				record.config[i] = 1;
			}
		}
		
		//�V�K�쐬
		FILE *createfile = fopen("data/config.csv","w+");

		for( int i = 0; i < 6; i++ ){
			fprintf( createfile, "%d", record.config[i] );

			if( i == 5 ){
				fclose( createfile );
				goto EXIT;
			}else{
				fprintf( createfile, ",");
			}
		}
	}

	while( 1 ){
		for( int i = 0; i < 100; i++){
			load[i] = FileRead_getc( filepass );
			if( load[i] == ',' ){
				load[i] = '\0';
				element++;
				break;
			}
			if( load[i] == '\n' ){
				load[i] = '\0';
				element++;
				break;
			}
			if( FileRead_eof( filepass ) != 0 ){
				goto EXIT;
			}
		}

		record.config[element - 1] = atoi( load );
		if( element == 6 ) goto EXIT;
	}


EXIT:
	if( filepass != 0 ){
		FileRead_close( filepass );
	}
}