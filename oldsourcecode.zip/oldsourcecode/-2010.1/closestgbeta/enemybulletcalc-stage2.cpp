/*--------------------------------------------/
/�G�@�V���b�g�p�^�[��2�ʂ܂Ƃ�                /
/�g�p�ԍ�20-25                                /
/                                             /
/--------------------------------------------*/

#include "dxlib.h"
#include "Extern.h"
#include "mathoperation.h"

//�e��o�^����ׂ̃v���g�^�C�v�錾
void addebullet( float x, float y, int pow, int ptn, float rad, float spd, int img, int size, int id );
void addebullet2( float x, float y, int pow, int ptn, float rad, float spd, int img, float width, float length, int id );

void enemybulletcalc20( int i ){
	if( enemy[i].time <= 1 ){
		enemy[i].shotrad = dis_rad( enemy[i].x, enemy[i].y );
	}
	
	if( enemy[i].time % (10 - info.dificality * 2) == 0 && enemy[i].shotcnt <= 20){
		addebullet( enemy[i].x, enemy[i].y, 6, 6, enemy[i].shotrad - (10 - enemy[i].shotcnt) / 45.0, 2, 66, 2, i );
		addebullet( enemy[i].x, enemy[i].y, 6, 6, enemy[i].shotrad + (10 - enemy[i].shotcnt) / 45.0, 2, 66, 2, i );
		enemy[i].shotcnt++;
	}
	if( enemy[i].time % (5 - info.dificality) == 0 && enemy[i].shotcnt > 20 && enemy[i].shotcnt <= 100 ){
		addebullet( enemy[i].x, enemy[i].y, 6, 1, 1 - (enemy[i].shotcnt - 20) / 38.0, 2 + (info.dificality * 0.7), 39, 2, i );
		addebullet( enemy[i].x, enemy[i].y, 6, 1, 1 + (enemy[i].shotcnt - 20) / 38.0, 2 + (info.dificality * 0.7), 39, 2, i );
		enemy[i].shotcnt++;
	}
}

void enemybulletcalc21( int i ){
	enemy[i].shotrad = dis_rad( enemy[i].x, enemy[i].y );
	if( enemy[i].time % ( 40 - info.dificality * 5 ) == 0 && enemy[i].shotcnt < 6 + info.dificality * 2 ){
		addebullet2( enemy[i].x, enemy[i].y, 8, 1, enemy[i].shotrad + 0.07, 2 + info.dificality * 0.7, 84, 2, 6, i );
		addebullet2( enemy[i].x, enemy[i].y, 8, 1, enemy[i].shotrad, 2 + info.dificality * 0.7, 84, 2, 6, i );
		addebullet2( enemy[i].x, enemy[i].y, 8, 1, enemy[i].shotrad - 0.07, 2 + info.dificality * 0.7, 84, 2, 6, i );
		enemy[i].shotcnt++;
	}
}

void enemybulletcalc22( int i ){
	int shotnum = 20 + info.dificality * 5;
	enemy[i].shotrad = dis_rad( enemy[i].x, enemy[i].y );
	if( enemy[i].time == 100 - info.dificality * 20 ){
		for( int j = 0; j < shotnum; j++ ){
			addebullet( enemy[i].x, enemy[i].y, 7, 1, enemy[i].shotrad + 2 * j / (float)shotnum , 1.5 * (0.8 + info.dificality * 0.2), 0, 3, i );
			addebullet( enemy[i].x, enemy[i].y, 7, 1, enemy[i].shotrad + 2 * j / (float)shotnum , 2 * (0.8 + info.dificality * 0.2), 0, 3, i );
		}
	}
}

void enemybulletcalc23( int i ){
	int shotnum = 2 + info.dificality;
	static int waitcnt;
	if( enemy[i].time == 1 || enemy[i].shotcnt == 2 + info.dificality ){
		enemy[i].shotrad = dis_rad( enemy[i].x, enemy[i].y );
	}
	if( enemy[i].shotcnt < 2 + info.dificality ){
		if( enemy[i].time % ( 90 - info.dificality * 20 ) < 80 - info.dificality * 20 ){
			if( enemy[i].time % (4 - info.dificality) == 0 ){
				for( int k = 0; k < 6; k++ ){
					addebullet( enemy[i].x, enemy[i].y, 8, 1, enemy[i].shotrad + ( k / 3.0 ), 1 + info.dificality * 0.2, 40, 2, i );
				}
				if( enemy[i].shotcnt % 2 == 1 ){
					enemy[i].shotrad += 0.006;
				}else{
					enemy[i].shotrad -= 0.006;
				}
			}
		}
		if( enemy[i].time % ( 90 - info.dificality * 20 ) == 89 - info.dificality * 20 ){
			enemy[i].shotcnt++;
			enemy[i].shotrad += 0.2;
			waitcnt = 120;
		}
	}else{
		if( enemy[i].time % 5 - info.dificality == 0 && waitcnt == 0 ){
			for( int j = 0; j < shotnum; j++ ){
				addebullet2( enemy[i].x + 20, enemy[i].y, 8, 1, enemy[i].shotrad - (0.07 - info.dificality * 0.01) * j, 1.5 + info.dificality * 0.3, 70, 1, 3, i );
				addebullet2( enemy[i].x - 20, enemy[i].y, 8, 1, enemy[i].shotrad + (0.07 - info.dificality * 0.01) * j, 1.5 + info.dificality * 0.3, 70, 1, 3, i );	
			}
			enemy[i].shotcnt++;
			enemy[i].shotrad += rand( 0.005 );
		}else if( waitcnt > 0 ){
			waitcnt--;
		}
	}
}

void enemybulletcalc24( int i ){
	static float moverad;

	if( enemy[i].time <= 1 ){
		moverad = 0.0;
		enemy[i].shotrad = dis_rad( enemy[i].x, enemy[i].y );
	}

	if( enemy[i].time % ( 4 / ( info.dificality + 1 )) == 0 && enemy[i].shotcnt < 60 + info.dificality * 15 ){
		enemy[i].shotrad += moverad;
		for( int j = 0; j < 2; j++ ){
			addebullet2( enemy[i].x, enemy[i].y, 7, 2, j + enemy[i].shotrad, ( 1 + enemy[i].shotcnt * 0.03 ) * ( 1 + info.dificality * 0.15 ), 49, 1, 3, i );
		}
		enemy[i].shotcnt++;
		moverad += 0.001 * (4 - info.dificality );
	}
}

void enemybulletcalc25( int i ){

	if( enemy[i].time <= 1 ){
		enemy[i].shotrad = dis_rad( enemy[i].x, enemy[i].y );
	}

	if( enemy[i].time == 70 - info.dificality * 15 ){
		for( int j = 0; j < 5; j++ ){
			addebullet( enemy[i].x, enemy[i].y, 7, 2, enemy[i].shotrad + ( 0.24 - j * 0.12 ), 2 * ( 0.8 + info.dificality * 0.2 ), 50, 4, i );
		}
	}
}
