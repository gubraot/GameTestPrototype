/*--------------------------------------------/
/5�ʗp�{�X                                    /
/�g�p�ԍ���60-6x                              /
/                                             /
/--------------------------------------------*/

#include "dxlib.h"
#include "Extern.h"
#include "mathoperation.h"
#include <math.h>

//�e��o�^����ׂ̃v���g�^�C�v�錾
void addebullet( float x, float y, int pow, int ptn, float rad, float spd, int img, int size, int id );
void addebullet2( float x, float y, int pow, int ptn, float rad, float spd, int img, float width, float length, int id );
void add_b_enemy( float x, float y, int hp, int ptn, int spd, float rad, int size, int img );

void bossbulletcalc60(){
	static int shotcnt, paturncnt, shotnum;

	if( boss.cnt == 1 ){
		shotcnt = 0;
		paturncnt = 0;
	}

	if( boss.cnt % 480 < 120 ){
		if( boss.cnt % 2 && shotcnt < 12 ){
			shotnum = 16 + ( info.dificality * 4 );
			for( int i = 0; i < shotnum; i++ ){
				addebullet2( boss.x, boss.y, 7, 1, i / (shotnum / 2.0) + shotcnt * 0.005 + paturncnt * 0.1, ( 2 + shotcnt * 0.2 ) * (info.dificality * 0.2 + 1.0), 42, 1, 3, 400 );
			}
			shotcnt++;
		}else if( boss.cnt % 60 == 59 ){
			shotcnt = 0;
			paturncnt++;
		}
	}else if( boss.cnt % 480 < 360){
		if( boss.cnt % ( 6 - info.dificality ) == 0 ){
			for( int i = 0; i < 8; i++ ){
				addebullet( boss.x, boss.y, 10, 1, (i / 4.0) + (boss.cnt / 180.0), 3, 37, 2, 400 );
				addebullet( boss.x, boss.y, 10, 1, (i / 4.0) - (boss.cnt / 180.0), 3, 37, 2, 400 );
			}
		}
	}
}

void bossbulletcalc61(){
	static int shotcnt;

	if( boss.cnt <= 1 ){
		shotcnt = 0;
	}

	float randam = rand( 0.4 );


	if( boss.cnt % ( 5 - info.dificality ) == 0 ){
		addebullet2( boss.x, boss.y, 10, 8, 1 + randam, 1.7, 70, 1, 2, 400 );
		addebullet2( boss.x, boss.y, 10, 8, 1 + randam, 1.74, 70, 1, 2, 400 );
		addebullet2( boss.x, boss.y, 10, 8, 1 + randam, 1.78, 70, 1, 2, 400 );
		addebullet2( boss.x, boss.y, 10, 8, 1 + randam, 1.82, 70, 1, 2, 400 );
	}
}

void bossbulletcalc62(){
	static int waitcnt, shotcnt;
	static float shotrad;
	if( boss.cnt <= 1 ){
		waitcnt = 0;
		shotcnt = 0;
		shotrad = dis_rad( boss.x, boss.y );
	}

	if( waitcnt == 0 ){
		addebullet( boss.x, boss.y, 10, 1, shotrad + ( shotcnt - 50 ) / 90.0, ( 1.0 + shotcnt * 0.07 ) * ( 1 + info.dificality * 0.15 ), 92, 2, 400 );
		addebullet( boss.x, boss.y, 10, 1, shotrad + ( shotcnt - 50 ) / 90.0, ( 1.2 + shotcnt * 0.07 ) * ( 1 + info.dificality * 0.15 ), 92, 2, 400 );
		addebullet( boss.x, boss.y, 10, 1, shotrad - ( shotcnt - 50 ) / 90.0, ( 1.0 + shotcnt * 0.07 ) * ( 1 + info.dificality * 0.15 ), 92, 2, 400 );
		addebullet( boss.x, boss.y, 10, 1, shotrad - ( shotcnt - 50 ) / 90.0, ( 1.2 + shotcnt * 0.07 ) * ( 1 + info.dificality * 0.15 ), 92, 2, 400 );
		shotcnt++;
		if( shotcnt >= 70 ){
			waitcnt = 0;
			shotcnt = 0;
			shotrad = dis_rad( boss.x, boss.y );
		}
	}else{
		waitcnt--;
	}

	if( boss.cnt % ( 40 - info.dificality * 10 ) == 0 ){
		shotrad = dis_rad( boss.x, boss.y );
	}
}

void bossbulletcalc63(){
	static int startshot, shotcnt;
	static float angle;
	if( boss.cnt <= 1 ){
		shotcnt = 0;
		angle = rand( 0.02 );
	}

	if( boss.cnt % ( 16 - info.dificality * 4 ) == 0 ){
		startshot = GetRand( 400 );
		angle = rand( 0.02 );
		for( int i = 0; i < 4; i++ ){
			addebullet( startshot + 4 * i, 0, 10, 1, angle, 2 * ( 1 + info.dificality * 0.15 ) + i / 8.0, 92, 2, 400 );
		}
		if( shotcnt % 4 == 0 ){
			startshot = GetRand( 400 );
			angle = rand( 0.02 );
			for( int i = 0; i < 4; i++ ){
				addebullet( startshot - 4 * i, 0, 10, 1, angle, 2 * ( 1 + info.dificality * 0.15 ) + i / 8.0, 92, 2, 400 );
			}
		}
	}
}

void bossbulletcalc64(){
	static int shotcnt;
	if( boss.cnt <= 1 ){
		shotcnt = 0;
	}

	if( boss.cnt % ( 4 - info.dificality ) == 0 ){
		if( shotcnt % 120 < 60 ){
			addebullet2( boss.x, boss.y, 10, 23, rand( 1.0 ), 5, 42 + GetRand( 7 ), 1, 2, 400 );
			addebullet2( boss.x, boss.y, 10, 23, rand( 1.0 ), 5, 42 + GetRand( 7 ), 1, 2, 400 );
		}else{
			addebullet2( boss.x, boss.y, 10, 6, 1 - rand( 0.15 ), 2.4, 66 + GetRand( 9 ), 1, 1.5, 400 );
			addebullet2( boss.x, boss.y, 10, 6, 1 - rand( 0.15 ), 2.4, 66 + GetRand( 9 ), 1, 1.5, 400 );
		}
		shotcnt++;
	}
}

void bossbulletcalc65(){
	static float shotrad[3];
	if(boss.cnt <= 1 ){
		for( int i = 0; i < 3; i++ ){
			shotrad[i] = rand( 1.0 );
		}
	}

	if( boss.cnt % 12 - ( info.dificality * 2 ) == 0 ){
		for( int i = 0; i < 3; i++ ){
			for( int j = 0; j < 8; j++ ){
				if( i == 0 ){
					addebullet( boss.x, boss.y, 10, 1, shotrad[0] + j / 4.0, 3 * ( 1 + info.dificality * 0.1 ), 37, 2, 400 );
					addebullet( boss.x, boss.y, 10, 1, shotrad[0] + j / 4.0, 3 * ( 1 + info.dificality * 0.1 ) + 0.4, 37, 2, 400 );
					addebullet( boss.x, boss.y, 10, 1, shotrad[0] + j / 4.0, 3 * ( 1 + info.dificality * 0.1 ) + 0.8, 37, 2, 400 );
				}else if( i == 1 ){
					addebullet( boss.x, boss.y, 10, 1, shotrad[1] + j / 4.0, 2.4 * ( 1 + info.dificality * 0.1 ), 50, 4, 400 );
					addebullet( boss.x, boss.y, 10, 1, shotrad[1] + j / 4.0, 2.4 * ( 1 + info.dificality * 0.1 ) + 0.4, 50, 4, 400 );
					addebullet( boss.x, boss.y, 10, 1, shotrad[1] + j / 4.0, 2.4 * ( 1 + info.dificality * 0.1 ) + 0.8, 50, 4, 400 );
				}else if( i == 2 ){
					addebullet( boss.x, boss.y, 10, 1, shotrad[2] + j / 4.0, 1.9 * ( 1 + info.dificality * 0.1 ), 1, 5, 400 );
					addebullet( boss.x, boss.y, 10, 1, shotrad[2] + j / 4.0, 1.9 * ( 1 + info.dificality * 0.1 ) + 0.4, 1, 5, 400 );
					addebullet( boss.x, boss.y, 10, 1, shotrad[2] + j / 4.0, 1.9 * ( 1 + info.dificality * 0.1 ) + 0.8, 1, 5, 400 );
				}
			}
			
		}
		shotrad[0] += 1 / 33.0;
		shotrad[1] += 1 / 42.0;
		shotrad[2] += 1 / 51.0;
	}
}

//�炷�ڂ�
void bossbulletcalc66(){
	static float startrad, addspeed;
	static int shotnum;

	if( boss.cnt <= 1 ){
		startrad = 0;
		shotnum = 120 + info.dificality * 40;
	}

	if( boss.cnt % ( 60 - info.dificality * 10 ) == 0 ){
		startrad = rand( 1.0 );
		for( int i = 0; i < ( shotnum / 8 ); i++){
			for( int j = 0; j < 8; j++ ){
				addebullet2( boss.x, boss.y, 10, 1, ( i / ( shotnum / 2.0 )) + ( j / 4.0 ) + startrad,( 1 + info.dificality * 0.3 ) + addspeed, 73, 1.5, 2.5, 400 );
			}
			if( i < ( shotnum / 16.0 ) ){
				addspeed += 0.07;
			}else{
				addspeed -= 0.07;
			}
		}
	}
}

void bossbulletcalc67(){
	static int shotnum;
	if( boss.cnt <= 1 ){
		shotnum = 80 + info.dificality * 30;
	}

	if( boss.cnt % ( 360 - info.dificality * 40 ) == 0 ){
		for( int i = 0; i < shotnum; i++ ){
			addebullet( 20 + GetRand( 400 ), 480, 10, 7, 1 + rand( 0.15 ), 0.5 + rand( 1.0 ), 52, 4, 400 );
		}
	}else if( boss.cnt % ( 360 - info.dificality * 40 ) == 60 ){
		for( int i = 0; i < shotnum; i++ ){
			addebullet( 20 + GetRand( 400 ), 480, 10, 7, 1 + rand( 0.15 ), 4 + rand( 1.0 ), 52, 4, 400 );
		}
	}
}