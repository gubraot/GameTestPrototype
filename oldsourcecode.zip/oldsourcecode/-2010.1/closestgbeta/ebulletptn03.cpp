/*--------------------------------------------/
/�G�e��03                                     /
/Add���ɋL�^���ꂽ�p�x���O�������@�_���e      /
/���̃p�^�[���͑��p�^�[���ւ̕ғ���           /
/--------------------------------------------*/

#include "dxlib.h"
#include "Extern.h"
#include "mathoperation.h"

void ebulletptn03( int i, int type ){
	switch(type){
		case 0:
			if( ebullet[i].time == 0){
				ebullet[i].rad = ebullet[i].rad + dis_rad( ebullet[i].x, ebullet[i].y );
			}
			ebullet[i].x	+= rad_x( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
			ebullet[i].y	+= rad_y( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
			break;

		case 1:
			if( erecbullet[i].time == 0){
				erecbullet[i].rad = erecbullet[i].rad + dis_rad( erecbullet[i].x, erecbullet[i].y );
			}
			erecbullet[i].x	+= rad_x( erecbullet[i].rad, erecbullet[i].spd * spd.objspeed );
			erecbullet[i].y	+= rad_y( erecbullet[i].rad, erecbullet[i].spd * spd.objspeed );
			break;
	}
}