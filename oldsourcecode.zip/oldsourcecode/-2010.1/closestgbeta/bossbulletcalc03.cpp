/*--------------------------------------------/
/1�{�X�p�^�[��3                               /
/                                             /
/                                             /
/--------------------------------------------*/

#include "dxlib.h"
#include "Extern.h"
#include "mathoperation.h"

#define BC03_NUM 16

//�e��o�^����ׂ̃v���g�^�C�v�錾
void addebullet( float x, float y, int pow, int ptn, float rad, float spd, int img, int size, int id );

void bossbulletcalc03(){
	static int	change = 0,
				shotcnt = 0,
				wait = 0;
	static float fix_rad = - 2.0 / 12.0,
				  fix_rad2 = 0.0;

	fix_rad2 = dis_rad( boss.x, boss.y );

	if( change == 0 && wait == 0 ){
		if( boss.cnt > 1 && boss.cnt %6 == 0 ){
			for( int i = 0; i < 5; i++ ){
				addebullet( boss.x +3, boss.y +3, 10, 1,(float)i / 12.0 + fix_rad, 3.5, 9, 3, 400 );
			}
			fix_rad += 1.0 / 90.0;
			shotcnt++;
			if( shotcnt >= 10 ){
				shotcnt = 0;
				change++;
				wait = 20;
				fix_rad = 0;
			}
		}
	}
	if( change == 1 && wait == 0 ){
		if( boss.cnt > 1 && boss.cnt %3 == 0 ){
			addebullet( boss.x, boss.y, 10, 4, fix_rad2 + rand( 0.6 ), 4, 11, 3, 400 );
			addebullet( boss.x, boss.y, 10, 5, fix_rad2 + rand( 0.6 ), 4, 11, 3, 400 );
			shotcnt++;
		}
		if( shotcnt >= 45 ){
			shotcnt = 0;
			change = 0;
			wait = 40;
			fix_rad = - 2.0 / 12.0;
		}
	}
	if( wait > 0 ){
	wait--;
	}
}


		