/*--------------------------------------------/
/2�ʗp�{�X                                    /
/�g�p�ԍ���20-24                              /
/                                             /
/--------------------------------------------*/

#include "dxlib.h"
#include "Extern.h"
#include "mathoperation.h"

//�e��o�^����ׂ̃v���g�^�C�v�錾
void addebullet( float x, float y, int pow, int ptn, float rad, float spd, int img, int size, int id );
void addebullet2( float x, float y, int pow, int ptn, float rad, float spd, int img, float width, float length, int id );

void bossbulletcalc20(){
	static int shotcnt;
	static int waitcnt;

	if( boss.cnt <= 1 ){
		shotcnt = 0;
		waitcnt = 20 - info.dificality * 3;
	}

	float shotrad = dis_rad( boss.x, boss.y );
	if( boss.cnt % ( 5 - info.dificality ) == 0 && waitcnt == 0 ){
		for( int i = 0; i < 10; i++ ){
			addebullet( boss.x, boss.y, 10, 1, shotrad + i / 5.0, ( 1 + shotcnt * 0.1 ) * ( 1 + info.dificality * 0.15 ), 51, 4, 400 );
		}
		shotcnt++;
	}else if( waitcnt > 0 ){
		waitcnt--;
	}
	if( shotcnt == 15 ){
		shotcnt = 0;
		waitcnt = 20 - info.dificality * 3;
	}
	
}

void bossbulletcalc21(){
	static int shotcnt;

	if( boss.cnt <= 1 ){
		shotcnt = 0;
	}

	float randam = rand( 0.4 );


	if( boss.cnt % ( 5 - info.dificality ) == 0 ){
		addebullet2( boss.x, boss.y, 10, 8, 1 + randam, 1.3, 70, 1, 2, 400 );
		addebullet2( boss.x, boss.y, 10, 8, 1 + randam, 1.6, 70, 1, 2, 400 );
		addebullet2( boss.x, boss.y, 10, 8, 1 + randam, 1.9, 70, 1, 2, 400 );
		addebullet2( boss.x, boss.y, 10, 8, 1 + randam, 2.2, 70, 1, 2, 400 );
	}
}

void bossbulletcalc22(){
	static float shotrad,shotrad2,state;

	if(boss.cnt <= 1 ){
		shotrad = 0.55;
		state = 0;
	}

	if( boss.cnt % (30 - info.dificality * 3) == 0 ){
		addebullet( boss.x, boss.y, 25, 21, shotrad, 1, 2, 4, 400 );
		addebullet( boss.x, boss.y, 25, 22, - shotrad, 1, 2, 4, 400 );
		if( shotrad > 0.3 && state == 0 ){
			shotrad -= 0.015 + info.dificality * 0.003;
		}else{
			state = 1;
		}
		if( shotrad < 1.1 && state == 1){
			shotrad += 0.06 + info.dificality * 0.012;
		}else{
			state = 0;
		}

	}
	if( state == 1 && boss.cnt % ( 36 - info.dificality * 5 ) == 0 || shotrad > 0.4 && boss.cnt % ( 36 - info.dificality * 5 ) == 0 ){
		shotrad2 = dis_rad( boss.x, boss.y ) + rand( 0.04 ); 
		for( int i = 0; i < 5; i++ ){
			addebullet( boss.x, boss.y, 25, 1, shotrad2 + (0.1 - i * 0.05), 2 * (0.8 + info.dificality* 0.2), 38, 2, 400 );
		}
	}
}

void bossbulletcalc23(){
	static float limit[2], shotrad[2][8];

	if( boss.cnt <= 1 ){
		for( int i = 0; i < 2; i++ ){
			for(int j = 0; j < 8; j++ ){
				if( j < 2 ){
					limit[j] = 0;
				}
				shotrad[i][j] = -2;
			}
		}
	}

	if( boss.cnt % 50 == 0 ){
		for( int i = 0; i < 8; i++ ){
			if( shotrad[0][i] == -2 ){
				shotrad[0][i] = 0.75;
				break;
			}
		}
	}else if( boss.cnt % 50 == 25 ){
		for( int i = 0; i < 8; i++ ){
			if( shotrad[1][i] == -2 ){
				shotrad[1][i] = -0.75;
				break;
			}
		}
	}
	if(boss.cnt % 2 == 0 ){
		for( int i = 0; i < 8; i++ ){
			if( shotrad[0][i] != -2 ){
				addebullet( boss.x + 50, boss.y, 10, 1, shotrad[0][i], 3, 50, 4, 400 );
				shotrad[0][i] -= 0.007 * (1 + info.dificality * 0.2);
				if( shotrad[0][i] < limit[0] ){
					shotrad[0][i] = -2;
					limit[0] = rand( 0.09 ) - ((info.dificality - 3) * 0.015 );
				}
			}
			if( shotrad[1][i] != -2 ){
				addebullet( boss.x - 50, boss.y, 10, 1, shotrad[1][i], 3, 50, 4, 400 );
				shotrad[1][i] += 0.007 * (1 + info.dificality * 0.2);
				if( shotrad[1][i] > limit[1] ){
					shotrad[1][i] = -2;
					limit[1] = rand( 0.09 ) + ((info.dificality - 3) * 0.015 );
				}
			}
		}
	}
	if( boss.cnt % ( 6 - info.dificality ) == 0 ){
		addebullet2( boss.x, boss.y, 10, 23, 1 + rand( 0.4 ), 3, 42 + GetRand( 7 ), 1, 2, 400 );
	}
}

void bossbulletcalc24(){
	static float shotrad;
	static int shotnum;

	if( boss.cnt <= 1 ){
		shotnum = 0;
	}
	if( shotnum % 10 == 0 ){
		shotrad = dis_rad( boss.x, boss.y );
	}

	if( boss.cnt % (30 - info.dificality * 5) == 0 ){
		for( int i = 0; i < 5 + info.dificality; i++ ){
			addebullet( boss.x, boss.y, 10, 1, shotrad + rand( 0.3 ), absrand( 0.9 * ( 1 + info.dificality * 0.25 )), 37, 2, 400 );
		}
		shotnum++;
	}
	if( boss.cnt % ( 45 - info.dificality * 5 ) == 0 && shotnum > 3 ){
		for( int i = 0; i < 4 + info.dificality; i++ ){
			addebullet( boss.x, boss.y, 10, 1, shotrad + rand( 0.3 ), absrand( 1.5 * ( 1 + info.dificality * 0.25 )), 50, 4, 400 );
		}
	}
	if( boss.cnt % ( 55 - info.dificality * 5 ) == 0 && shotnum > 8 ){
		for( int i = 0; i < 3 + info.dificality; i++ ){
			addebullet( boss.x, boss.y, 10, 1, shotrad + rand( 0.3 ), absrand( 2.1 * ( 1 + info.dificality * 0.25 )), 58, 6, 400 );
		}
	}
	if( boss.cnt % 55 == 0 && info.dificality == 3 && shotnum > 16 ){
		for( int i = 0; i < 6; i++ ){
			addebullet( boss.x, boss.y, 10, 1, shotrad + rand( 0.3 ), absrand( 4.3 ), 1, 5, 400 );
		}
	}
}