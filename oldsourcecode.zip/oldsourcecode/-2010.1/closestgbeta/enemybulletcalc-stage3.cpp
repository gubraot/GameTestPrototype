/*--------------------------------------------/
/�G�@�V���b�g�p�^�[��3�ʂ܂Ƃ�                /
/�g�p�ԍ�30-**                                /
/                                             /
/--------------------------------------------*/

#include "dxlib.h"
#include "Extern.h"
#include "mathoperation.h"

//�e��o�^����ׂ̃v���g�^�C�v�錾
void addebullet( float x, float y, int pow, int ptn, float rad, float spd, int img, int size, int id );
void addebullet2( float x, float y, int pow, int ptn, float rad, float spd, int img, float width, float length, int id );

void enemybulletcalc30( int i ){
	if( enemy[i].time <= 1 ){
		enemy[i].shotrad = dis_rad( enemy[i].x, enemy[i].y );
	}
	if( enemy[i].time % ( 6 - info.dificality ) == 0 && enemy[i].shotcnt < 20 ){
		if( info.dificality == 3 && player.magicflg == 1 ){
			addebullet( enemy[i].x, enemy[i].y, 8, 1, enemy[i].shotrad + 0.01, ( 1.6 + enemy[i].shotcnt * 0.1 ) * (1 + info.dificality * 0.15 ), 56, 4, i );
			addebullet( enemy[i].x, enemy[i].y, 8, 1, enemy[i].shotrad - 0.01, ( 1.6 + enemy[i].shotcnt * 0.1 ) * (1 + info.dificality * 0.15 ), 56, 4, i );
		}else{
			addebullet( enemy[i].x, enemy[i].y, 8, 1, enemy[i].shotrad, ( 1.0 + enemy[i].shotcnt * 0.1 ) * (1 + info.dificality * 0.15 ), 56, 4, i );
		}
		enemy[i].shotcnt++;
	}
}

void enemybulletcalc31( int i ){
	if( enemy[i].time <= 1 ){
		enemy[i].shotrad = dis_rad( enemy[i].x, enemy[i].y );
	}
	if( enemy[i].time % 8 == 0 && info.dificality == 3 && player.magicflg == 1 ){
		for( int j = 0; j < 16; j++ ){
			addebullet2( enemy[i].x, enemy[i].y, 8, 24, enemy[i].shotrad + j / 8.0, 5, 107, 2, 14, i );
		}
		enemy[i].shotcnt++;
	}else if( enemy[i].time % ( 6 - info.dificality ) == 0 ){
		for( int j = 0; j < ( 6 + info.dificality ); j++ ){
			addebullet2( enemy[i].x, enemy[i].y, 8, 24, enemy[i].shotrad + j / (float)(( 6 + info.dificality ) / 2.0 ), 2 * ( 0.8 + info.dificality * 0.2 ), 99, 2, 3, i );
		}
		enemy[i].shotcnt++;
	}

	if( enemy[i].shotcnt == 20 ){
		enemy[i].shotcnt = 0;
		enemy[i].shotrad = dis_rad( enemy[i].x, enemy[i].y );
	}
}

void enemybulletcalc32( int i ){
	static float rate;

	if( enemy[i].time <= 1 ){
		if( info.dificality == 3 ){
			rate = 0.3;
		}else if( info.dificality == 2 ){
			rate = 0.6;
		}else if( info.dificality == 1 ){
			rate = 0.9;
		}else{
			rate = 1.0;
		}
	}
	if( enemy[i].time % ( 10 - info.dificality * 2 ) == 0 ){
		addebullet( enemy[i].x + 10, enemy[i].y, 8, 1, 1 - enemy[i].shotcnt * ( 0.1 * rate ), 2 * (0.8 + info.dificality * 0.2 ), 50, 4, i ); 
		addebullet( enemy[i].x - 10, enemy[i].y, 8, 1, 1 + enemy[i].shotcnt * ( 0.1 * rate ), 2 * (0.8 + info.dificality * 0.2 ), 50, 4, i ); 
		enemy[i].shotcnt++;
	}
}

void enemybulletcalc33( int i ){
	static int shotnum;
	if( enemy[i].time <= 1 ){
		enemy[i].shotrad = dis_rad( enemy[i].x, enemy[i].y );
		shotnum = 30 + info.dificality * 10;
	}
	
	if( enemy[i].time % ( 100 - info.dificality * 20 ) == 0 ){
		for( int j = 0; j < shotnum; j++ ){
			addebullet2( enemy[i].x, enemy[i].y, 8, 1, enemy[i].shotrad + j / ( shotnum / 2.0 ), 1.3 * ( 0.8 + info.dificality * 0.2 ), 66, 0.8, 1.5, i );
			addebullet2( enemy[i].x, enemy[i].y, 8, 1, enemy[i].shotrad + j / ( shotnum / 2.0 ), 1.6 * ( 0.8 + info.dificality * 0.2 ), 66, 0.8, 1.5, i );
		}
		for( int j = 0; j < 10; j++ ){
			addebullet2( enemy[i].x, enemy[i].y, 8, 1, enemy[i].shotrad + 0.02, (1.3 + j * 0.2 ) * ( 0.8 + info.dificality * 0.2 ), 66, 0.8, 1.5, i );
			addebullet2( enemy[i].x, enemy[i].y, 8, 1, enemy[i].shotrad - 0.02, (1.3 + j * 0.2 ) * ( 0.8 + info.dificality * 0.2 ), 66, 0.8, 1.5, i );
		}
	}
	
}

void enemybulletcalc34( int i ){
	static int fix_x,fix_y;
	if( enemy[i].time <= 1 ){
		enemy[i].shotrad = dis_rad( enemy[i].x, enemy[i].y );
	}
	
	if( enemy[i].time % ( 4 - info.dificality ) == 0 && enemy[i].shotcnt < 100 ){
		fix_x = rad_x( enemy[i].shotrad, 15 );
		fix_y = rad_y( enemy[i].shotrad, 15 );
		addebullet2( enemy[i].x + fix_x, enemy[i].y + fix_y, 8, 25, enemy[i].shotrad, 0, 66, 0.8, 1.5, i );
		if( info.dificality == 3 && player.magicflg == 1 ){
			addebullet2( enemy[i].x + fix_x * 2, enemy[i].y + fix_y * 2, 8, 25, enemy[i].shotrad, 0, 66, 0.8, 1.5, i );
		}
		enemy[i].shotrad += 0.02;
		enemy[i].shotcnt ++;
	}
}

void enemybulletcalc35( int i ){
	if( enemy[i].time <= 1 ){
	}

	if( enemy[i].time % ( 10 - info.dificality * 1 ) == 0 ){
		for( int j = 0; j < ( 5 + info.dificality * 2 ); j++ ){
			addebullet( enemy[i].x + rand( 50.0 ), enemy[i].y + rand( 50.0 ), 7, 2, ( enemy[i].shotcnt % 6 ) / 3.0, 2 + (info.dificality * 0.5 ), 41, 2, i );
		}
		enemy[i].shotcnt++;
	}
}