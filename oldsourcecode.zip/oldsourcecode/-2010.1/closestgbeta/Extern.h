/*--------------------------------------------/
/Extern�錾                                   /
/����cpp�Ŏg�����̂̊O���Q�Ɛ錾              /
/�ecpp�łقڊm���ɃC���N���[�h���ׂ��t�@�C��  /
/�R�����g�͓��l�̃t�@�C��GlobalVariable.h     /
/--------------------------------------------*/
#ifndef _INC_EXTERN
#define _INC_EXTERN


#define DEBUG_MEASURENUM 6
#define FLAME 60.0
#define ENEMY_MAXNUM 400
#define MAX_X 400
#define MAX_Y 460
#define MIN_XY 40
#define BULLET_MAX_X 420
#define BULLET_MAX_Y 480
#define BULLET_MIN_XY 20
#define P_SHOT_MAX1 40
#define P_SHOT_MAX2 8
#define E_SHOT_MAX 1500
#define PLAYER_ANIME1 4
#define	PLAYER_TYPE 3
#define STAGE_NUM 6
#define BOSS_NUM 20
#define STAGE_BOSS_MAX 3
#define SECTION_MAX 20
#define ITEM_MAX 200
#define EFFECTMAX 400

//
extern int		mainini;
//

extern char		Key[256];

extern float	flame_time;
extern int		obnum;

extern int		GameCounter;
extern int		pcounter;

extern int		color[20];

extern int		key_up,
				key_down,
				key_right,
				key_left,
				key_shot,
				key_magic,
				key_special,
				key_slow,
				key_pause;

extern int		backboard[3];
extern int		boardparts[20];
extern int		Playeranime[4][6];
extern int		Playersp[2][20];
extern int		enemydeathimg[16];
extern int		bossdeathimg[16];
extern int		edeathkake[6];
extern int		bdeathkake[5];
extern int		menuimg[6];
extern int		bossmater[3];
extern int		ccelect[2][2];
extern int		titleparts[20];
extern int		timenum[10];
extern int		numgraph0[10];
extern int		numgraph1[10];
extern int		numgraph2[10];
extern int		xnumgraph[10];
extern int		backimg[30];

extern int		font[6];

extern int		img_screen;

extern int		powitem[2];
extern int		magicitem[32];
extern int		sppointitem[12];
extern int		pointitem[2];	

extern int		stgsound[10];
extern int		manusound[10];
extern int		effectsound[10];
extern int		bgmsound[10];

extern int		fireballsprite[32];
extern int		heart[12];

extern int		stagefile[STAGE_NUM];

extern int		bosscalc[STAGE_NUM];

extern int		bossfile[BOSS_NUM];

extern int		stagecalc[STAGE_NUM];

extern int		ebulletexp[16];
extern int		hitsmoke[32];
extern int		hitring;
extern int		star[10];
extern int		powerup;
extern int		spslasheff[4];
extern int		slasheff[4];
extern int		spallow[10];
extern int		swing[5];

extern int		n2bullet[8];
extern int		wbullet[8];
extern int		nbullet[40];
extern int		smbullet[5];
extern int		crisbullet[8];
extern int		mcirclebullet[8];
extern int		lcirclebullet[8];
extern int		pbulletimg[20];
extern int		rbullet[10];
extern int		lazerimg[40];
extern int		lcrisbullet[8];
extern int		mscirclebullet[8];
extern int		rsbullet[8];
extern int		stickbullet1[8];
extern int		stickbullet2[8];

extern int		circleguage[4];

extern int		magical[4];

typedef struct Effectobj{
	float	x,
			y,
			fanc,
			rad;
	int		count,
			lifecount,
			flg,
			type;
}Effectobj;

extern Effectobj effect[EFFECTMAX];

typedef struct BackGround{
	float	rad,
			nowspd,
			tspd,
			spd;
	int		num,
			switchnum,
			switchcount;
}BackGround;

extern BackGround bg;

typedef struct Debug{
	int			swich;		
	long		headtime[DEBUG_MEASURENUM],
				foottime[DEBUG_MEASURENUM];
	float		process[DEBUG_MEASURENUM];

} Debug;

extern Debug debug;

typedef struct Config{
	int extend[3],
		powerup[7],
		m_maxup;
}Config;

extern Config config;

typedef struct Speed{
	float	objspeed,
			autofps;
	int 	gamespeed,
			count;
}Speed;

extern Speed spd;

typedef struct PlayData{
	int		score[2],
			stage,
			powerint[2],
			pointint[2],
			sppoint[2],
			magicget[2],
			graze,
			sp_rate[3],
			clearnum[2],
			sp_score[2],
			bosssecscore,
			hitnum[2],
			dificality;
} Pdata;

extern Pdata info;

typedef struct oldplaydata{
	int		totalhiscore[10],
			stagehiscore[STAGE_NUM][10],
			stagesp_score[STAGE_NUM][10],
			totalinfo[10][9],
			config[20];
} oldplaydata;

extern oldplaydata record;

typedef struct MyCharacter{
	float	x,
			y,
			size;
	int		hp,
			hpmax,
			exnum,
			magic,
			magicmax,
			no_control,
			mycount,
			shotcount,
			nodmg_cnt,
			nodmg_max,
			charge_cnt,
			shot_lv,
			graze,
			chara_type,
			g_over_flag,
			damage_flg,	
			pause,
			magicflg,
			specialflg,
			clearflg,
			hitbullet[2];
} Player;

extern Player player;

typedef struct Enemy_Data{
	float	x,
			y,
			angle,
			spd,
			shotrad,
			hp,
			dist;
	int		addtime,
			moveptn,
			movecng,
			movecng2,
			shotptn,
			shotcnt,
			time,
			hpmax,
			size,
			item[4],
			img,
			flg;
} Enemy;

extern Enemy enemy[ENEMY_MAXNUM];
extern Enemy bossenemy[100];

typedef struct Player_Bullet{
	float	x,
			y,
			angle,
			atk,
			spd;
	int		flg,
			size,
			ptn,
			gen,
			time,
			graph;
} Player_Bullet;

extern Player_Bullet pbullet[P_SHOT_MAX1][P_SHOT_MAX2];

typedef struct PLaser{
	float	lux[40],
			luy[40],
			rux[40],
			ruy[40],
			ldx[40],
			ldy[40],
			rdx[40],
			rdy[40],
			x[40],
			y[40],
			rad,		
			P0[2],
			P1[2],
			P2[2],
			u;

	int		time,
			maxtime,
			target,
			atk,
			flg;

} PLaser;

extern PLaser plazer[20];

typedef struct Enemy_Bullet{
	float	x,
			y,
			rad,
			spd,
			dist,
			size;
	int		flg,
			atk,
			ptn,
			graph,
			time,
			delef,
			grazeflg,
			enemyid,
			hitflg;
} Enemy_Bullet;

extern Enemy_Bullet ebullet[E_SHOT_MAX];

typedef struct Enemy_RecBullet{
	float	x,
			y,
			rad,
			spd,
			dist,
			size,
			recx[4],
			recy[4],
			width,
			length;
	int		flg,
			atk,
			ptn,
			graph,
			time,
			delef,
			grazeflg,
			enemyid,
			hitflg;
} Enemy_RecBullet;

extern Enemy_RecBullet erecbullet[E_SHOT_MAX];


typedef struct RecArea{
	float	x,
			y,
			spd,
			rad,
			recx[4],
			recy[4],
			width,
			length;
	int		flg,
			areaflge[ENEMY_MAXNUM],
			areaflgb,
			areaflgeb[100],
			atk,
			hitnum,
			graph,
			target,
			time,
			moveptn,
			maxtime;
} RecArea;

extern RecArea recarea[20];

typedef struct Boss_state{
	float	x,
			y,
			nowhp,
			dist;
	int		flg,
			bossid,
			maxhp,
			openhp,
			checkhp,
			checkhp2,
			checkcnt,
			limitcnt,
			allcnt,
			lifetime,
			gclimit,
			calc,
			waitccnt,
			bonuscnt,
			useflg[5],
			cnt,
			fanc;

} Boss_state;

extern Boss_state boss;

typedef struct Stage_Data{
	int		time,
			effect,
			flg;
	float	conf1,
			conf2,
			conf3,
			conf4;
} Stage_Data;

extern Stage_Data stage_data[100][STAGE_NUM];

typedef struct Big_Enemy{
	int		addtime,
			calctime,
			limitdis,
			enemynum,
			dispell,
			flg;

} Big_Enemy;

extern Big_Enemy mboss[STAGE_NUM][STAGE_BOSS_MAX];

typedef struct Enemynum{
	int		hp,
			ptn,
			endtime,
			item[4],
			clearbonus,
			clrefect;
} Enemynum;

extern Enemynum enemynum[BOSS_NUM][SECTION_MAX];

typedef struct Item{
	float	x,				
			y,
			rad,
			dist;
	int		type,
			time,
			flg,
			autoget;
}Item;

extern Item item[ITEM_MAX];

#endif