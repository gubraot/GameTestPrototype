/*--------------------------------------------/
/���@�V���b�g�p�^�[��02                       /
/�E���͂��Ă�ԁ������ɋO����U��e           /
/                                             /
/--------------------------------------------*/

#include "dxlib.h"
#include "Extern.h"
#include "mathoperation.h"
#include "imagedraw.h"

void mybullet02( int num, int lv ){
	static int gen = 0;
	pbullet[num][lv].spd	= 14;
	if( pbullet[num][lv].time == 0 ){
		if( key_right != 0 ){
			gen += 2;
			if(	gen >= 30 ){
				gen  = 30;
			} 
		}
		else{
			gen	= ( gen / 2 ) - 1;
			if(	gen <= 0 ){
				gen = 0;
			}
		}
	}
	if(pbullet[num][lv].time == 1 ){
		pbullet[num][lv].angle = pbullet[num][lv].angle - ((float)gen / 180.0);
	}
	pbullet[num][lv].x	+= rad_x( pbullet[num][lv].angle, pbullet[num][lv].spd );
	pbullet[num][lv].y	+= rad_y( pbullet[num][lv].angle, pbullet[num][lv].spd ); 
	if( pbullet[num][lv].time >= 1){
		drawbullet( pbullet[num][lv].x, pbullet[num][lv].y, pbullet[num][lv].angle, 0, pbullet[num][lv].graph );
	}
}
