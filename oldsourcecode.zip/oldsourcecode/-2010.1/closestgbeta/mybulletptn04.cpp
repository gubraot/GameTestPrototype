/*--------------------------------------------/
/���@�V���b�g�p�^�[��04                       /
/���@�����ԋ߂��G�Ƀz�[�~���O����e         /
/                                             /
/--------------------------------------------*/

#include "dxlib.h"
#include "Extern.h"
#include "mathoperation.h"
#include "imagedraw.h"

void mybullet04( int num, int lv ){
	float mem_x,mem_y;
	float P0[2],P1[2],P2[2],P3[2];
	float u ;
	float P01[2] , P12[2] , P23[2] ;
	float P02[2] , P13[2] ;
	float P03[2] ;
	int snum = pbullet[num][lv].gen;

	mem_x = pbullet[num][lv].x;
	mem_y = pbullet[num][lv].y;
	if( pbullet[num][lv].time == 0 ){
		pbullet[num][lv].gen = searchdisobject( 0 );
		pbullet[num][lv].angle = 0.75;
	}else if( pbullet[num][lv].time <= 30 && snum != -1 ){
		P0[0] = player.x;
		P0[1] = player.y;
		P1[0] = player.x+120;
		P1[1] = player.y-100;
		P2[0] = player.x+120;
		P2[1] = player.y-200;
		if( snum != 1000 ){
			P3[0] = enemy[snum].x;
			P3[1] = enemy[snum].y;
		}else{
			P3[0] = boss.x;
			P3[1] = boss.y;
		}

			u = ( 1.0 / 30 ) * pbullet[num][lv].time ;

			P01[0] = ( 1.0 - u ) * P0[0] + u * P1[0] ; P01[1] = ( 1.0 - u ) * P0[1] + u * P1[1] ;
			P12[0] = ( 1.0 - u ) * P1[0] + u * P2[0] ; P12[1] = ( 1.0 - u ) * P1[1] + u * P2[1] ;
			P23[0] = ( 1.0 - u ) * P2[0] + u * P3[0] ; P23[1] = ( 1.0 - u ) * P2[1] + u * P3[1] ;

			P02[0] = ( 1.0 - u ) * P01[0] + u * P12[0] ; P02[1] = ( 1.0 - u ) * P01[1] + u * P12[1] ;
			P13[0] = ( 1.0 - u ) * P12[0] + u * P23[0] ; P13[1] = ( 1.0 - u ) * P12[1] + u * P23[1] ;

			P03[0] = ( 1.0 - u ) * P02[0] + u * P13[0] ; P03[1] = ( 1.0 - u ) * P02[1] + u * P13[1] ;

			pbullet[num][lv].x = ( int )P03[0] ;
			pbullet[num][lv].y = ( int )P03[1] ;
	
	pbullet[num][lv].angle = free_rad( mem_x, mem_y, pbullet[num][lv].x, pbullet[num][lv].y );
	drawbullet( pbullet[num][lv].x, pbullet[num][lv].y, pbullet[num][lv].angle, 0, pbullet[num][lv].graph );
	}else{
		pbullet[num][lv].spd	= 15;

		pbullet[num][lv].x	+= rad_x( pbullet[num][lv].angle, pbullet[num][lv].spd );
		pbullet[num][lv].y	+= rad_y( pbullet[num][lv].angle, pbullet[num][lv].spd );
		drawbullet( pbullet[num][lv].x, pbullet[num][lv].y, pbullet[num][lv].angle, 0, pbullet[num][lv].graph );
	}
}

void mybullet05( int num, int lv ){
	float mem_x,mem_y;
	float P0[2],P1[2],P2[2],P3[2];
	float u ;
	float P01[2] , P12[2] , P23[2] ;
	float P02[2] , P13[2] ;
	float P03[2] ;
	int snum = pbullet[num][lv].gen;

	mem_x = pbullet[num][lv].x;
	mem_y = pbullet[num][lv].y;
	if( pbullet[num][lv].time == 0 ){
		pbullet[num][lv].gen = searchdisobject( 0 );
		pbullet[num][lv].angle = -0.75;
	}else if( pbullet[num][lv].time <= 30 && snum != -1 ){
		P0[0] = player.x;
		P0[1] = player.y;
		P1[0] = player.x-120;
		P1[1] = player.y-100;
		P2[0] = player.x-120;
		P2[1] = player.y-200;
		if( snum != 1000 ){
			P3[0] = enemy[snum].x;
			P3[1] = enemy[snum].y;
		}else{
			P3[0] = boss.x;
			P3[1] = boss.y;
		}

			u = ( 1.0 / 30 ) * pbullet[num][lv].time ;

			P01[0] = ( 1.0 - u ) * P0[0] + u * P1[0] ; P01[1] = ( 1.0 - u ) * P0[1] + u * P1[1] ;
			P12[0] = ( 1.0 - u ) * P1[0] + u * P2[0] ; P12[1] = ( 1.0 - u ) * P1[1] + u * P2[1] ;
			P23[0] = ( 1.0 - u ) * P2[0] + u * P3[0] ; P23[1] = ( 1.0 - u ) * P2[1] + u * P3[1] ;

			P02[0] = ( 1.0 - u ) * P01[0] + u * P12[0] ; P02[1] = ( 1.0 - u ) * P01[1] + u * P12[1] ;
			P13[0] = ( 1.0 - u ) * P12[0] + u * P23[0] ; P13[1] = ( 1.0 - u ) * P12[1] + u * P23[1] ;

			P03[0] = ( 1.0 - u ) * P02[0] + u * P13[0] ; P03[1] = ( 1.0 - u ) * P02[1] + u * P13[1] ;

			pbullet[num][lv].x = ( int )P03[0] ;
			pbullet[num][lv].y = ( int )P03[1] ;
	
	pbullet[num][lv].angle = free_rad( mem_x, mem_y, pbullet[num][lv].x, pbullet[num][lv].y );
	drawbullet( pbullet[num][lv].x, pbullet[num][lv].y, pbullet[num][lv].angle, 0, pbullet[num][lv].graph );
	}else{
		pbullet[num][lv].spd	= 15;

		pbullet[num][lv].x	+= rad_x( pbullet[num][lv].angle, pbullet[num][lv].spd );
		pbullet[num][lv].y	+= rad_y( pbullet[num][lv].angle, pbullet[num][lv].spd );
		drawbullet( pbullet[num][lv].x, pbullet[num][lv].y, pbullet[num][lv].angle, 0, pbullet[num][lv].graph );
		//drawbullet( mem_x, mem_y, pbullet[num][lv].angle, 0, pbullet[num][lv].graph );
	}
}