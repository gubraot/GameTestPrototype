/*--------------------------------------------/
/�G�@�V���b�g�p�^�[��1�ʂ܂Ƃ�                /
/�g�p�ԍ�10-**                                /
/                                             /
/--------------------------------------------*/

#include "dxlib.h"
#include "Extern.h"
#include "mathoperation.h"

//�e��o�^����ׂ̃v���g�^�C�v�錾
void addebullet( float x, float y, int pow, int ptn, float rad, float spd, int img, int size, int id );
void addebullet2( float x, float y, int pow, int ptn, float rad, float spd, int img, float width, float length, int id );

void enemybulletcalc10( int i ){
	float fix_rad;
	fix_rad = dis_rad( enemy[i].x, enemy[i].y );

	if( enemy[i].time % ( 60 / (info.dificality + 1)) == 0  && enemy[i].shotcnt < info.dificality * 6 ){
			addebullet( enemy[i].x, enemy[i].y, 8, 1, fix_rad, 1.5 *(0.75 +(info.dificality * 0.25)) , 50, 4, i );
			enemy[i].shotcnt;
	}
}

void enemybulletcalc11( int i ){
	float fix_rad;
	fix_rad = dis_rad( enemy[i].x, enemy[i].y );

	if( enemy[i].time == 10 && enemy[i].shotcnt == 0 ){
		int ren = info.dificality * 2 + 5;
		for( int j = 0; j < ren; j++){
			addebullet( enemy[i].x, enemy[i].y, 10, 1, fix_rad + 0.15 + (rand(info.dificality * 0.02)), 1.2 + ( j * 0.1 ) , 20, 3, i );
			addebullet( enemy[i].x, enemy[i].y, 10, 1, fix_rad + (rand(info.dificality * 0.02)), 1.2 + ( j * 0.1 ) , 20, 3, i );
			addebullet( enemy[i].x, enemy[i].y, 10, 1, fix_rad - 0.15 + (rand(info.dificality * 0.02)), 1.2 + ( j * 0.1 ) , 20, 3, i );
		}
		enemy[i].shotcnt++;
	}
}

void enemybulletcalc12( int i ){
	float fix_rad;
	fix_rad = dis_rad( enemy[i].x, enemy[i].y );
	int ren = info.dificality * 4 + 16;

	if( enemy[i].time % 180 == 120 ){
		for( int j = 0; j < ren; j++ ){
			addebullet( enemy[i].x, enemy[i].y, 10, 1, fix_rad + (2 * j / (float)ren), 1.2 + ( info.dificality * 0.3 ) , 66, 2, i );
		}
	}
}

void enemybulletcalc13( int i ){
	float fix_rad;
	fix_rad = dis_rad( enemy[i].x, enemy[i].y );
	if(enemy[i].time > 20 && enemy[i].shotcnt < 5 && enemy[i].time % (30 / (info.dificality + 1)) == 0){
		addebullet( enemy[i].x, enemy[i].y, 10, 1, fix_rad, 3, 41, 2, i );
		enemy[i].shotcnt++;
	}else if( enemy[i].shotcnt == info.dificality + 2 && enemy[i].time > 120 ){
		for(int j = 0; j < 11; j++){
			addebullet2( enemy[i].x, enemy[i].y, 7, 1, fix_rad + (float)( -5 + j ) * ( 0.04 - ( info.dificality * 0.01 )), 2 * (0.75 + info.dificality * 0.25), 33, 0.8, 4, i );
		}
		enemy[i].shotcnt++;
	}
}

void enemybulletcalc14( int i ){
	float shotpos = enemy[i].time * 0.007;
	int shotnum = enemy[i].shotcnt + 1;
	if( shotnum > info.dificality + 1 ) shotnum = info.dificality + 1;
	float shotstart = shotpos + (shotnum - 1) * 0.01;

	if( enemy[i].time % 12 - (info.dificality * 2) == 0 ){
		for( int j = 0; j < shotnum ; j++){
			addebullet2( enemy[i].x, enemy[i].y, 9, 1, shotstart - j * 0.02, 1 + ( info.dificality * 0.5 ), 43, 1, 3, i );
		}
		enemy[i].shotcnt++;
	}
}

void enemybulletcalc15( int i ){
	float fix_rad;
	fix_rad = dis_rad( enemy[i].x, enemy[i].y );
	int shotnum = 16 + (info.dificality * 4);

	if( enemy[i].time % (120 - info.dificality * 10) == 60 ){
		for(int j = 0; j < shotnum; j++){
			addebullet( enemy[i].x, enemy[i].y, 6, 1, fix_rad + ( j /(shotnum / 2.0)), 1.5 + (info.dificality * 0.25), 37, 4, i );
		}
	}
}

void enemybulletcalc16( int i ){
 	int shotnum = 3 + (info.dificality * 2);
	float fix_rad;
	fix_rad = dis_rad( enemy[i].x, enemy[i].y );

	if(enemy[i].time % 60 == 0 ){
		for( int j = 0; j < shotnum; j++ ){
			if( j == 0 ){
				addebullet2( enemy[i].x, enemy[i].y, 7, 1, fix_rad, 1 + ( info.dificality * 0.5 ), 44, 1, 3, i );
			}else if( j % 2 == 1 ){
				addebullet2( enemy[i].x, enemy[i].y, 7, 1, fix_rad + ((shotnum+ 1) / 2) * 0.05, 1 + ( info.dificality * 0.5 ), 44, 1, 3, i );
			}else{
				addebullet2( enemy[i].x, enemy[i].y, 7, 1, fix_rad - ((shotnum+ 1) / 2) * 0.05, 1 + ( info.dificality * 0.5 ), 44, 1, 3, i );
			}
		}
	}
}