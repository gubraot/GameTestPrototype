/*--------------------------------------------/
/���@�V���b�g�p�^�[��01                       /
/�^������rad�����ɒe�𔭎˂���                /
/                                             /
/--------------------------------------------*/

#include "dxlib.h"
#include "Extern.h"
#include "mathoperation.h"
#include "imagedraw.h"

void mybullet01( int num, int lv ){

	//test
		pbullet[num][lv].spd	= 12;

		pbullet[num][lv].x	+= rad_x( pbullet[num][lv].angle, pbullet[num][lv].spd );
		pbullet[num][lv].y	+= rad_y( pbullet[num][lv].angle, pbullet[num][lv].spd );
		drawbullet( pbullet[num][lv].x, pbullet[num][lv].y, pbullet[num][lv].angle, 0, pbullet[num][lv].graph );
}
