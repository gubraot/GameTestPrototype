/*--------------------------------------------/
/�g���b�N                                     /
/�܂��͌Œ�G��p�e�@�@�@�@                   /
/�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@           /
/--------------------------------------------*/

#include "dxlib.h"
#include "Extern.h"
#include "mathoperation.h"
#include <math.h>

void addebullet( float x, float y, int pow, int ptn, float rad, float spd, int img, int size, int id );
void addebullet2( float x, float y, int pow, int ptn, float rad, float spd, int img, float width, float length, int id );

void ebulletptn21( int i ){
	ebullet[i].x	+= rad_x( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
	ebullet[i].y	+= rad_y( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
	if( ebullet[i].time % (30 - info.dificality * 3) == 0 ){
		addebullet( ebullet[i].x, ebullet[i].y, 10, 1, ebullet[i].rad - 0.4, ebullet[i].spd * 1.3, 70, 1.2, 400 );
	}
}

void ebulletptn22( int i ){
	ebullet[i].x	+= rad_x( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
	ebullet[i].y	+= rad_y( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
	if( ebullet[i].time % (30 - info.dificality * 3) == 0 ){
		addebullet( ebullet[i].x, ebullet[i].y, 10, 1, ebullet[i].rad + 0.4, ebullet[i].spd * 1.3, 70, 1.2, 400 );
	}
}

void ebulletptn23( int i ){
	float memx,memy,memspd;

	memx = rad_x( erecbullet[i].rad, erecbullet[i].spd );
	memy = rad_y( erecbullet[i].rad, erecbullet[i].spd ) + 0.01;
	memspd = ebullet[i].spd;
	erecbullet[i].rad = free_rad( 0, 0, memx, memy );
	erecbullet[i].spd = sqrt( distancefree( 0, 0, memx, memy ));
	if( erecbullet[i].spd >= memspd ) ebullet[i].spd = memspd;

	erecbullet[i].x	+= rad_x( erecbullet[i].rad, erecbullet[i].spd * spd.objspeed );
	erecbullet[i].y	+= rad_y( erecbullet[i].rad, erecbullet[i].spd * spd.objspeed );

	if( erecbullet[i].time == 50 ){
		erecbullet[i].ptn = 1;
		erecbullet[i].rad = rand( 0.05 );
		erecbullet[i].spd = 0.6 * ( 1 + info.dificality * 0.3 );
	}
}

void ebulletptn24( int i ){
	if( erecbullet[i].time < 60 ){
		erecbullet[i].rad -= (float) (4.5  * spd.objspeed)  / 180.0;
	}else if ( erecbullet[i].time < 63 ){
		erecbullet[i].rad += rand( 0.004 );
	}

	erecbullet[i].x	+= rad_x( erecbullet[i].rad, erecbullet[i].spd * spd.objspeed );
	erecbullet[i].y	+= rad_y( erecbullet[i].rad, erecbullet[i].spd * spd.objspeed );
}

void ebulletptn25( int i ){
	if( erecbullet[i].time > 60 ){
		if( erecbullet[i].spd <  2 * ( 1 + info.dificality * 0.2 ) ){
			erecbullet[i].spd += 0.001 * ( 1 + info.dificality );
		}
	}
	erecbullet[i].x	+= rad_x( erecbullet[i].rad, erecbullet[i].spd * spd.objspeed );
	erecbullet[i].y	+= rad_y( erecbullet[i].rad, erecbullet[i].spd * spd.objspeed );
}

void ebulletptn26( int i ){
	if( ebullet[i].time < 20 || ebullet[i].time > 240 ){
		ebullet[i].x	+= rad_x( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
		ebullet[i].y	+= rad_y( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
	}
}

void ebulletptn27( int i ){
	if( ebullet[i].time < 180 ){
		ebullet[i].rad += 0.0015;
		ebullet[i].spd = ebullet[i].spd * ( 99 / 100.0 );
	}else{
		ebullet[i].spd += 0.05;
	}

	ebullet[i].x	+= rad_x( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
	ebullet[i].y	+= rad_y( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
}

void ebulletptn28( int i ){
	if( ebullet[i].time < 180 ){
		ebullet[i].rad -= 0.0015;
		ebullet[i].spd = ebullet[i].spd * ( 99 / 100.0 );
	}else{
		ebullet[i].spd += 0.05;
	}

	ebullet[i].x	+= rad_x( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
	ebullet[i].y	+= rad_y( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
}

void ebulletptn29( int i ){
	if( ebullet[i].time % ( 4 - info.dificality ) == 0 ){
		addebullet2( ebullet[i].x, ebullet[i].y, 10, 7, rand( 1.0 ), ( info.dificality + 1 ) * 0.1, 42 + GetRand( 7 ), 1, 2, 400 ); 
	}
	ebullet[i].x	+= rad_x( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
	ebullet[i].y	+= rad_y( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
}

void ebulletptn30( int i ){
	if( ebullet[i].dist < 2500 ){
		ebullet[i].x	+= rad_x( ebullet[i].rad, 0.5 * spd.objspeed );
		ebullet[i].y	+= rad_y( ebullet[i].rad, 0.5 * spd.objspeed );	
	}else{
		ebullet[i].x	+= rad_x( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
		ebullet[i].y	+= rad_y( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
	}
}

void ebulletptn31( int i ){
	if( ebullet[i].time < 120 && spd.count == 1 ){
		ebullet[i].rad += 1 / 240.0;
		ebullet[i].spd -= ebullet[i].spd / 60.0;
	}
	ebullet[i].x	+= rad_x( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
	ebullet[i].y	+= rad_y( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
}

void ebulletptn32( int i ){
	if( ebullet[i].time < 120 && spd.count == 1 ){
		ebullet[i].rad -= 1 / 240.0;
		ebullet[i].spd -= ebullet[i].spd / 60.0;
	}
	ebullet[i].x	+= rad_x( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
	ebullet[i].y	+= rad_y( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
}

void ebulletptn33( int i ){
	float fix_spd;

	if( erecbullet[i].time < 20 || erecbullet[i].time > 80 ){
		fix_spd = erecbullet[i].spd;
	}else if( erecbullet[i].time < 50 ){
		fix_spd = ( ebullet[i].spd / 30.0 ) * ( 50 - erecbullet[i].time );
	}else if( erecbullet[i].time < 80 ){
		fix_spd = 0.0;
	}else if( erecbullet[i].time == 80 ){
		erecbullet[i].rad = dis_rad( erecbullet[i].x, erecbullet[i].y );
		fix_spd = erecbullet[i].spd;
	}

	erecbullet[i].x	+= rad_x( erecbullet[i].rad, fix_spd * spd.objspeed );
	erecbullet[i].y	+= rad_y( erecbullet[i].rad, fix_spd * spd.objspeed );
}

void ebulletptn34( int i ){
	if( ebullet[i].time < 90 ){
	ebullet[i].rad	+= (float) (3 * spd.objspeed)  / 360.0;
	}
	ebullet[i].x	+= rad_x( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
	ebullet[i].y	+= rad_y( ebullet[i].rad, ebullet[i].spd * spd.objspeed );

	if( ebullet[i].time % ( 11 - info.dificality * 3 ) == 0 && spd.count == 1 ){
		addebullet2( ebullet[i].x, ebullet[i].y, 10, 1, ebullet[i].rad + 0.5, 0.6, 44, 1, 2, 400 );
		addebullet2( ebullet[i].x, ebullet[i].y, 10, 1, ebullet[i].rad - 0.5, 0.6, 44, 1, 2, 400 );
	}
}

void ebulletptn35( int i ){
	if( ebullet[i].time < 90 ){
	ebullet[i].rad	-= (float) (3 * spd.objspeed)  / 360.0;
	}
	ebullet[i].x	+= rad_x( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
	ebullet[i].y	+= rad_y( ebullet[i].rad, ebullet[i].spd * spd.objspeed );

	if( ebullet[i].time % ( 11 - info.dificality * 3 ) == 0 && spd.count == 1 ){
		addebullet2( ebullet[i].x, ebullet[i].y, 10, 1, ebullet[i].rad + 0.5, 0.6, 44, 1, 2, 400 );
		addebullet2( ebullet[i].x, ebullet[i].y, 10, 1, ebullet[i].rad - 0.5, 0.6, 44, 1, 2, 400 );
	}
}

void ebulletptn36( int i ){
	if(ebullet[i].time == 180 ){
		ebullet[i].rad = dis_rad( ebullet[i].x, ebullet[i].y );
	}else if( ebullet[i].time > 180 ){
		if( ebullet[i].spd < ( 0.7 + info.dificality * 0.3 ) ){
			ebullet[i].spd += 0.0005;
		}
	}
	ebullet[i].x	+= rad_x( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
	ebullet[i].y	+= rad_y( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
}