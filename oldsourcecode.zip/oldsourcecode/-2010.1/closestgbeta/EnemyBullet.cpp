/*--------------------------------------------/
/�G�e��`�t�@�C��                             /
/�G�e�̐���                                   /
/                                             /
/--------------------------------------------*/

#include "dxlib.h"
#include "Extern.h"
#include "imagedraw.h"
#include "mathoperation.h"
#include <math.h>
#include "Debug.h"

//�e���֐��̃v���g�^�C�v�錾
void ebulletptn01( int i, int type );
void ebulletptn02( int i, int type );
void ebulletptn03( int i, int type );
void ebulletptn04( int i, int type );
void ebulletptn05( int i, int type );
void ebulletptn06( int i, int type );
void ebulletptn07( int i, int type );
void ebulletptn08( int i, int type );
void ebulletptn21( int i );
void ebulletptn22( int i );
void ebulletptn23( int i );
void ebulletptn24( int i );
void ebulletptn25( int i );
void ebulletptn26( int i );
void ebulletptn27( int i );
void ebulletptn28( int i );
void ebulletptn29( int i );
void ebulletptn30( int i );
void ebulletptn31( int i );
void ebulletptn32( int i );
void ebulletptn33( int i );
void ebulletptn34( int i );
void ebulletptn35( int i );
void ebulletptn36( int i );
void ebulletptn1001( int i );
void ebulletptn1002( int i );
void ebulletptn1003( int i );
void ebulletptn1005( int i, int type );

//���`����G�e�̓o�^
void addebullet( float x, float y, int pow, int ptn, float rad, float spd, int img, int size, int id ){ 
	for(int j = 0; j < E_SHOT_MAX; j++ ){
		if( ebullet[j].flg == 0 ){
			ebullet[j].flg	= 1;
			ebullet[j].x	= x;
			ebullet[j].y	= y;
			ebullet[j].size = size;
			ebullet[j].rad	= rad;
			ebullet[j].spd	= spd;
			ebullet[j].ptn	= ptn;
			ebullet[j].atk	= pow;
			ebullet[j].time = 0;
			ebullet[j].graph= img;
			ebullet[j].delef= 0;
			ebullet[j].grazeflg = 0;
			ebullet[j].enemyid = id;
			break;
		}
	}
}

//���`����G�e�̓o�^
void addebullet2( float x, float y, int pow, int ptn, float rad, float spd, int img, float width, float length, int id ){ 
	for(int j = 0; j < E_SHOT_MAX; j++ ){
		if( erecbullet[j].flg == 0 ){
			erecbullet[j].flg	= 1;
			erecbullet[j].x		= x;
			erecbullet[j].y		= y;
			erecbullet[j].rad	= rad;
			erecbullet[j].spd	= spd;
			erecbullet[j].ptn	= ptn;
			erecbullet[j].atk	= pow;
			erecbullet[j].time	= 0;
			erecbullet[j].graph	= img;
			erecbullet[j].delef	= 0;
			erecbullet[j].width = width;
			erecbullet[j].length= length;
			erecbullet[j].grazeflg = 0;
			erecbullet[j].enemyid = id;
			break;
		}
	}
}

//�G�e�̈ړ�
void move_ebullet( int i, int type ){
	if( type == 1 ){
		switch( ebullet[i].ptn ){
			case 1:
				ebulletptn01( i, 0 );
				break;
	
			case 2:
				ebulletptn02( i, 0 );
				break;

			case 3:
				ebulletptn03( i, 0 );
				break;

			case 4:
				ebulletptn04( i, 0 );
				break;

			case 5:
				ebulletptn05( i, 0 );
				break;

			case 6:
				ebulletptn06( i, 0 );
				break;

			case 7:
				ebulletptn07( i, 0 );
				break;

			case 8:
				ebulletptn08( i, 0 );
				break;

			case 21:
				ebulletptn21( i );
				break;

			case 22:
				ebulletptn22( i );
				break;

			case 26:
				ebulletptn26( i );
				break;

			case 27:
				ebulletptn27( i );
				break;

			case 28:
				ebulletptn28( i );
				break;

			case 29:
				ebulletptn29( i );
				break;

			case 30:
				ebulletptn30( i );
				break;

			case 31:
				ebulletptn31( i );
				break;

			case 32:
				ebulletptn32( i );
				break;

			case 34:
				ebulletptn34( i );
				break;

			case 35:
				ebulletptn35( i );
				break;

			case 36:
				ebulletptn36( i );
				break;

			case 1001:
				ebulletptn1001( i );
				break;

			case 1002:
				ebulletptn1002( i );
				break;

			case 1003:
				ebulletptn1003( i );
				break;

			case 1005:
				ebulletptn1005( i, 0 );
				break;
		}
		if(spd.count == 1) ebullet[i].time++;
	}else if( type == 2 ){
		switch( erecbullet[i].ptn ){
			case 1:
				ebulletptn01( i, 1 );
				break;

			case 2:
				ebulletptn02( i, 1 );
				break;

			case 3:
				ebulletptn03( i, 1 );
				break;

			case 4:
				ebulletptn04( i, 1 );
				break;

			case 5:
				ebulletptn05( i, 1 );
				break;

			case 6:
				ebulletptn06( i, 1 );
				break;

			case 7:
				ebulletptn07( i, 1 );
				break;
			case 8:
				ebulletptn08( i, 1 );
				break;

			case 23:
				ebulletptn23( i );
				break;

			case 24:
				ebulletptn24( i );
				break;

			case 25:
				ebulletptn25( i );
				break;

			case 33:
				ebulletptn33( i );
				break;

			case 1001:
				ebulletptn1001( i );
				break;

			case 1002:
				ebulletptn1002( i );
				break;

			case 1003:
				ebulletptn1003( i );
				break;

			case 1005:
				ebulletptn1005( i, 1 );
				break;
		}
		if(spd.count == 1) erecbullet[i].time++;
	}
}

//�G�erec����G���A�̐ݒ�
void hitarea( int i ){
	float diagonal, posrad, fixrad;
//	if( erecbullet[i].time <= 1 ){
		diagonal = sqrt(pow( erecbullet[i].length / 2.0, 2 ) + pow( erecbullet[i].width / 2.0, 2 ));
		posrad = atan2((  erecbullet[i].length / 2.0 ), (  erecbullet[i].width / 2.0 ));
		for( int j = 0; j < 4; j++ ){
			switch( j ){
				case 0:
					erecbullet[i].recx[j] = erecbullet[i].x + rad_x( erecbullet[i].rad + posrad, diagonal );
					erecbullet[i].recy[j] = erecbullet[i].y + rad_y( erecbullet[i].rad + posrad, diagonal );
					break;
				case 1:
					erecbullet[i].recx[j] = erecbullet[i].x + rad_x( erecbullet[i].rad - posrad, diagonal );
					erecbullet[i].recy[j] = erecbullet[i].y + rad_y( erecbullet[i].rad - posrad, diagonal );
					break;
				case 2:
					erecbullet[i].recx[j] = erecbullet[i].x - rad_x( erecbullet[i].rad + posrad, diagonal );
					erecbullet[i].recy[j] = erecbullet[i].y - rad_y( erecbullet[i].rad + posrad, diagonal );
					break;
				case 3:
					erecbullet[i].recx[j] = erecbullet[i].x - rad_x( erecbullet[i].rad - posrad, diagonal );
					erecbullet[i].recy[j] = erecbullet[i].y - rad_y( erecbullet[i].rad - posrad, diagonal );
					break;
			}
		}
		erecbullet[i].size = diagonal;
//	}else{
//		for( int j = 0; j < 4; j++ ){
//			erecbullet[i].recx[j] = rad_x( erecbullet[i].rad, erecbullet[i].spd );
//			erecbullet[i].recy[j] = rad_y( erecbullet[i].rad, erecbullet[i].spd );
//		}
//	}
}

//�G�e�Ǝ��@�̔���
int hitmodule(int num, int type){
	float hantei = 0.0;
	float grazehantei = 0.0;
	float diffencehantei = 0.0;
	float vx, vy, cx, cy, dis, ex, ey, ext, inner, rad;
	int flg = 0;
	if( type == 1 ){//���^�̓����蔻��
		hantei = pow( ebullet[num].size + player.size, (float)2.0 );
		grazehantei = pow( ebullet[num].size + player.size + 8, (float)2.0 );
		if( ebullet[num].dist < hantei ){
			return 1;//�q�b�g���Ă���
		}else if( ebullet[num].dist < grazehantei ){
			return 2;//�����Ă���
		}else if( ebullet[num].dist < diffencehantei && player.specialflg > 0 ){
			return 3;//�h�䂳�ꂽ
		}else{
			return 0;//�G���ĂȂ�
		}
	}else if( type == 2 ){//���^�̓����蔻��
		hantei = pow(erecbullet[num].size + player.size, 2 );
		grazehantei = pow(erecbullet[num].size + player.size +8, 2 );
		diffencehantei = pow(erecbullet[num].size + player.size +30, 2 );
		if( erecbullet[num].dist < hantei ){
			for( int j = 0; j < 4; j++){

				//�x�N�g��������
				vx = erecbullet[num].recx[j] - erecbullet[num].recx[(j+1)%4];
				vy = erecbullet[num].recy[j] - erecbullet[num].recy[(j+1)%4];
				cx = erecbullet[num].recx[j] - player.x;
				cy = erecbullet[num].recy[j] - player.y;
				dis= sqrt(vx * vx + vy * vy);

				//�e�x�N�g���ŐڐG�܂��͓����ɑ��݂��Ă邩����
				if(vx != 0) ex = vx / dis;
				else ex = 0.0;
				if(vy != 0) ey = vy / dis;
				else ey = 0.0;
					ext		= cx * ey - cy * ex;
				inner	= cx * ex + cy * ey;
				rad     = atan2(ext , inner);
				if( ext < player.size ) flg++;
			}
			if( flg == 4 ) return 1; //4�ӑS�Ă��ڐGor�����ɂ���(�q�b�g���Ă���)
			else	return 0;//�G���ĂȂ�
		}else if( erecbullet[num].dist < grazehantei ){
			return 2;//�����Ă���
		}else if( erecbullet[num].dist < diffencehantei && player.specialflg > 0 ){
			return 3;//�h�䂳�ꂽ
		}
		return 0;//�G���ĂȂ�
	}
}

//�e�����������ꍇ�̒e������


//�G�e�̏���
void delete_ebullet( int i ){
	if( ebullet[i].x <= BULLET_MIN_XY - 40 || ebullet[i].x >= BULLET_MAX_X + 40 || ebullet[i].y <= BULLET_MIN_XY -40 || ebullet[i].y >= BULLET_MAX_Y || ebullet[i].hitflg == 1 || ebullet[i].hitflg == 3){
		ebullet[i].flg = 0;
		//ebullet[i].hitflg = 0;
	}
	//���ŃG�t�F�N�g�𔺂�����
	if( ebullet[i].flg == 2 ){
		int ab = 0;
		if(spd.count == 1) ebullet[i].delef--;
		ab = ebullet[i].delef * 24 - 240;
		SetDrawBlendMode( DX_BLENDMODE_ALPHA , ab );
		drawbullet( ebullet[i].x, ebullet[i].y, ebullet[i].rad, 0, ebullet[i].graph );
		if( ebullet[i].delef < 16 && ebullet[i].delef > 0 ){
			DrawRotaGraph( ebullet[i].x, ebullet[i].y, 0.25, 0, ebulletexp[16 - ebullet[i].delef], TRUE , FALSE ) ;
		}
		if( ebullet[i].delef == 0 ){
			ebullet[i].flg = 0;
		}
	}
}

void delete_ebulletrec( int i ){
	if( erecbullet[i].x <= BULLET_MIN_XY - 40 || erecbullet[i].x >= BULLET_MAX_X +40 || erecbullet[i].y <= BULLET_MIN_XY -40 || erecbullet[i].y >= BULLET_MAX_Y +40 || erecbullet[i].hitflg == 1 || erecbullet[i].hitflg == 3){
		erecbullet[i].flg = 0;
		//erecbullet[i].hitflg = 0;
	}
	//���ŃG�t�F�N�g�𔺂�����
	if( erecbullet[i].flg == 2 ){
		int ab = 0;
		if(spd.count == 1) erecbullet[i].delef--;
		ab = erecbullet[i].delef * 24 - 240;
		SetDrawBlendMode( DX_BLENDMODE_ALPHA , ab );
		drawbullet( erecbullet[i].x, erecbullet[i].y, erecbullet[i].rad, 0, erecbullet[i].graph );
		if( erecbullet[i].delef < 16 && erecbullet[i].delef > 0 ){
			DrawRotaGraph( erecbullet[i].x, erecbullet[i].y, 0.25, 0, ebulletexp[16 - erecbullet[i].delef], TRUE , FALSE ) ;
		}
		if( erecbullet[i].delef == 0 ){
			erecbullet[i].flg = 0;
		}
	}
}

//�G�e���䃁�C���֐�
void ebullet_mein(){
	manage_measure( 0, 0 );
	
	//���^����e����B
	for(int i = 0; i < E_SHOT_MAX; i++ ){
		if( ebullet[i].flg != 0 ){

			//�e�����v�Z�p
			obnum++;

			move_ebullet ( i, 1 );
			ebullet[i].dist = distance( ebullet[i].x, ebullet[i].y );
			ebullet[i].hitflg = hitmodule( i, 1 );
			if( ebullet[i].hitflg == 2 && ebullet[i].grazeflg == 0 && player.no_control == 0 && player.specialflg == 0 && player.nodmg_cnt == 0 ){
				info.graze++;
				ebullet[i].grazeflg = 1;
				ebullet[i].hitflg = 0;

				//�O���C�Y�ɂ�鐬��
				if( info.graze % 20 == 0 && player.chara_type == 1 ){
					player.magicmax++;
				}else if( info.graze % 18 == 0 && player.chara_type == 2 ){
					player.magicmax++;
				}
				if( CheckSoundMem( effectsound[0] ) == 1 ){
					StopSoundMem( effectsound[0] );
				}
				PlaySoundMem( effectsound[0] , DX_PLAYTYPE_BACK ) ;
				add_effect(player.x, player.y, 2, 0 );
			}
			delete_ebullet( i );
		}

		//���݂���e�̕`��
		if( ebullet[i].flg == 1 ){
			drawbullet( ebullet[i].x, ebullet[i].y, ebullet[i].rad, 0, ebullet[i].graph );
		}
	}

	//���^����e����
	for(int j = 0; j < E_SHOT_MAX; j++ ){
		if( erecbullet[j].flg != 0 ){

			//�e�����v�Z�p
			obnum++;

			move_ebullet ( j, 2 );
			hitarea( j );
			erecbullet[j].dist = distance( erecbullet[j].x, erecbullet[j].y );
			erecbullet[j].hitflg = hitmodule( j, 2 );
			if( erecbullet[j].hitflg == 2 && erecbullet[j].grazeflg == 0 && player.no_control == 0 && player.specialflg == 0 && player.nodmg_cnt == 0 ){
				info.graze++;
				erecbullet[j].grazeflg = 1;
				erecbullet[j].hitflg = 0;

				//�O���C�Y�ɂ�鐬��
				if( info.graze % 20 == 0 && player.chara_type == 1 ){
					player.magicmax++;
				}else if( info.graze % 18 == 0 && player.chara_type == 2 ){
					player.magicmax++;
				}
				if( CheckSoundMem( effectsound[0] ) == 1 ){
					StopSoundMem( effectsound[0] );
				}
				PlaySoundMem( effectsound[0] , DX_PLAYTYPE_BACK ) ;
				add_effect(player.x, player.y, 2, 0 );
			}
			delete_ebulletrec( j );
		}

		//���݂���e�̕`��
		if( erecbullet[j].flg == 1 ){
			drawbullet( erecbullet[j].x, erecbullet[j].y, erecbullet[j].rad, 0, erecbullet[j].graph );
			//DrawModiGraph( erecbullet[j].recx[0] , erecbullet[j].recy[0] , erecbullet[j].recx[1] , erecbullet[j].recy[1] , erecbullet[j].recx[2] , erecbullet[j].recy[2] , erecbullet[j].recx[3] , erecbullet[j].recy[3] , backboard[2] , FALSE );
		}
	}
	manage_measure( 1, 0 );
}