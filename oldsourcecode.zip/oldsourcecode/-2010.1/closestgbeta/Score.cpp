/*--------------------------------------------/
/�X�R�A�v�Z�֌W                               /
/                                             /
/                                             /
/--------------------------------------------*/

#include "Extern.h"
#include "dxlib.h"
#include <math.h>

//�G�t�F�N�g�ǉ��֐��̃v���g�^�C�v�錾
void add_effect( float x, float y, int type, float rad );


//�P���G���j�ɂ��X�R�A���Z
int add_score_enemy( int i ){
	if( boss.flg == 0 ){
		int addscore = enemy[i].hpmax * info.stage * 10;
		return addscore;
	}else{
		int addscore = 50000 * info.stage;
		return addscore;
	}
}

//����G���j�ɂ��X�R�A�������Z
void add_spscore_enemy( int i ){
	info.sp_rate[0]++;
	if( info.sp_rate[0] >= player.magicmax ) info.sp_rate[0] = player.magicmax;
	if( boss.flg == 0 ){
		info.sp_score[0] += enemy[i].hpmax * info.sp_rate[0];
	}
	
	for(int j = 0; j < E_SHOT_MAX; j++ ){
		if( ebullet[j].enemyid == i && ebullet[j].flg == 1 ){
			info.sp_rate[0]++;
			info.clearnum[0]++;
			if( info.sp_rate[0] >= player.magicmax ) info.sp_rate[0] = player.magicmax;
			info.sp_score[0] += ebullet[j].atk * info.sp_rate[0];
			ebullet[j].flg = 2;
			ebullet[j].delef = 10;
		}
		if( erecbullet[j].enemyid == i && erecbullet[j].flg == 1 ){
			info.clearnum[0]++;
			info.sp_rate[0]++;
			if( info.sp_rate[0] >= player.magicmax ) info.sp_rate[0] = player.magicmax;
			info.sp_score[0] += erecbullet[j].atk * info.sp_rate[0];
			erecbullet[j].flg = 2;
			erecbullet[j].delef = 10;
		}
	}
	if( boss.flg == 0 ){
		add_effect( enemy[i].x, enemy[i].y - 20, 16, info.sp_rate[0] );
	}else{
		add_effect( boss.x, boss.y - 20, 16, info.sp_rate[0] );
	}
}

//���������N�_
void add_clearbullet(){
	int rank;
	rank = info.clearnum[0] / 400;
	info.score[0] = pow( (float)rank, 2 ) * ( 10000 * info.stage );
}

//���͊J�����s�_���Z
void add_runscore(){
	info.score[0] += player.magicmax * (float)((info.graze + 500.0) / 2000.0 );
}

//�{�X���j�{�[�i�X�_
int add_bossbonus( int bossnum ){
	float bonusrate = 1;
	int getbonus;

	if( boss.useflg[0] == 1 ) bonusrate *= 1.3;
	if( boss.useflg[1] == 1 ) bonusrate *= 0.8;
	if( boss.useflg[2] == 1 ) bonusrate *= 1.6;
	if( boss.useflg[3] == 1 ) bonusrate *= 0.5;
	if( boss.useflg[4] >= 1 ) bonusrate *= 0.4;
	
	getbonus = (enemynum[bossnum][boss.checkcnt].clearbonus * ((float)(boss.limitcnt - boss.cnt) / (float)boss.limitcnt)) *bonusrate;
	info.score[0] += getbonus;

	return getbonus;
}

//�{�X�ł����ݓ_���Z
void hitscore(){
	info.score[0] += 64 * info.stage;
}

//�|�C���g�A�C�e���擾�_���Z
int pointitem_score(){
	int rscore = 1000 * info.pointint[0] * info.stage;
	info.score[0] += rscore;
	return rscore;
}

//�J�X��_���Z
int grazed_addsocre(){
	int addscore = info.stage * ( info.graze / 3.0 );
	return addscore;
}

//�X�R�A�������C��
void score_main( int i ){
	//�X�R�A�̉��Z
	if(player.magicflg == 1 ){
		add_spscore_enemy( i );
	}else{
		info.score[0] += add_score_enemy( i );
	}
}

