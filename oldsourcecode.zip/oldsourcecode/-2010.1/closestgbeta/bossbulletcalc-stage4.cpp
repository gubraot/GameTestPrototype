/*--------------------------------------------/
/4�ʗp�{�X                                    /
/�g�p�ԍ���40-45                              /
/                                             /
/--------------------------------------------*/

#include "dxlib.h"
#include "Extern.h"
#include "mathoperation.h"
#include <math.h>

//�e��o�^����ׂ̃v���g�^�C�v�錾
void addebullet( float x, float y, int pow, int ptn, float rad, float spd, int img, int size, int id );
void addebullet2( float x, float y, int pow, int ptn, float rad, float spd, int img, float width, float length, int id );

void bossbulletcalc40(){
	static int startshot, shotcnt;
	if( boss.cnt <= 1 ){
		shotcnt = 0;
	}

	if( boss.cnt % ( 16 - info.dificality * 4 ) == 0 ){
		startshot = GetRand( 400 );
		for( int i = 0; i < 4; i++ ){
			addebullet( startshot + 4 * i, 0, 10, 1, 0, 2 * ( 1 + info.dificality * 0.15 ) + i / 8.0, 92, 2, 400 );
		}
		if( shotcnt % 4 == 0 ){
			startshot = GetRand( 400 );
			for( int i = 0; i < 4; i++ ){
				addebullet( startshot - 4 * i, 0, 10, 1, 0, 2 * ( 1 + info.dificality * 0.15 ) + i / 8.0, 92, 2, 400 );
			}
		}
	}
}

void bossbulletcalc41(){
	static int shotcnt;
	static float shotrad;
	if( boss.cnt <= 1 ){
		shotcnt = 9 + info.dificality * 3;
	}

	if( boss.cnt % ( 15 - info.dificality * 2) == 0 ){
		shotrad = dis_rad( boss.x, boss.y );
		for( int i = 0; i < shotcnt; i++ ){
			addebullet( boss.x, boss.y, 10, 30, shotrad + ( i - shotcnt / 2 ) / ( shotcnt * 2.0 ) + rand( 0.01 ), 16, 99, 2, 400 );
		}
	}
}

void bossbulletcalc42(){
	static int shotcnt, shotcnt2, cooltime;
	if( boss.cnt <= 1 ){
		shotcnt = 0;
		cooltime = 30;
	}

	if( boss.cnt % ( 10 - info.dificality * 2 ) == 0 ){
		addebullet( boss.x + 30, boss.y, 10, 1, shotcnt / 25.0, 2 + ( info.dificality * 0.5 ), 58, 6, 400 );
		addebullet( boss.x - 30, boss.y, 10, 1,  - shotcnt / 25.0, 2 + ( info.dificality * 0.5 ), 58, 6, 400 );
		shotcnt++;
	}
	if( cooltime == 0 && boss.cnt % 6 == 0 ){
		addebullet2( boss.x, boss.y, 10, 33, 0.55, 2 + info.dificality, 72, 1, 2, 400 );
		addebullet2( boss.x, boss.y, 10, 33, -0.55, 2 + info.dificality, 72, 1, 2, 400 );
		shotcnt2++;

		if( shotcnt2 == 3 ){
			cooltime = 60 - info.dificality * 10;
			shotcnt2 = 0;
		}

	}else if( cooltime > 0 ){
		cooltime--;
	}
}

void bossbulletcalc43(){
	static float shotrad;
	static int shotnum, shotcnt;

	if( boss.cnt <= 1 ){
		shotrad = 0;
		shotnum = 30 + info.dificality * 10;
		shotcnt = 0;
	}

	if( boss.cnt % ( 80 - info.dificality * 15 ) == 10 ){
		shotrad = dis_rad( boss.x, boss.y );
		for( int i = 0; i < shotnum; i++ ){
			if( i % 2 == 0 ){
				addebullet( boss.x, boss.y, 10, 31, shotrad + i * ( 2 / (float) shotnum ), 4 * ( 1 + info.dificality * 0.2 ), 66 + ( shotcnt % 10 ), 1.4, 400 );
			}else{
				addebullet( boss.x, boss.y, 10, 32, shotrad + i * ( 2 / (float) shotnum ), 4 * ( 1 + info.dificality * 0.2 ), 66 + ( shotcnt % 10 ), 1.4, 400 );
			}
		}
		shotcnt++;
	}else if( boss.cnt % ( 80 - info.dificality * 15 ) == 30 ){
		for( int i = 0; i < shotnum; i++ ){
			addebullet( boss.x, boss.y, 10, 1, i * ( 2 / (float) shotnum ), 2 * ( 1 + info.dificality * 0.2 ), 66 + ( shotcnt % 10 ), 1.4, 400 );
		}
	}
}

void bossbulletcalc44(){
	static float shotrad;
	static int shotnum, shotcnt;

	if( boss.cnt <= 1 ){
		shotrad = 0;
		shotnum = 50 + info.dificality * 20;
		shotcnt = 0;
	}

	if( boss.cnt % ( 80 - info.dificality * 15 ) == 10 ){
		shotrad = dis_rad( boss.x, boss.y );
		for( int i = 0; i < shotnum; i++ ){
			if( i % 2 == 0 ){
				addebullet( boss.x, boss.y, 10, 31, shotrad + i * ( 2 / (float) shotnum ), 4 * ( 1 + info.dificality * 0.2 ), 66 + ( shotcnt % 10 ), 1.4, 400 );
			}else{
				addebullet( boss.x, boss.y, 10, 32, shotrad + i * ( 2 / (float) shotnum ), 4 * ( 1 + info.dificality * 0.2 ), 66 + ( shotcnt % 10 ), 1.4, 400 );
			}
		}
		shotcnt++;
	}
}

void bossbulletcalc45(){
	if( boss.cnt % 150 == 0 ){
		for( int i = 0; i < 16; i++ ){
			if( i % 2 == 0 ){
				addebullet( boss.x, boss.y, 10, 35, i * ( 1 / 8.0 ) + 1 / 16.0, 4 * ( 1 + info.dificality * 0.2 ), 78, 1.4, 400 );
			}else{
				addebullet( boss.x, boss.y, 10, 34, i * ( 1 / 8.0 ) + 1 / 16.0, 4 * ( 1 + info.dificality * 0.2 ), 78, 1.4, 400 );
			}		
		}
	}
}