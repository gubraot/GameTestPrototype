/*--------------------------------------------/
/�����蔻�菈���֘A                           /
/                                             /
/                                             /
/--------------------------------------------*/

#include "Extern.h"
#include "dxlib.h"
#include "mathoperation.h"
#include "debug.h"
#include "imagedraw.h"
#include "score.h"
#include <math.h>

//�e�����@
//����͊���Enemybullet���ōs���Ă���̂ŁA�ǂ̒e�����������̂��̔��f������
void hit_b_p(){	
	player.hitbullet[0] = -1;	//-1=hit���Ă��Ȃ�
	player.hitbullet[1] = -1;

	for(int i =0; i < E_SHOT_MAX; i++ ){
		if( ebullet[i].hitflg == 1 ){
			player.hitbullet[0] = i;
			ebullet[i].hitflg = 0;
		}
	}
	for( int i = 0; i < E_SHOT_MAX; i++ ){
		if( erecbullet[i].hitflg == 1 ){
			player.hitbullet[1] = i;
			erecbullet[i].hitflg = 0;
		}
	}
	if(player.nodmg_cnt == 0 && player.damage_flg == 0 && player.specialflg == 0 ){
		for( int i = 0; i < 2; i++ ){
			if(player.hitbullet[i] >= 0 ){
				player.damage_flg = 1;
				break;
			}
		}
	}
}

/*//�{�X�G�������@
void hit_be_p(){
	float hantei,grazehantei;
	for( int num = 0; num < 100; num++ ){
		hantei = pow( bossenemy[num].size + player.size, (float)2.0 );
		grazehantei = pow( bossenemy[num].size + player.size + 8, (float)2.0 );
		if( bossenemy[num].dist < hantei ){
			player.damage_flg = 1;
			bossenemy[num].flg = 0;
		}else if( bossenemy[num].dist < grazehantei && bossenemy[num].addtime == 0 ){
			bossenemy[num].addtime = 1;//�����Ă���
			info.graze++;
			//�O���C�Y�ɂ�鐬��
			if( info.graze % 20 == 0 && player.chara_type == 1 ){
				player.magicmax++;
			}else if( info.graze % 18 == 0 && player.chara_type == 2 ){
				player.magicmax++;
			}
			if( CheckSoundMem( effectsound[0] ) == 1 ){
				StopSoundMem( effectsound[0] );
			}
			PlaySoundMem( effectsound[0] , DX_PLAYTYPE_BACK ) ;
			add_effect(player.x, player.y, 2, 0 );
		}else if( bossenemy[num].dist < diffencehantei && player.specialflg > 0 ){
			bossenemy[num].flg = 0;
		}else{
			bossenemy[num].addtime = 0;//�G���ĂȂ�
		}
	}
} */

//���@�e���G
void hit_mb_e(){
	int hanteidist;
	int hihantei_x, hihantei_y;
	for(int i = 0; i < P_SHOT_MAX1; i++){
		for(int j = 0; j < P_SHOT_MAX2; j++){
			if( boss.flg == 1 && boss.waitccnt == 0){//�{�X�����ď����I����Ă�ꍇ
				hanteidist = distancefree( pbullet[i][j].x, pbullet[i][j].y, boss.x, boss.y );

				//�e�΃{�X�̔�����s��
				if( pbullet[i][j].flg == 1 && hanteidist <= pbullet[i][j].size * pbullet[i][j].size + 25 * 25 ){
					boss.nowhp -= pbullet[i][j].atk;
					pbullet[i][j].flg = 0;

					//�ł����ݓ_����
					hitscore();

					//�q�b�g�G�t�F�N�g�ǉ�
					if( player.chara_type == 1 ){
						add_effect( pbullet[i][j].x, pbullet[i][j].y, 9, 0 );
					}else{
						if( pbullet[i][j].ptn >= 4 ){
							add_effect( pbullet[i][j].x, pbullet[i][j].y, 1, pbullet[i][j].angle );
						}else{
							add_effect( pbullet[i][j].x, pbullet[i][j].y, 0, pbullet[i][j].angle );
						}
					}
				}

				//�e�΃{�X�G���̔�����s��
				for(int k = 0; k < 100; k++){
					if( pbullet[i][j].flg == 1 && bossenemy[k].flg == 1 ){//�e�ƓG�����ɑ��݂��Ă���
						hanteidist = distancefree( pbullet[i][j].x, pbullet[i][j].y, bossenemy[k].x, bossenemy[k].y );
						if( hanteidist <= (pbullet[i][j].size * pbullet[i][j].size + bossenemy[k].size * bossenemy[k].size) * 2){//����T�C�Y��2�{�ȓ�
							hihantei_x = pbullet[i][j].x;
							hihantei_y = pbullet[i][j].y;

							//6�񍂐��x������s��
							for( int l = 1; l < 6; l++){
								hihantei_x -= (rad_x( pbullet[i][j].angle, pbullet[i][j].spd ) / 6.0);
								hihantei_y -= (rad_y( pbullet[i][j].angle, pbullet[i][j].spd ) / 6.0);

								//���苗���Čv�Z
								hanteidist = distancefree( hihantei_x, hihantei_y, bossenemy[k].x, bossenemy[k].y );

								//�����蔻��
								if( hanteidist <= pbullet[i][j].size * pbullet[i][j].size + bossenemy[k].size * bossenemy[k].size ){
									bossenemy[k].hp -= pbullet[i][j].atk;
									pbullet[i][j].flg = 0;

									//�G�t�F�N�g�̒ǉ�
									if( player.chara_type == 2 ){
										if( pbullet[i][j].ptn >= 4 ){
											add_effect( pbullet[i][j].x, pbullet[i][j].y, 1, pbullet[i][j].angle );
										}else{
											add_effect( pbullet[i][j].x, pbullet[i][j].y, 0, pbullet[i][j].angle );
										}
									}else{
										add_effect( pbullet[i][j].x, pbullet[i][j].y, 9, 0 );
									}
									break;
								}
							}
						}
					}
				}
			}
			//���@�ΎG���Ƃ̔�����s��
			for(int k = 0; k < ENEMY_MAXNUM; k++){
				if( pbullet[i][j].flg == 1 && enemy[k].flg == 1 ){//�e�ƓG�����ɑ��݂��Ă���
					hanteidist = distancefree( pbullet[i][j].x, pbullet[i][j].y, enemy[k].x, enemy[k].y );
					if( hanteidist <= (pbullet[i][j].size * pbullet[i][j].size + enemy[k].size * enemy[k].size) * 2){//����T�C�Y��2�{�ȓ�
						hihantei_x = pbullet[i][j].x;
						hihantei_y = pbullet[i][j].y;

						//6�񍂐��x������s��
						for( int l = 1; l < 6; l++){
							hihantei_x -= (rad_x( pbullet[i][j].angle, pbullet[i][j].spd ) / 6.0);
							hihantei_y -= (rad_y( pbullet[i][j].angle, pbullet[i][j].spd ) / 6.0);

							//���苗���Čv�Z
							hanteidist = distancefree( hihantei_x, hihantei_y, enemy[k].x, enemy[k].y );

							//�����蔻��
							if( hanteidist <= pbullet[i][j].size * pbullet[i][j].size + enemy[k].size * enemy[k].size ){
								enemy[k].hp -= pbullet[i][j].atk;
								pbullet[i][j].flg = 0;

								//�G�t�F�N�g�̒ǉ�
								if( player.chara_type == 2 ){
									if( pbullet[i][j].ptn >= 4 ){
										add_effect( pbullet[i][j].x, pbullet[i][j].y, 1, pbullet[i][j].angle );
									}else{
											add_effect( pbullet[i][j].x, pbullet[i][j].y, 0, pbullet[i][j].angle );
									}
								}else{
									add_effect( pbullet[i][j].x, pbullet[i][j].y, 9, 0 );
								}
								break;
							}
						}
					}
				}
			}
		}
	}
}

//rec�����b
int recbasic( int i, int target, int targetnum ){
	int flg = 0;
	float cx,cy,ex,ey;
	for( int j = 0; j < 4; j++){
		//�x�N�g��������
		float vx = recarea[i].recx[j] - recarea[i].recx[(j+1)%4];
		float vy = recarea[i].recy[j] - recarea[i].recy[(j+1)%4];
		switch( target ){
			case 0: //�G
				cx = recarea[i].recx[j] - enemy[targetnum].x;
				cy = recarea[i].recy[j] - enemy[targetnum].y;
				break;

			case 1: //�{�X
				cx = recarea[i].recx[j] - boss.x;
				cy = recarea[i].recy[j] - boss.y;
				break;

			case 2: //�{�X�G��
				cx = recarea[i].recx[j] - bossenemy[targetnum].x;
				cy = recarea[i].recy[j] - bossenemy[targetnum].y;
				break;

			case 3: //���@
				cx = recarea[i].recx[j] - player.x;
				cy = recarea[i].recy[j] - player.y;
				break;
		}
		float dis = sqrt(vx * vx + vy * vy);

		//�ڐG���Ă邩����
		if(vx != 0) ex = vx / dis;
		else ex = 0.0;
		if(vy != 0) ey = vy / dis;
		else ey = 0.0;
		float ext	= cx * ey - cy * ex;
		float inner	= cx * ex + cy * ey;
		float rad   = atan2(ext , inner);

		//�����蔻��Ώۂɉ������茳�̕���
		switch( target ){
			case 0:
				if( ext < enemy[targetnum].size ) flg++;
				break;

			case 1:
				if( ext < 32 ) flg++;
				break;

			case 2:
				if( ext < bossenemy[targetnum].size ) flg++;
				break;

			case 3:
				if( ext < player.size ) flg++;
				break;
		}

		if( flg == 4 ) return 1;
	}
	return 0;
}

//�͈͔���G���A�̔���(���@1�A�厲+����+��+�p�x�ɂ��͈͎w��)
void cleate_recarea1( int x, int y, float width, float length, int atk, int hitnum, int time, int target, float spd, float rad, int graph ){
	for(int i = 0; i < 20; i++){
		if( recarea[i].flg == 0 ){
			recarea[i].x		= 0; 
			recarea[i].y		= 0; 
			recarea[i].spd		= spd;
			recarea[i].rad		= rad;
			recarea[i].width	= width;	
			recarea[i].length	= length;

			//4�_�Z�o�Ƒ��
			float diagonal, posrad, fixrad;
			diagonal = sqrt(pow( recarea[i].length / 2.0, 2 ) + pow( recarea[i].width / 2.0, 2 ));
			posrad = atan2(( recarea[i].length / 2.0 ), ( recarea[i].width / 2.0 ));
			for( int j = 0; j < 4; j++ ){
				switch( j ){
					case 0:
						recarea[i].recx[j] = recarea[i].x + rad_x( recarea[i].rad + posrad, diagonal );
						recarea[i].recy[j] = recarea[i].y + rad_y( recarea[i].rad + posrad, diagonal );
						break;
					case 1:
						recarea[i].recx[j] = recarea[i].x + rad_x( recarea[i].rad - posrad, diagonal );
						recarea[i].recy[j] = recarea[i].y + rad_y( recarea[i].rad - posrad, diagonal );
						break;
					case 2:
						recarea[i].recx[j] = recarea[i].x - rad_x( recarea[i].rad + posrad, diagonal );
						recarea[i].recy[j] = recarea[i].y - rad_y( recarea[i].rad + posrad, diagonal );
						break;
					case 3:
						recarea[i].recx[j] = recarea[i].x - rad_x( recarea[i].rad - posrad, diagonal );
						recarea[i].recy[j] = recarea[i].y - rad_y( recarea[i].rad - posrad, diagonal );
						break;
				}
			}
			recarea[i].width	= 0;	
			recarea[i].length	= 0;
			recarea[i].flg		= 1;
			for(int j = 0; j < ENEMY_MAXNUM; j++ ){
				recarea[i].areaflge[j] = 0;
			}
			for(int j = 0; j < 100; j++ ){
				recarea[i].areaflgeb[j] = 0;
			}
			recarea[i].areaflgb = 0;
			recarea[i].atk		= atk; 
			recarea[i].hitnum	= hitnum;
			recarea[i].graph	= graph;
			recarea[i].target	= target;
			recarea[i].time		= 0;
			recarea[i].maxtime	= time;
		}
	}
}

//�͈͔���G���A�̔���(���@2,4�_�̒��ڎw��ɂ��͈͎w��)
void cleate_recarea2( float x1, float y1, float x2, float y2, float x3, float y3, float x4, float y4, int atk, int hitnum, int time, int target, float spd, float rad, int graph ){
	for(int i = 0; i < 20; i++){
		if( recarea[i].flg == 0 ){
			recarea[i].x		= 0; 
			recarea[i].y		= 0; 
			recarea[i].spd		= spd;
			recarea[i].rad		= rad;
			recarea[i].recx[0]	= x1;
			recarea[i].recx[1]	= x2;
			recarea[i].recx[2]	= x3;
			recarea[i].recx[3]	= x4;
			recarea[i].recy[0]	= y1;
			recarea[i].recy[1]	= y2;
			recarea[i].recy[2]	= y3;
			recarea[i].recy[3]	= y4;
			recarea[i].width	= 0;	
			recarea[i].length	= 0;
			recarea[i].flg		= 1;
			for(int j = 0; j < ENEMY_MAXNUM; j++ ){
				recarea[i].areaflge[j] = 0;
			}
			for(int j = 0; j < 100; j++ ){
				recarea[i].areaflgeb[j] = 0;
			}
			recarea[i].areaflgb = 0;
			recarea[i].atk		= atk; 
			recarea[i].hitnum	= hitnum;
			recarea[i].graph	= graph;
			recarea[i].target	= target;
			recarea[i].time		= 0;
			recarea[i].maxtime	= time;
			break;
		}
	}
}

//�͈͔��莩�瓮���ꍇ
void erea_move( int i ){
	switch( recarea[i].moveptn ){
		case -1:
			break;

		case 0:
			break;
	}
}


//�͈͔��聨���@or�G ��������
void area_hit(){
	for(int i = 0; i < 20; i++){
		if(recarea[i].flg == 1){
			switch( recarea[i].target ){
				case 0://�G�̏ꍇ
					if( boss.flg == 1 ){//�{�X������ꍇ
						if( recarea[i].areaflgb < recarea[i].hitnum ){
							if( recbasic( i, 1, 0 ) == 1 ){
								recarea[i].areaflgb++;
								boss.nowhp -= recarea[i].atk;
							}
						}
						for(int j = 0; j < 100; j++ ){
							if( recarea[i].areaflgeb[j] < recarea[i].hitnum &&bossenemy[j].flg == 1){
								if( recbasic( i, 2, j ) == 1 ){
									recarea[i].areaflgeb[j]++;
									bossenemy[j].hp -= recarea[i].atk;
								}
							}
						}
					}else{//���Ȃ��ꍇ
						for(int j = 0; j < ENEMY_MAXNUM; j++ ){
							if( recarea[i].areaflge[j] < recarea[i].hitnum && enemy[j].flg == 1 ){
								if( recbasic( i, 0, j ) == 1 ){
									recarea[i].areaflge[j]++;
									enemy[j].hp -= recarea[i].atk;
								}
							}
						}
					}
					break;
				case 1://���@�̏ꍇ
					break;
			}
			recarea[i].time++;
			if( recarea[i].time == recarea[i].maxtime ){
				recarea[i].flg = 0;
			}
		}
		if( recarea[i].spd > 0 ){//����G���A�������ꍇ
			for( int j = 0; j < 4; j++ ){
				recarea[i].recx[j] += rad_x( recarea[i].rad, recarea[i].spd );
				recarea[i].recy[j] += rad_y( recarea[i].rad, recarea[i].spd );
			}
		}
	}
}


//���@���[�U�[
int hit_lazer_e( int x, int y, float size, float atk ){
	int hanteidist;

	//�{�X�����ď������I����Ă���ꍇ
	if( boss.flg == 1 && boss.waitccnt == 0){
		hanteidist = distancefree( x, y, boss.x, boss.y );
		if( hanteidist <= size * size + 25 * 25 ){
			boss.nowhp -= atk;
			hitscore();
			add_effect( x, y, 0, 1 );
			return 1;
		}
	}

	//�G��
	for(int k = 0; k < ENEMY_MAXNUM; k++){
		if( enemy[k].flg == 1 ){//�G�����ɑ��݂��Ă���
			hanteidist = distancefree( x, y, enemy[k].x, enemy[k].y );
			if( hanteidist <= size * size + enemy[k].size * enemy[k].size ){
				enemy[k].hp -= atk;
				add_effect( x, y, 0, 1 );
				return 1;
			}
		}
	}
	return 0;
}

//���@�z�[�~���O���[�U�[
int hit_hlazer_e( int x, int y, float atk ){
	int hanteidist;

	//�{�X�����ď������I����Ă���ꍇ
	if( boss.flg == 1 && boss.waitccnt == 0){
		hanteidist = distancefree( x, y, boss.x, boss.y );
		if( hanteidist <= 4 * 4 + 25 * 25 ){
			boss.nowhp -= atk;
			hitscore();
			add_effect( x, y, 0, 1 );
			return 1;
		}
	}
	for(int k = 0; k < ENEMY_MAXNUM; k++){
		if( enemy[k].flg == 1 ){//�G�����ɑ��݂��Ă���
			hanteidist = distancefree( x, y, enemy[k].x, enemy[k].y );
			if( hanteidist <= 4 * 4 + enemy[k].size * enemy[k].size ){
				enemy[k].hp -= atk;
				add_effect( x, y, 0, 1 );
				return 1;
			}
		}
	}
	return 0;
}



//�����蔻�葍��
void hitmodule(){
	manage_measure( 0, 3 );
	hit_mb_e();
	hit_b_p();
	area_hit();
	manage_measure( 1, 3 );
}