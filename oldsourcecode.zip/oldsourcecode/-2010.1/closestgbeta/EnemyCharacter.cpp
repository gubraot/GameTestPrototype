/*--------------------------------------------/
/�G�I�u�W�F�N�g��`                           /
/�G�{�́A�s���p�^�[����                       /
/                                             /
/--------------------------------------------*/

#include "dxlib.h"
#include "Extern.h"
#include "mathoperation.h"
#include "score.h"
#include "imagedraw.h"
#include "ebulletcalc.h"

//�A�C�e���h���b�v�֐��v���g�^�C�v�錾
void item_drop(int enem );

//�p�^�[��1(�w��b��Ɋp�x�����ɓ���)
void enemymoveptn01( int i ){
	if( enemy[i].time > enemy[i].movecng ){
		enemy[i].x	+= rad_x( enemy[i].angle, enemy[i].spd );
		enemy[i].y	+= rad_y( enemy[i].angle, enemy[i].spd ); 
	}
}

//�p�^�[��2(�ʂ�߂��邾��)
void enemymoveptn02( int i ){
	enemy[i].x	+= rad_x( enemy[i].angle, enemy[i].spd );
	enemy[i].y	+= rad_y( enemy[i].angle, enemy[i].spd ); 
}

//�p�^�[��3(�~��Ă��Đ؂�ւ����Ԃ܂Œ�؂��Ċp�x�����Ɏw�葬�x�łǂ����s��)
void enemymoveptn03( int i ){
	if(enemy[i].time <= 50){
		enemy[i].y	+= rad_y( 0, (50 - enemy[i].time) / 10 );
	}else if( enemy[i].time > enemy[i].movecng ){
		enemy[i].x	+= rad_x( enemy[i].angle, enemy[i].spd );
		enemy[i].y	+= rad_y( enemy[i].angle, enemy[i].spd ); 
	}

}

//�p�^�[��4(�o�����Đ؂�ւ����Ԍ��ɓK���Ɉړ�����)
void enemymoveptn04( int i ){
	if( enemy[i].time > enemy[i].movecng ){
		if((enemy[i].time - enemy[i].movecng)% 30 == 1){
			enemy[i].angle = 1.0 + rand(0.4);
		}	
		enemy[i].x	+= rad_x( enemy[i].angle, ((enemy[i].time - enemy[i].movecng)% 30) / 10.0 );
		enemy[i].y	+= rad_y( enemy[i].angle, ((enemy[i].time - enemy[i].movecng)% 30) / 10.0 ); 
	}
}

//�p�^�[��5(�o���ʒu���ɍs���ā��A���ɖ߂�Ȑ��ňړ��B���x�l�̎��Ԃŏ���)
void enemymoveptn05( int i ){
	float mem_x,mem_y;
	float P0[2],P1[2],P2[2],P3[2];
	float u ;
	float P01[2] , P12[2] , P23[2] ;
	float P02[2] , P13[2] ;
	float P03[2] ;

	mem_x = enemy[i].x;
	mem_y = enemy[i].y;
	P0[0] = enemy[i].movecng;
	P0[1] = enemy[i].movecng2;
	P1[0] = enemy[i].movecng-400;
	P1[1] = enemy[i].movecng2-40;
	P2[0] = enemy[i].movecng-500;
	P2[1] = enemy[i].movecng2-200;
	P3[0] = enemy[i].movecng+100;
	P3[1] = enemy[i].movecng2-300;

	u = ( 1.0 / enemy[i].spd ) * enemy[i].time ;

	P01[0] = ( 1.0 - u ) * P0[0] + u * P1[0] ; P01[1] = ( 1.0 - u ) * P0[1] + u * P1[1] ;
	P12[0] = ( 1.0 - u ) * P1[0] + u * P2[0] ; P12[1] = ( 1.0 - u ) * P1[1] + u * P2[1] ;
	P23[0] = ( 1.0 - u ) * P2[0] + u * P3[0] ; P23[1] = ( 1.0 - u ) * P2[1] + u * P3[1] ;

	P02[0] = ( 1.0 - u ) * P01[0] + u * P12[0] ; P02[1] = ( 1.0 - u ) * P01[1] + u * P12[1] ;
	P13[0] = ( 1.0 - u ) * P12[0] + u * P23[0] ; P13[1] = ( 1.0 - u ) * P12[1] + u * P23[1] ;

	P03[0] = ( 1.0 - u ) * P02[0] + u * P13[0] ; P03[1] = ( 1.0 - u ) * P02[1] + u * P13[1] ;

	enemy[i].x = ( int )P03[0] ;
	enemy[i].y = ( int )P03[1] ;
	
	enemy[i].angle = free_rad( mem_x, mem_y, enemy[i].x, enemy[i].y );
}

//�p�^�[��6(�o���ʒu���ɍs���ā��A���ɖ߂�Ȑ��ňړ��B���x�l�̎��Ԃŏ���)
void enemymoveptn06( int i ){
	float mem_x,mem_y;
	float P0[2],P1[2],P2[2],P3[2];
	float u ;
	float P01[2] , P12[2] , P23[2] ;
	float P02[2] , P13[2] ;
	float P03[2] ;

	mem_x = enemy[i].x;
	mem_y = enemy[i].y;
	P0[0] = enemy[i].movecng;
	P0[1] = enemy[i].movecng2;
	P1[0] = enemy[i].movecng+400;
	P1[1] = enemy[i].movecng2-40;
	P2[0] = enemy[i].movecng+500;
	P2[1] = enemy[i].movecng2-200;
	P3[0] = enemy[i].movecng-100;
	P3[1] = enemy[i].movecng2-300;

	u = ( 1.0 / enemy[i].spd ) * enemy[i].time ;

	P01[0] = ( 1.0 - u ) * P0[0] + u * P1[0] ; P01[1] = ( 1.0 - u ) * P0[1] + u * P1[1] ;
	P12[0] = ( 1.0 - u ) * P1[0] + u * P2[0] ; P12[1] = ( 1.0 - u ) * P1[1] + u * P2[1] ;
	P23[0] = ( 1.0 - u ) * P2[0] + u * P3[0] ; P23[1] = ( 1.0 - u ) * P2[1] + u * P3[1] ;

	P02[0] = ( 1.0 - u ) * P01[0] + u * P12[0] ; P02[1] = ( 1.0 - u ) * P01[1] + u * P12[1] ;
	P13[0] = ( 1.0 - u ) * P12[0] + u * P23[0] ; P13[1] = ( 1.0 - u ) * P12[1] + u * P23[1] ;

	P03[0] = ( 1.0 - u ) * P02[0] + u * P13[0] ; P03[1] = ( 1.0 - u ) * P02[1] + u * P13[1] ;

	enemy[i].x = ( int )P03[0] ;
	enemy[i].y = ( int )P03[1] ;
	
	enemy[i].angle = free_rad( mem_x, mem_y, enemy[i].x, enemy[i].y );
}

//�p�^�[��7(�w�莞�Ԋ|���ォ�瑬�x(�ʒu�ő�p)�ɓo��A�w�莞��2�ň�葬�x�������Ďw��p�x�ɋA��B)(�����ʒuy���W��0�Œ�)
void enemymoveptn07( int i ){
	int movey;
	if( enemy[i].time <= enemy[i].movecng ){
		movey = enemy[i].spd / enemy[i].movecng;
		enemy[i].y += movey;
	}else if( enemy[i].time < enemy[i].movecng2 ){
		movey = 0;
	}else{
		enemy[i].x	+= rad_x( enemy[i].angle, 3 );
		enemy[i].y	+= rad_y( enemy[i].angle, 3 ); 
	}
}

//�p�^�[��8(�ォ��~��Ă��đҋ@���Ԃ�����񂵂Ăǂ��������B���񂷂�a�͑��x�Ɉˑ�����B�p�x�����܂Ő��񂷂�B
void enemymoveptn08( int i ){
	float fix_rad;
	if( enemy[i].angle < 0 ){
		fix_rad = - ( enemy[i].time - enemy[i].movecng ) * 0.01;
		if( fix_rad < enemy[i].angle ){
			fix_rad = enemy[i].angle;
		}
	}else{
		fix_rad =( enemy[i].time - enemy[i].movecng ) * 0.01;
		if( fix_rad > enemy[i].angle ){
			fix_rad = enemy[i].angle;
		}
	}
	if( enemy[i].time < enemy[i].movecng ){
		fix_rad = 0.0;
	}
	enemy[i].x += rad_x( fix_rad, enemy[i].spd );
	enemy[i].y += rad_y( fix_rad, enemy[i].spd );
}

//�p�^�[��9(�ォ��~��Ă��đҋ@���Ԃ���t����ɐ��񂵂Ăǂ��������B���񂷂�a�͑��x�Ɉˑ�����B�p�x�����܂Ő��񂷂�B
void enemymoveptn09( int i ){
	float fix_rad = 0.0;
	if( enemy[i].angle < 0 ){
		fix_rad = ( enemy[i].time - enemy[i].movecng ) * 0.01;
		if( fix_rad > abs(enemy[i].angle) ){
			fix_rad = enemy[i].angle;
		}
	}else{
		fix_rad = - ( enemy[i].time - enemy[i].movecng ) * 0.01;
		if( abs(fix_rad) < enemy[i].angle ){
			fix_rad = enemy[i].angle;
		}
	}

	if( enemy[i].time < enemy[i].movecng ){
		fix_rad = 0.0;
	}
	enemy[i].x += rad_x( fix_rad, enemy[i].spd );
	enemy[i].y += rad_y( fix_rad, enemy[i].spd );
}

//�G�̏o��
void Popenemy( int i ){
	//�t���O�𗧂ē���p�ϐ�������������
	if( enemy[i].addtime == GameCounter && boss.flg == 0 && enemy[i].hp > 0 ){
		enemy[i].flg = 1;
		enemy[i].shotcnt = 0;
		enemy[i].time = 0;
		enemy[i].hpmax = enemy[i].hp;
		enemy[i].size = 20;
	}
}

//�G�̈ړ��ƕ\���̔��f
void Moveenemy( int i ){
	if( enemy[i].flg == 1 && spd.count == 1 ){
		switch( enemy[i].moveptn ){
			case 1:
				enemymoveptn01( i );
				break;

			case 2:
				enemymoveptn02( i );
				break;

			case 3:
				enemymoveptn03( i );
				break;

			case 4:
				enemymoveptn04( i );
				break;

			case 5:
				enemymoveptn05( i );
				break;

			case 6:
				enemymoveptn06( i );
				break;

			case 7:
				enemymoveptn07( i );
				break;

			case 8:
				enemymoveptn08( i );
				break;

			case 9:
				enemymoveptn09( i );
				break;
		}
	enemy[i].dist = distance( enemy[i].x,enemy[i].y );
	enemy[i].time++;
	}
	DrawBox( enemy[i].x-16 , enemy[i].y-16 , enemy[i].x+16 , enemy[i].y+16 , color[1] , TRUE);
}

//�G�̍U��
void Attackenemy( int i ){
	if(spd.count == 1){ 
		switch( enemy[i].shotptn ){
			case 1:
				enemybulletcalc01( i );
				break;
	
			case 2:
				enemybulletcalc02( i );
				break;
	
			case 3:
				enemybulletcalc03( i );
				break;
	
			case 4:
				enemybulletcalc04( i );
				break;

			case 5:
				enemybulletcalc05( i );
				break;

			case 6:
				enemybulletcalc06( i );
				break;

			case 7:
				enemybulletcalc07( i );
				break;

			case 8:
				enemybulletcalc08( i );
				break;

			case 10:
				enemybulletcalc10( i );
				break;

			case 11:
				enemybulletcalc11( i );
				break;

			case 12:
				enemybulletcalc12( i );
				break;

			case 13:
				enemybulletcalc13( i );
				break;

			case 14:
				enemybulletcalc14( i );
				break;

			case 15:
				enemybulletcalc15( i );
				break;

			case 16:
				enemybulletcalc15( i );
				break;

			case 20:
				enemybulletcalc20( i );
				break;

			case 21:
				enemybulletcalc21( i );
				break;

			case 22:
				enemybulletcalc22( i );
				break;

			case 23:
				enemybulletcalc23( i );
				break;

			case 24:
				enemybulletcalc24( i );
				break;

			case 25:
				enemybulletcalc25( i );
				break;

			case 30:
				enemybulletcalc30( i );
				break;

			case 31:
				enemybulletcalc31( i );
				break;

			case 32:
				enemybulletcalc32( i );
				break;

			case 33:
				enemybulletcalc33( i );
				break;

			case 34:
				enemybulletcalc34( i );
				break;

			case 35:
				enemybulletcalc35( i );
				break;
		}
	}
}

//�G�̏���
void Deleteenemy( int i ){
	if( enemy[i].x <= BULLET_MIN_XY -30 || enemy[i].x >= BULLET_MAX_X  + 30 || enemy[i].y <= BULLET_MIN_XY -30 || enemy[i].y >= BULLET_MAX_Y + 30){
		enemy[i].flg = 0;
	}
	if( enemy[i].hp < 0 && enemy[i].addtime < GameCounter){
		enemy[i].flg = 0;
		add_effect( enemy[i].x, enemy[i].y, 3, 0 );
		for( int j = 0; j < 10; j++){
			add_effect( enemy[i].x, enemy[i].y, 6, rand(1.0) );
		}
		item_drop( i );
		score_main( i );
	}
}


//�G�{�̏������C��
void EnemyCharacter(){
	for(int i = 0; i < ENEMY_MAXNUM; i++ ){

		//���݂��Ă��Ȃ��G�̓���
		if( boss.flg == 0 ){
			Popenemy( i );
		}

		//���݂���G�̓���
		if( enemy[i].flg == 1 ){
			Moveenemy( i );
			Attackenemy( i );
			Deleteenemy( i );
		}
	}
}

/*-------------
��������{�X��芪���G������
-------------*/

//�e��o�^����ׂ̃v���g�^�C�v�錾
void addebullet( float x, float y, int pow, int ptn, float rad, float spd, int img, int size, int id );
void addebullet2( float x, float y, int pow, int ptn, float rad, float spd, int img, float width, float length, int id );


//�G�̓o�^
void add_b_enemy( float x, float y, int hp, int ptn, int spd, float rad, int size, int img ){
	for(int i = 0; i < 100; i++ ){
		if( bossenemy[i].flg == 0 ){
			bossenemy[i].flg	= 1;
			bossenemy[i].x		= x;
			bossenemy[i].y		= y;
			bossenemy[i].hp		= hp;
			bossenemy[i].hpmax	= hp;
			bossenemy[i].moveptn= ptn;
			bossenemy[i].spd	= spd;
			bossenemy[i].angle	= rad;
			bossenemy[i].size	= size;
			bossenemy[i].time	= 0;
			bossenemy[i].img	= img;
			break;
		}
	}
}

//�{�X�p�G������֐�
void act_b_enemy( int i ){

	//��ނœG�̐U�镑���̕���
	switch( bossenemy[i].moveptn ){
		case 0:
			bossenemy[i].x	+= rad_x( bossenemy[i].angle, bossenemy[i].spd * spd.objspeed );
			bossenemy[i].y	+= rad_y( bossenemy[i].angle, bossenemy[i].spd * spd.objspeed );
			if( bossenemy[i].hp <= 0 ){
				float baserad = dis_rad( bossenemy[i].x, bossenemy[i].y ); 
				for(int j = 0; j < 40; j++ ){
					addebullet2( bossenemy[i].x, bossenemy[i].y, 10, 1, baserad +float(j/20.0) - 0.015, 1.2, 31, 1, 3, 400 );
				}
			}
			break;

		case 1:
			bossenemy[i].x	+= rad_x( bossenemy[i].angle, bossenemy[i].spd * spd.objspeed );
			bossenemy[i].y	+= rad_y( bossenemy[i].angle, bossenemy[i].spd * spd.objspeed );
			if( bossenemy[i].hp <= 0 ){
				float baserad = dis_rad( bossenemy[i].x, bossenemy[i].y ); 
				for(int j = 0; j < 3 + info.dificality; j++ ){
					addebullet2( bossenemy[i].x, bossenemy[i].y, 10, 1, baserad + rand( 0.15 ), 1.2 * ( 1 + info.dificality * 0.15 ), 31, 1, 3, 400 );
				}
			}
	}

	//�J�E���g�A�b�v
	if( spd.count == 1 ) bossenemy[i].time++;

	//�G�̏���
	if( bossenemy[i].x <= BULLET_MIN_XY - 30 || bossenemy[i].x >= BULLET_MAX_X +30 || bossenemy[i].y <= BULLET_MIN_XY-30 || bossenemy[i].y >= BULLET_MAX_Y+30){
		bossenemy[i].flg = 0;
	}
	if( bossenemy[i].hp <= 0 ){
		add_effect( bossenemy[i].x, bossenemy[i].y, 3, 0 );
		bossenemy[i].flg = 0;
	}
}

//�{�X�p�G�����C���֐�
void b_enemy_main(){
	for(int i = 0; i < 100; i++ ){
		if( bossenemy[i].flg == 1 ){
			obnum++;
			act_b_enemy( i );
			drawbullet( bossenemy[i].x, bossenemy[i].y, bossenemy[i].angle, 0, bossenemy[i].img );
		}
	}
}