/*--------------------------------------------/
/�G�e��04,05                                  /
/��������]����e                           /
/���̃p�^�[���͑��p�^�[���ւ̕ғ���           /
/--------------------------------------------*/

#include "dxlib.h"
#include "Extern.h"
#include "mathoperation.h"

void ebulletptn04( int i, int tipe ){
	if( ebullet[i].time < 90 ){
	ebullet[i].rad	+= (double) (2 * spd.objspeed)  / 360.0;
	}
	ebullet[i].x	+= rad_x( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
	ebullet[i].y	+= rad_y( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
}

void ebulletptn05( int i, int type ){
	if( ebullet[i].time < 90 ){
	ebullet[i].rad	-= (double) (2 * spd.objspeed)  / 360.0;
	}
	ebullet[i].x	+= rad_x( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
	ebullet[i].y	+= rad_y( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
}