/*--------------------------------------------/
/�A�C�e�����W���[��                           /
/�A�C�e���Ɋւ��鏈���܂Ƃ�                   /
/                                             /
/--------------------------------------------*/

#include "Extern.h"
#include "dxlib.h"
#include "mathoperation.h"
#include "debug.h"
#include "score.h"
#include "imagedraw.h"

//�A�C�e���h���b�v����
//enemy��boss�����j���ꂽ���ɌĂ΂�f�[�^�ɏ]���A�C�e�������܂������o�^����
void item_drop(int enem ){
RET:
	if( enemy[enem].item[0] > 0 || enemy[enem].item[1] > 0 || enemy[enem].item[2] > 0 || enemy[enem].item[3] > 0 ){
		for(int i = 0; i < ITEM_MAX; i++){
			if( item[i].flg == 0 ){
				if(enemy[enem].item[0] > 10 ){
					item[i].type = 2;
					item[i].autoget = 1;
					enemy[enem].item[0] -= 10;
				}else if( enemy[enem].item[0] > 5 ){
					item[i].type = 1;
					item[i].autoget = 1;
					enemy[enem].item[0] -= 5;
				}else if( enemy[enem].item[0] > 0 ){
					item[i].type = 0;
					item[i].autoget = 1;
					enemy[enem].item[0]--;
				}else if( enemy[enem].item[1] > 5 ){
					item[i].type = 4;
					item[i].autoget = 0;
					enemy[enem].item[1] -= 5;
				}else if( enemy[enem].item[1] > 0 ){
					item[i].type = 3;
					item[i].autoget = 0;
					enemy[enem].item[1]--;
				}else if( enemy[enem].item[2] > 0 ){
					item[i].type = 5;
					item[i].autoget = 0;
					enemy[enem].item[2]--;
				}else if( enemy[enem].item[3] > 0 ){
					item[i].type = 6;
					item[i].autoget = 0;
					enemy[enem].item[3]--;
				}
				item[i].x = enemy[enem].x;
				item[i].y = enemy[enem].y;
				item[i].flg = 1;
				item[i].time = 0;
				item[i].rad = rand(1.0);
				goto RET;
			}
		}
	}
}

//�{�X�A�C�e���h���b�v����
void boss_item_drop(int bossn, int sec ){
	int item1 = enemynum[bossn][sec].item[0];
	int item2 = enemynum[bossn][sec].item[1];
	int item3 = enemynum[bossn][sec].item[2];
	int item4 = enemynum[bossn][sec].item[3];
RET:
	if( item1 > 0 || item2 > 0 || item3 > 0 || item4 > 0 ){
		for(int i = 0; i < ITEM_MAX; i++){
			if( item[i].flg == 0 ){
				if(item1 > 15 ){
					item[i].type = 1;
					item[i].autoget = 1;
					item1 -= 5;
				}else if( item1 > 0 ){
					item[i].type = 0;
					item[i].autoget = 1;
					item1--;
				}else if( item2 > 15 ){
					item[i].type = 4;
					item[i].autoget = 1;
					item2 -= 5;
				}else if( item2 > 0 ){
					item[i].type = 3;
					item[i].autoget = 1;
					item2--;
				}else if( item3 > 0 ){
					item[i].type = 5;
					item[i].autoget = 1;
					item3--;
				}else if( item4 > 0 ){
					item[i].type = 6;
					item[i].autoget = 1;
					item4--;
				}
				item[i].x = boss.x;
				item[i].y = boss.y;
				item[i].flg = 1;
				item[i].time = 0;
				item[i].rad = rand(1.0);
				goto RET;
			}
		}
	}
}

//�A�C�e���̈ړ��A�\������
void item_act( int num ){
	float spd,autorad;
	int count = item[num].time;
	//�ړ���

	if(item[num].time < 30 ){
		spd = 3.0 - ((float)item[num].time / 10.0);
		item[num].x	+= rad_x( item[num].rad, spd );
		item[num].y	+= rad_y( item[num].rad, spd );
	}
	if( item[num].autoget == 0 && item[num].dist < 1600 ){
		autorad = dis_rad( item[num].x, item[num].y );
		item[num].x	+= rad_x( autorad, 7 );
		item[num].y	+= rad_y( autorad, 7 );
	}else if(item[num].autoget == 0 ){
		item[num].y++;
	}else if( item[num].autoget == 1 && item[num].time > 30 ){
		autorad = dis_rad( item[num].x, item[num].y );
		item[num].x	+= rad_x( autorad, 6 );
		item[num].y	+= rad_y( autorad, 6 );
	}
	item[num].dist = distance( item[num].x, item[num].y );
	item[num].time++;

	//�\����
	switch( item[num].type ){
		case 0:
			SetDrawBlendMode( DX_BLENDMODE_ADD, 192 );
			DrawExtendGraph( item[num].x-5, item[num].y-10, item[num].x+5, item[num].y+10, magicitem[count % 32], TRUE );
			DrawExtendGraph( item[num].x-5, item[num].y-10, item[num].x+5, item[num].y+10, magicitem[(count+16) % 32], TRUE );
			SetDrawBlendMode( DX_BLENDMODE_NOBLEND , 0 );
			break;

		case 1:
			SetDrawBlendMode( DX_BLENDMODE_ADD, 192 );
			DrawExtendGraph( item[num].x-8, item[num].y-16, item[num].x+8, item[num].y+16, magicitem[count % 32], TRUE );
			DrawExtendGraph( item[num].x-8, item[num].y-16, item[num].x+8, item[num].y+16, magicitem[(count+16) % 32], TRUE );
			SetDrawBlendMode( DX_BLENDMODE_NOBLEND , 0 );
			break;

		case 2:
			SetDrawBlendMode( DX_BLENDMODE_ADD, 192 );
			DrawExtendGraph( item[num].x-12, item[num].y-24, item[num].x+12, item[num].y+24, magicitem[count % 32], TRUE );
			DrawExtendGraph( item[num].x-12, item[num].y-24, item[num].x+12, item[num].y+24, magicitem[(count+16) % 32], TRUE );
			SetDrawBlendMode( DX_BLENDMODE_NOBLEND , 0 );
			break;

		case 3:
			DrawRotaGraph( item[num].x , item[num].y , 0.3 , 0 , powitem[0] , TRUE );
			DrawRotaGraph( item[num].x , item[num].y , 0.2 , 3.141f *((float)count / 30.0) , powitem[1] , TRUE );
			break;

		case 4:
			DrawRotaGraph( item[num].x , item[num].y , 0.5, 0 , powitem[0] , TRUE );
			DrawRotaGraph( item[num].x , item[num].y , 0.34 , 3.141f *((float)count / 30.0) , powitem[1] , TRUE );
			break;

		case 5:
			DrawRotaGraph( item[num].x , item[num].y , 0.3, 0 , sppointitem[count % 24 / 2] , TRUE );
	}
}

//�A�C�e���̎擾�A���f����
void item_get( int num ){
	switch( item[num].type ){
		case 0:
			player.magic++;
			if( player.magic > player.magicmax ) player.magic = player.magicmax;
			info.magicget[0]++;
			info.magicget[1]++;
			item[num].flg = 0;
			if( CheckSoundMem( effectsound[5] ) == 1 ){
				StopSoundMem( effectsound[5] );
			}
			PlaySoundMem( effectsound[5], DX_PLAYTYPE_BACK ) ;
			break;

		case 1:
			player.magic += 7;
			if( player.magic > player.magicmax ) player.magic = player.magicmax;
			info.magicget[0] += 7;
			info.magicget[1] += 7;
			item[num].flg = 0;
			if( CheckSoundMem( effectsound[5] ) == 1 ){
				StopSoundMem( effectsound[5] );
			}
			PlaySoundMem( effectsound[5], DX_PLAYTYPE_BACK ) ;
			break;

		case 2:
			player.magic += 20;
			if( player.magic > player.magicmax ) player.magic = player.magicmax;
			info.magicget[0] += 20;
			info.magicget[1] += 20;
			item[num].flg = 0;
			if( CheckSoundMem( effectsound[5] ) == 1 ){
				StopSoundMem( effectsound[5] );
			}
			PlaySoundMem( effectsound[5], DX_PLAYTYPE_BACK ) ;
			break;

		case 3:
			info.powerint[0] ++;
			info.powerint[1] ++;
			item[num].flg = 0;
			break;

		case 4:
			info.powerint[0] += 8;
			info.powerint[1] += 8;
			item[num].flg = 0;
			break;

		case 5:
			info.pointint[0] ++;
			info.pointint[1] ++;
			item[num].rad = pointitem_score();
			add_effect( item[num].x, item[num].y, 4, item[num].rad );
			item[num].flg = 0;
			if( CheckSoundMem( effectsound[6] ) == 1 ){
				StopSoundMem( effectsound[6] );
			}
			PlaySoundMem( effectsound[6], DX_PLAYTYPE_BACK ) ;
			break;

		case 6:
			player.hp += 10;
			if( player.hp > player.hpmax ) player.hpmax = player.hp;
			item[num].flg = 0;
			break;

		case 7:
			break;
		case 8:
			break;
	}
	//shotlv�A�b�v
	if( info.powerint[1] >= config.powerup[player.shot_lv] && player.shot_lv < 7){
		player.shot_lv++;
		add_effect( player.x + 25, player.y -10 , 5, 0 );
		PlaySoundMem( effectsound[8], DX_PLAYTYPE_BACK ) ;
	}
}

//�A�C�e���������C��
void item_main(){
	manage_measure( 0, 4 );
	for( int i = 0; i < ITEM_MAX; i++ ){
		if(item[i].flg == 1){
			item_act( i );
			if( item[i].dist < 25 ){
				item_get( i );
			}
		}
	}
	manage_measure( 1, 4 );
}