/*--------------------------------------------/
/�G�e��07                                     /
/�������ɗ����Ă����e                         /
/���̃p�^�[���͑��p�^�[�����ɕғ���           /
/--------------------------------------------*/

#include "dxlib.h"
#include "Extern.h"
#include "mathoperation.h"
#include <math.h>

void ebulletptn07( int i, int type ){
	float memx,memy,memspd;
	switch(type){
		case 0:
			memx = rad_x( ebullet[i].rad, ebullet[i].spd );
			memy = rad_y( ebullet[i].rad, ebullet[i].spd ) + 0.025;
			memspd = ebullet[i].spd;
			ebullet[i].rad = free_rad( 0, 0, memx, memy );
			ebullet[i].spd = sqrt( distancefree( 0, 0, memx, memy ));
			if( ebullet[i].spd >= memspd ) ebullet[i].spd = memspd;
			

			ebullet[i].x	+= rad_x( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
			ebullet[i].y	+= rad_y( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
			break;

		case 1:
			memx = rad_x( erecbullet[i].rad, erecbullet[i].spd );
			memy = rad_y( erecbullet[i].rad, erecbullet[i].spd ) + 0.025;
			memspd = ebullet[i].spd;
			erecbullet[i].rad = free_rad( 0, 0, memx, memy );
			erecbullet[i].spd = sqrt( distancefree( 0, 0, memx, memy ));
			if( erecbullet[i].spd >= memspd ) ebullet[i].spd = memspd;

			erecbullet[i].x	+= rad_x( erecbullet[i].rad, erecbullet[i].spd * spd.objspeed );
			erecbullet[i].y	+= rad_y( erecbullet[i].rad, erecbullet[i].spd * spd.objspeed );
			break;
	}
}