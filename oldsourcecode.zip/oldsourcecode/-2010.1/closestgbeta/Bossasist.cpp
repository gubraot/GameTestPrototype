/*--------------------------------------------/
/�{�X�֘A                                     /
/�{�X�̎�芪��                               /
/                                             /
/--------------------------------------------*/

#include "Extern.h"
#include "dxlib.h"
#include "mathoperation.h"

//��芪���̓o�^
void add_basist( double x, double y, int moveptn, int atkptn ){
}
