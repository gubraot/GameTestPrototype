/*--------------------------------------------/
/�G�e��01                                     /
/�^������Rad�x�ɒe������                      /
/                                             /
/--------------------------------------------*/

#include "dxlib.h"
#include "Extern.h"
#include "mathoperation.h"

void ebulletptn02( int i, int type ){
	switch(type){
		case 0:
			ebullet[i].x	+= rad_x( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
			ebullet[i].y	+= rad_y( ebullet[i].rad, ebullet[i].spd * spd.objspeed );
			break;

		case 1:
			erecbullet[i].x	+= rad_x( erecbullet[i].rad, erecbullet[i].spd * spd.objspeed );
			erecbullet[i].y	+= rad_y( erecbullet[i].rad, erecbullet[i].spd * spd.objspeed );
			break;
	}
}